#pragma once

#include <Arduino.h>

bool radarInitDisplayAndLVGL();
void radarShowSplash(uint32_t durationMs = 1400);
void radarShowBoot(const char *message);
void radarCreateMainScreen();
void radarStartNetwork();
void radarLoop();
void radarResyncRgbDma();
