#include "RuntimeConfig.h"
#include <Preferences.h>
#include <string.h>

struct StoredConfig {
  bool ready = false;
  char ssid[33] = {};
  char password[65] = {};
  char name[80] = {};
  char zone[64] = {};
  char posix[112] = {};
  double lat = 0;
  double lon = 0;
};
static StoredConfig cfg;
static void copyTo(char* dst, size_t cap, const String& src) {
  if(cap) snprintf(dst,cap,"%s",src.c_str());
}
void cmLoadConfig() {
  cfg = StoredConfig{};
  Preferences p;
  if(!p.begin("flyradar",true)) return;
  cfg.ready = p.getBool("ready",false);
  copyTo(cfg.ssid,sizeof(cfg.ssid),p.getString("ssid",""));
  copyTo(cfg.password,sizeof(cfg.password),p.getString("pass",""));
  copyTo(cfg.name,sizeof(cfg.name),p.getString("name",""));
  copyTo(cfg.zone,sizeof(cfg.zone),p.getString("zone",""));
  copyTo(cfg.posix,sizeof(cfg.posix),p.getString("posix",""));
  cfg.lat=p.getDouble("lat",0);
  cfg.lon=p.getDouble("lon",0);
  p.end();
  if(!cfg.ssid[0] || !cfg.name[0] || !cfg.posix[0] || cfg.lat < -90 || cfg.lat > 90 || cfg.lon < -180 || cfg.lon > 180)
    cfg.ready=false;
}
bool cmHasConfig() { return cfg.ready; }
bool cmSaveConfig(const char* ssid, const char* pass, const char* name,
                  double latitude, double longitude, const char* zone, const char* posix) {
  if(!ssid || !ssid[0] || strlen(ssid)>32 || !name || !name[0] || !zone || !zone[0] || !posix || !posix[0] || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180)
    return false;
  Preferences p;
  if(!p.begin("flyradar",false)) return false;
  bool ok=true;
  // Invalidate until all values have been written.
  p.putBool("ready",false);
  ok &= p.putString("ssid",ssid)>0;
  p.putString("pass",pass ? pass : "");  // empty password: open WLAN
  ok &= p.putString("name",name)>0;
  ok &= p.putString("zone",zone)>0;
  ok &= p.putString("posix",posix)>0;
  ok &= p.putDouble("lat",latitude)==sizeof(double);
  ok &= p.putDouble("lon",longitude)==sizeof(double);
  if(ok) ok = p.putBool("ready",true)==1;
  p.end();
  cmLoadConfig();
  return ok && cmHasConfig();
}
void cmClearConfig() { Preferences p; if(p.begin("flyradar",false)){p.clear();p.end();} cfg=StoredConfig{}; }
const char* cmSSID(){ return cfg.ssid; }
const char* cmPassword(){ return cfg.password; }
const char* cmLocation(){ return cfg.name; }
const char* cmTZ(){ return cfg.ready ? cfg.posix : "UTC0"; }
const char* cmIANA(){ return cfg.zone; }
double cmLatitude(){ return cfg.lat; }
double cmLongitude(){ return cfg.lon; }
