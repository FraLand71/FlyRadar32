FlyRadar32 v5.9.1 TEST BUILD
- LVGL partial draw buffer restored from 40 lines to 10 lines.
- Map now visibly moves while dragging, as in v5.8.9.
- Fixed Aviationstack JSON key departure.estimated typo.
- Preferences now display FIRMWARE VERSION 5.9.1.
- Maximum radar range remains 160km.
- SD aircraft photos preserved.
WARNING: RGB visual artifacts are NOT proven fixed until tested on Waveshare hardware.
