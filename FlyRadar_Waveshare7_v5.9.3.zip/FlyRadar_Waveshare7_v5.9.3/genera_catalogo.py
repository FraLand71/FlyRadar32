#!/usr/bin/env python3
"""One-time build of GPL-3.0 top-view SVGs into LVGL 9 ARGB8888 descriptors.
Requires network and: python3 -m pip install --user cairosvg pillow
From: https://github.com/RexKramer1/AircraftShapesSVG (GPL-3.0)
"""
from pathlib import Path
import urllib.request, io
try:
    import cairosvg
    from PIL import Image
except ImportError:
    raise SystemExit('Installa le dipendenze: python3 -m pip install --user cairosvg pillow')

ROOT=Path(__file__).resolve().parent
MODELS=['B744','B748','B763','A388','A320','CL35','C172','R44']
WIDTH=56
text=['#pragma once','#include <lvgl.h>','// Generated from RexKramer1/AircraftShapesSVG, GPL-3.0.','// Asset GPL-3.0: see LICENSE_CATALOGO_GPL3.txt for attribution.']
for model in MODELS:
    url=f'https://raw.githubusercontent.com/RexKramer1/AircraftShapesSVG/main/Shapes%20SVG/{model}.svg'
    print('Scarico',url)
    try:
        data=urllib.request.urlopen(url,timeout=15).read()
        png=cairosvg.svg2png(bytestring=data,output_width=WIDTH,output_height=WIDTH)
        im=Image.open(io.BytesIO(png)).convert('RGBA')
    except Exception as e:
        print('Impossibile caricare',model,':',e,'- uso una sagoma di categoria')
        fallback={'CL35':'GLF6','C172':'C172','R44':'R44','B763':'B763'}.get(model,'A320')
        url=f'https://raw.githubusercontent.com/RexKramer1/AircraftShapesSVG/main/Shapes%20SVG/{fallback}.svg'
        data=urllib.request.urlopen(url,timeout=15).read()
        png=cairosvg.svg2png(bytestring=data,output_width=WIDTH,output_height=WIDTH)
        im=Image.open(io.BytesIO(png)).convert('RGBA')
    # Convert white/black SVG silhouette to solid golden/yellow with correct alpha.
    pixels=[]
    for R,G,B,A in im.getdata():
        alpha=round(A*(1-(R+G+B)/765)) if A else 0
        # original paths often black on transparent: keep black pixels opaque
        pixels.extend([0x57,0xD1,0xFF,alpha])
    words=','.join(f'0x{x:02X}' for x in pixels)
    text.append(f'static const uint8_t catalog_pixels_{model}[] = {{{words}}};')
    text.append(f'''static const lv_image_dsc_t fly_catalog_{model} = {{
  .header = {{ .magic=LV_IMAGE_HEADER_MAGIC, .cf=LV_COLOR_FORMAT_ARGB8888,
              .flags=0, .w={WIDTH}, .h={WIDTH}, .stride={WIDTH*4} }},
  .data_size=sizeof(catalog_pixels_{model}), .data=catalog_pixels_{model}
}};''')
(ROOT/'AircraftCatalog.h').write_text('\n'.join(text)+'\n')
print('Creato AircraftCatalog.h; modelli:',', '.join(MODELS))
