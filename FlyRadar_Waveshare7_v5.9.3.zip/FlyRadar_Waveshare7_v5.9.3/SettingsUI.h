#pragma once
// Return true if the setup wizard replaced the radar screen; on BACK
// RadarUI must rebuild it. On a successful save, the ESP restarts once.
// startupRecovery=true: no radar exists yet; BACK instead retries Wi-Fi.
bool cmRunSettingsMenu(bool startupRecovery = false);
