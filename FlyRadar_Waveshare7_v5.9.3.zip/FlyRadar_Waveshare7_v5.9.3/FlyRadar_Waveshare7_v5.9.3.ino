/*
  FlyRadar32 v5.9.3 - Waveshare firmware for Waveshare ESP32-S3-Touch-LCD-7.

  Display and GT911 initialization are derived directly from the stable
  CalendarMoon build. Two NVS-tracked restarts occur only on the first boot
  of each firmware version; no display test loop is present. Network work
  starts only after the first complete LVGL
  frame has been drawn and the RGB DMA has been aligned once.
  Wi-Fi authentication may start earlier, while the splash is on screen.

  Data sources:
  - Esri World Imagery (photographic map)
  - adsb.fi Open Data API v3 (live aircraft)

  Informational use only. Not for aviation navigation or safety.
*/

#include <Arduino.h>
#include <esp_system.h>
#include <WiFi.h>
#include <Preferences.h>

#include "NetworkTime.h"
#include "RadarUI.h"
#include "RuntimeConfig.h"
#include "SettingsUI.h"
#include "SetupWizard.h"
#include "config.h"

// Two software restarts on first boot of this firmware version only.
// NVS is preserved. A crash after these restarts will NOT trigger them again.
static void postFlashDoubleRestart() {
  Preferences prefs;
  if (!prefs.begin("fly_boot", false)) return;
  const String firmware = FLYRADAR_VERSION;
  String recorded = prefs.getString("fw", "");
  uint8_t phase = prefs.getUChar("phase", 0);
  if (recorded != firmware) {
    prefs.putString("fw", firmware);
    phase = 0;
    prefs.putUChar("phase", phase);
  }
  if (phase < 2) {
    prefs.putUChar("phase", phase + 1);  // commit before restarting
    prefs.end();
    Serial.printf("POST-FLASH restart %d/2\n", phase + 1);
    Serial.flush();
    delay(220);
    ESP.restart();
  }
  prefs.end();
}

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.printf("\nFlyRadar32 v%s - Waveshare 7 inch\n", FLYRADAR_VERSION);
  Serial.printf("RESET REASON: %d (1=poweron, 3=software, 7=watchdog, 9=brownout)\n", (int)esp_reset_reason());
  postFlashDoubleRestart();
  Serial.printf("DIAG startup freeHeap=%u freePsram=%u\n", (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());

  Serial.println("BOOT 1 - display/LVGL/GT911");
  if (!radarInitDisplayAndLVGL()) {
    Serial.println("FATAL: display/LVGL initialization failed");
    while (true) delay(1000);
  }

  Serial.println("BOOT 2 - stable display ready");
  // Inizializza NVS prima dello splash: se gia' configurato possiamo
  // iniziare la connessione Wi-Fi IN PARALLELO alla schermata iniziale.
  cmLoadConfig();
  constexpr uint32_t SPLASH_MIN_MS = 6000UL;
  const uint32_t splashStartMs = millis();
  radarShowSplash(0);  // Renderizza subito senza attendere nello helper.
  if (cmHasConfig()) {
    beginKnownWiFi();  // Non blocca LVGL; niente HTTPS durante lo splash.
  }
  while (millis() - splashStartMs < SPLASH_MIN_MS) delay(50);
  Serial.printf("SPLASH: displayed for at least %lu ms; wifiStatus=%d\n",
                (unsigned long)SPLASH_MIN_MS, (int)WiFi.status());

  Serial.printf("BOOT 2A - NVS loaded; configured=%d; location=%s; heap=%u; psram=%u\n",
                (int)cmHasConfig(), cmLocation(), (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());
  if (!cmHasConfig()) {
    Serial.println("FIRST SETUP: Wi-Fi/location missing");
    if (!cmRunFirstSetup()) {
      radarShowBoot("Setup incomplete. Restart FlyRadar32.");
      return;
    }
    Serial.printf("BOOT 2B - initial setup returned; configured=%d\n", (int)cmHasConfig());
  }

  // Always replace the setup form with the boot status before connecting.
  radarShowBoot("Setup complete. Connecting...");
  while (true) {
    radarShowBoot("Connecting to Wi-Fi...");
    if (connectKnownWiFi(15000)) break;
    Serial.println("BOOT 3 - Wi-Fi unavailable; opening Settings");
    cmRunSettingsMenu(true);
  }

  radarShowBoot("Synchronizing time...");
  if (!syncNTP(15000))
    Serial.println("BOOT 4 - NTP unavailable; radar will continue");
  else
    Serial.println("BOOT 4 - NTP ready");

  // Draw a complete, lightweight radar frame before allocating map buffers
  // or starting TLS. This is the same ordering used by stable CalendarMoon.
  Serial.printf("BOOT 4A - create radar, heap=%u, psram=%u\n", (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());
  radarCreateMainScreen();
  Serial.printf("BOOT 4B - radar created, heap=%u, psram=%u\n", (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());
  delay(250);
  radarResyncRgbDma();
  Serial.println("BOOT 4C - RGB resynchronized");

  // Only now may the background task allocate PSRAM and use HTTPS.
  Serial.println("BOOT 4D - starting network worker");
  radarStartNetwork();
  Serial.printf("BOOT 5 - FlyRadar32 ready; heap=%u, psram=%u\n", (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());
}

void loop() {
  maintainWiFi();
  radarLoop();
  delay(5);
}
