# FlyRadar32 v5.8.7 - Splash prolungato e Wi-Fi durante l'avvio

**Novita'**: splash di almeno 6 secondi; Wi-Fi avviato non appena compare
lo splash, se ci sono credenziali salvate. Evita la seconda chiamata a
WiFi.begin() se il collegamento e' gia' in corso. Branding aggiornato a
FlyRadar32 nelle schermate di avvio e configurazione. La SD e le foto
rimangono identiche alla v5.8.6.

**Apri** `FlyRadar_Waveshare7_v5.8.7.ino` in Arduino IDE mantenendo la
cartella `FlyRadar_Waveshare7_v5.8.7` e la stessa configurazione hardware
Waveshare ESP32-S3 Touch LCD 7 pollici / ESP32 Arduino 3.3.12.

**Non cancellare NVS**: conserva credenziali e coordinate.
Vedi `NOVITA_V5.8.7.txt` e `LEGGIMI_PRIMA.txt`.

---

## Note tecniche delle versioni precedenti (storico)

# Correzione v5.8.6 - montaggio microSD (EXIO4)

Il codice originale selezionava la SD soltanto dopo SPI.begin; la procedura ufficiale Waveshare 03_SD_Test abilita EXIO4 (attivo basso) prima di avviare SPI. La versione 5.8.6 corregge tale sequenza, mantiene i tentativi a 4 e 1 MHz e fornisce una diagnostica separata opzionale. Le foto online e il traffico ADS-B restano invariati.

Dopo il flash apri il Monitor Seriale 115200 e leggi PHOTO SD: MOUNT OK e PHOTO SD: PRONTA. Se fallisce, usa lo sketch separato Test_SD_Waveshare7 fornito nel pacchetto e verifica la formattazione FAT32.

---

# FlyRadar32 v5.8.5 – Foto microSD e indicatore Wi-Fi

Questa versione usa il catalogo fotografico già copiato sulla scheda FAT32 **FLYRADAR32**.
Non occorre rinominare le immagini, cambiare le cartelle né copiarle nello sketch.
La microSD contiene solo fotografie delle compagnie, **non dati ADS-B**: il traffico resta scaricato tramite Wi-Fi ogni 5 secondi.

## Percorsi sulla microSD

- `/foto_compagnie_aeree/mappa_codici.json`
- `/foto_compagnie_aeree/images/AZ/ita-airways-01.jpg`
- `/foto_compagnie_aeree/images/FR/ryanair-02.jpg`

Il nome volume `FLYRADAR32` non viene letto dal firmware: conta la struttura nella radice.

## Nuovo badge nella foto

- **S** verde: foto caricata dalla SD.
- **I** azzurro: foto scaricata da Internet.
- **–** grigio: fotografia illustrativa già inclusa nel firmware.

I crediti sotto la foto identificano la fonte e, se presenti nel catalogo, il fotografo e la licenza. Le foto SD corrispondono alla compagnia, ma non necessariamente all'identico modello o esemplare.

## Wi-Fi

In alto tra orologio e conteggio aerei trovi il ventaglio Wi-Fi (tre archetti), con potenza RSSI in dBm. Stato `OFF` se scollegato. La potenza è aggiornata ogni secondo.

## Diagnostica SD

Apri il Monitor Seriale a **115200 baud**, seleziona un aereo ed esamina i messaggi `PHOTO SD:`.

- `PHOTO SD: PRONTA` → scheda letta.
- `PHOTO SD: OK` → foto locale decodificata: appare **S**.
- `PHOTO SD: MOUNT FALLITO` → controllare filesystem FAT32, contatti, scheda inserita.
- `PHOTO SD: directory ... assente` → verifica che `foto_compagnie_aeree` sia nella radice, non dentro un'altra cartella.
- `PHOTO SD: compagnia non presente` → il catalogo non ha la foto per quel callsign.
- `PHOTO SD: decodifica JPEG fallita` → file non gestibile dal decoder: incolla il log completo per la correzione.

Il mount viene ritentato, prima a 4 MHz e poi a 1 MHz. Non modificare l'espansore CH422G o la configurazione display.

## Installazione

Estrai l'archivio e apri **`FlyRadar_Waveshare7_v5.8.5.ino`** in Arduino IDE, mantenendo scheda Waveshare/ESP32-S3 e le librerie della v5.8.4. Non usare «Erase All Flash», per conservare Wi-Fi e località. Come nelle versioni precedenti sono previsti due riavvii automatici per una nuova versione.

**Stato:** controlli dei sorgenti e integrità ZIP superati; compilazione reale ESP32 e collaudo fisico SD ancora da effettuare. Conserva un backup della v5.8.4.

---

# FlyRadar v5.7.9 – Splash FlyRadar32

La grafica iniziale mostra l'immagine FlyRadar32 800x480 allegata.
L'immagine è già incorporata nel firmware tramite `SplashImage.h`;
**non occorre copiare nessun file sul Waveshare né collegarsi a Internet**.

Non sono stati cambiati radar, touch, foto, compagnie e refresh ADS-B 5 s.
Il doppio riavvio previsto al primo avvio di ogni versione rimane attivo.
L'immagine originale PNG e il JPEG usato nel firmware sono in `SplashAssets/`.

Per compilare aprire il file `FlyRadar_Waveshare7_v5.7.9.ino` dentro
l'omonima cartella, utilizzando le stesse librerie e impostazioni della v5.7.8.
Non eseguire Erase All Flash: le preferenze Wi-Fi/località vengono mantenute.

**Stato:** ZIP verificato, test su hardware/compilazione Arduino non eseguiti.

---

# Aggiornamento FlyRadar Waveshare 7 - versione 5.7.8

**Novita**: rilevamento immediato delle compagnie dai callsign (120 codici ICAO/IATA),
verifica del nome dalla risposta ADSBDB gia scaricata per la rotta, fallback
ADSBDB /airline quando necessario. Se il feed ADS-B fornisce solo `ownOp`,
quello viene indicato come **Operatore**, non come compagnia.

Le fotografie e i crediti della 5.7.7 restano invariati. Frequenza dati ADS-B: 5 s.
Il doppio riavvio dopo il flash e ancora presente; la nuova versione viene
registrata in NVS, quindi al primo avvio fara due reset automatici.

**Installazione**: aprire `FlyRadar_Waveshare7_v5.7.8.ino` nella relativa
cartella, compilare con la stessa scheda/librerie della 5.7.7 e caricare.
Non occorre cancellare la flash ne riconfigurare Wi-Fi e localita.

> Le note storiche della prima base v5.0.0 qui sotto non descrivono tutte le
> funzionalita aggiunte fino alla 5.7.8. Per le modifiche consultare NOVITA_V5.7.8.txt.

---

# FlyRadar Waveshare 7 v5.0.0 — riscrittura pulita

Progetto per **Waveshare ESP32-S3-Touch-LCD-7**, display RGB ST7262
800×480 e touch GT911.

Questa versione non è una patch della serie 4: il boot, il pannello RGB,
LVGL, il touch, la configurazione Wi-Fi/località e il menu Impostazioni
derivano direttamente dalla base CalendarMoon stabile.

## Cosa mostra

- mappa fotografica della località configurata, tramite Esri World Imagery;
- traffico aereo reale dal servizio pubblico adsb.fi API v3;
- icone e callsign dei velivoli in volo;
- tap sull'aeromobile per quota, velocità, rotta, verticale, distanza,
  rilevamento e squawk;
- indicatore del raggio in chilometri;
- zoom a livelli 5, 10, 20, 40, 80 e 120 km con i pulsanti `−` e `+`;
- ora locale e numero di aeromobili;
- prima configurazione touch di rete Wi-Fi e località;
- ingranaggio per cambiare Wi-Fi/località o cancellare la configurazione.

## Correzioni strutturali rispetto alle v4

- nessun doppio riavvio automatico dopo il flash;
- nessun codice di restart nel normale percorso di boot;
- un solo framebuffer del pannello;
- LVGL `PARTIAL`, con un buffer da 10 righe in PSRAM;
- pixel clock RGB a 12 MHz e bounce buffer `800 × 20`, identici al
  CalendarMoon stabile;
- il task di rete parte soltanto dopo che la prima schermata radar è stata
  completata e il DMA RGB è stato riallineato una sola volta;
- nessuna allocazione della mappa prima della prima schermata stabile;
- la mappa nuova viene decodificata nel buffer non visibile;
- pausa fra il ridisegno completo della mappa e la richiesta ADS-B, per non
  contendere la banda PSRAM al pannello;
- icone degli aerei create una volta e poi riutilizzate: niente cancellazione
  e ricostruzione continua degli oggetti LVGL;
- nessun oggetto dello schermo radar è scrollabile;
- nessuna trasformazione/scalatura dell'immagine mentre il display è toccato;
- font scelti con fallback: non viene richiesto `lv_font_montserrat_28`.

### Zoom e touch

In questa prima build stabile il pinch e il trascinamento della mappa sono
intenzionalmente disabilitati. Lo zoom usa `−` e `+` e scarica una nuova mappa
alla scala corretta. Il precedente pinch ridimensionava ripetutamente tutti gli
800×480 pixel e ricreava le icone durante il gesto: era il percorso che causava
glitch, traslazione verso destra, lentezza e riavvii.

Il GT911 continua a essere letto ogni 8 ms, ma con il singolo punto già
collaudato in CalendarMoon. Il pinch potrà essere riattivato in una versione
successiva solo dopo avere confermato il boot stabile di questa base.

## Librerie richieste

Usare lo stesso ambiente del CalendarMoon funzionante:

- ESP32 Arduino Core **3.3.12**;
- ESP32_Display_Panel **1.0.4**;
- LVGL **9.6.0**, con lo stesso `lv_conf.h` di CalendarMoon;
- ArduinoJson **7.x**;
- TJpg_Decoder di Bodmer.

Non servono API key. Wi-Fi e località non sono scritti nel sorgente.

## Impostazioni Arduino IDE

- Scheda: `ESP32S3 Dev Module`;
- Flash Size: `8 MB`;
- PSRAM: `OPI PSRAM`;
- Flash Mode: `QIO 80 MHz`;
- USB CDC On Boot: `Disabled`;
- Partition Scheme: una configurazione 8 MB con almeno circa 3,34 MB per
  l'applicazione;
- collegamento: porta `USB TO UART` della Waveshare.

Se CalendarMoon funziona con impostazioni leggermente diverse sulla tua
unità, mantieni esattamente quelle già collaudate.

## Primo flash v5 — importante

1. Estrai lo ZIP in una cartella nuova.
2. Apri soltanto
   `FlyRadar_Waveshare7_v5.0.0/FlyRadar_Waveshare7_v5.0.0.ino`.
3. Non copiare file dalle cartelle v4 nella cartella v5.
4. Per questo primo caricamento imposta
   `Erase All Flash Before Sketch Upload: Enabled`.
5. Compila e carica.
6. Riporta poi `Erase All Flash Before Sketch Upload` su `Disabled`.
7. Seleziona il Wi-Fi, digita la password e cerca la località dal display.

La cancellazione completa al punto 4 rimuove le vecchie fasi di boot e anche
le credenziali salvate: la configurazione touch ricomparirà una volta.

## Boot atteso

Il display può fare un singolo passaggio bianco/nero quando il pannello viene
alimentato, ma non deve ciclare RGB. Deve poi comparire lo splash FlyRadar e,
se la memoria è vuota, la configurazione.

Nel Monitor Seriale a 115200 baud sono attese righe simili a:

```text
FlyRadar v5.0.0 - Waveshare 7 inch
BOOT 1 - display/LVGL/GT911
RGB: one panel FB, bounce=16000 pixels
DISPLAY MODE: PARTIAL | LVGL buffer=16000 bytes x1 | panelFB=1 NO-FB2
TOUCH: GT911 LVGL read timer=8 ms, one point
BOOT 2 - stable display ready
RGB SYNC: VSYNC DMA restart: ESP_OK (0)
BOOT 5 - FlyRadar ready
MAP: ready, range=40 km ...
ADSB: ... airborne aircraft ...
```

Se lo schermo dovesse ancora ciclare RGB, copiare dal Monitor Seriale tutte le
righe dal primo `FlyRadar v5.0.0` fino al reset successivo: in questa versione
non esiste alcun reset automatico nel boot, quindi il motivo sarà finalmente
visibile (alimentazione, watchdog o eccezione con backtrace).

## Uso

- `−`: raggio minore, mappa più ravvicinata;
- `+`: raggio maggiore, mappa più ampia;
- tap su un aereo: dettagli;
- ingranaggio: Wi-Fi, località e reset configurazione.

Durante il download rimane visibile la mappa precedente. Un errore di Esri o
adsb.fi mostra un messaggio e viene ritentato automaticamente; non riavvia
l'ESP32 e non cancella l'interfaccia.

## Servizi e uso corretto

La ricerca della località usa Open-Meteo e, come fallback, Photon. La mappa e
il traffico richiedono Internet. adsb.fi consente l'endpoint pubblico per uso
personale/non commerciale, con limiti di richiesta; FlyRadar interroga ogni
5 secondi, quindi resta ampiamente sotto il limite dichiarato.

I dati sono informativi e amatoriali. Non usare FlyRadar per navigazione,
separazione del traffico o sicurezza aeronautica.

Crediti: Francesco Landi; riscrittura assistita da OpenAI Codex; dati
adsb.fi; cartografia Esri World Imagery.


## Versione 5.8.0 - dettagli volo DARK

Scheda ripaginata con fotografia 300x156 in alto a destra e linea gialla della rotta subito sotto; le informazioni ADS-B sono in riquadri scuri. La linea e un collegamento grafico tra origine e destinazione, non una percentuale di percorso reale. Il sistema fotografico e l'intervallo di aggiornamento ADS-B (5 secondi) non sono stati modificati.


## Versione 5.8.1
Vedi `NOVITA_V5.8.1.txt` per il nuovo font, avanzamento geografico della tratta e foto illustrate in volo come fallback.

## v5.8.2 - Fotografie del modello, rotte alternative, orari

- **Foto:** la ricerca in rete prova prima l'abbinamento modello/compagnia, quindi
  altre fotografie in volo, poi una ricerca più ampia per il modello e la
  miniatura della pagina Wikipedia relativa al modello. Non viene assegnata
  la registrazione del volo a una fotografia illustrativa. Se tutti i servizi
  falliscono rimane l'immagine generica di emergenza della v5.8.1.
- **Tratta:** una prima ricerca `ADSBDB` usando il codice esadecimale e callsign;
  se incompleta, `ADSBDB /v0/callsign/...`, e infine il servizio indipendente
  `ADSB.lol POST /api/0/routeset` con callsign + latitudine/longitudine.
  Le informazioni ADSB.lol sono ricostruzioni non certificate.
- **Orari:** in alto a destra dei due riquadri PARTENZA e DESTINAZIONE compaiono
  DECOLLO e ARRIVO. Senza una fonte affidabile non inventiamo l'ora del decollo.
  Quando nota la geometria origine/destinazione e la velocità attuale, ARRIVO
  visualizza un'ETA stimata in UTC (non è l'orario programmato!).
- **Dati di orario ufficiali facoltativi:** inserire una propria chiave API in
  `FlightScheduleConfig.h` (macro `FLY_AVIATIONSTACK_API_KEY`) per consultare
  Aviationstack all'apertura della scheda volo. Sono distinti tempi
  programmati (`prog.`), stimati dal provider (`stim.`) ed effettivi (`eff.`).
  Servizio soggetto a limiti/quota e condizioni del fornitore.
- **Freccia:** centrata verticalmente rispetto alla barra gialla. La sua
  posizione orizzontale continua a dipendere dai dati GPS del volo.
- **Networking:** il refresh ADS-B resta impostato a **5000 ms**. Quando apri
  un dettaglio, le richieste foto/tratta possono temporaneamente impegnare
  l'unico worker di rete e ritardare i successivi cicli ADS-B.

### Verifica e diagnosi

Nel Monitor Seriale (115200) cerca prefissi `ROUTE:`, `TIMES:`, `PHOTO:`.
Se non compaiono informazioni di orario, senza chiave API è normale che
`DECOLLO --:--` rimanga invariato. L'ETA è visibile solo se una tratta con
coordinate valide, posizione e velocità sono disponibili.

Lo ZIP è stato controllato nella struttura, ma non compilato né collaudato
fisicamente su Waveshare.


## v5.8.4 - fotografie microSD

Inserisci la microSD FAT32 (etichetta consigliata `FLYRADAR32`) nel Waveshare.
La cartella dell'archivio originale deve trovarsi esattamente in
`/foto_compagnie_aeree/`. Il programma carica prima i JPEG locali usando
`mappa_codici.json` e mostra fonte, fotografo e licenza. In assenza di corrispondenza
continua a cercare online. Non è necessario ricopiare le foto nello sketch.
Leggi `ISTRUZIONI_MICROSD.txt` per diagnostica e percorsi.
