#pragma once
// FlyRadar offline airline recognition. Known ICAO and IATA prefixes only.
// Callsign prefix identifies the flight's operating carrier, not always the
// seller of a codeshare ticket. Unknown prefixes are never guessed.
#include <ctype.h>
#include <stddef.h>
#include <string.h>

struct FlyAirlineEntry {
  const char *icao;
  const char *iata;
  const char *name;
};

static const FlyAirlineEntry FLY_AIRLINES[] = {
  {"ITY", "AZ", "ITA Airways"},
  {"RYR", "FR", "Ryanair"},
  {"DLH", "LH", "Lufthansa"},
  {"BAW", "BA", "British Airways"},
  {"AFR", "AF", "Air France"},
  {"KLM", "KL", "KLM Royal Dutch Airlines"},
  {"EZY", "U2", "easyJet"},
  {"EJU", "EC", "easyJet Europe"},
  {"EZS", "DS", "easyJet Switzerland"},
  {"VLG", "VY", "Vueling"},
  {"VOE", "V7", "Volotea"},
  {"NOS", "NO", "Neos"},
  {"WZZ", "W6", "Wizz Air"},
  {"WMT", "W4", "Wizz Air Malta"},
  {"WUK", "W9", "Wizz Air UK"},
  {"SWR", "LX", "SWISS"},
  {"AUA", "OS", "Austrian Airlines"},
  {"BEL", "SN", "Brussels Airlines"},
  {"EWG", "EW", "Eurowings"},
  {"DLA", "EN", "Air Dolomiti"},
  {"TAP", "TP", "TAP Air Portugal"},
  {"IBE", "IB", "Iberia"},
  {"IBS", "I2", "Iberia Express"},
  {"AEA", "UX", "Air Europa"},
  {"LOT", "LO", "LOT Polish Airlines"},
  {"AEE", "A3", "Aegean Airlines"},
  {"SAS", "SK", "Scandinavian Airlines"},
  {"FIN", "AY", "Finnair"},
  {"EIN", "EI", "Aer Lingus"},
  {"NAX", "DY", "Norwegian Air Shuttle"},
  {"NSZ", "D8", "Norwegian Air Sweden"},
  {"THY", "TK", "Turkish Airlines"},
  {"PGT", "PC", "Pegasus Airlines"},
  {"SXS", "XQ", "SunExpress"},
  {"CTN", "OU", "Croatia Airlines"},
  {"ROT", "RO", "TAROM"},
  {"BTI", "BT", "airBaltic"},
  {"LGL", "LG", "Luxair"},
  {"ICE", "FI", "Icelandair"},
  {"ASL", "JU", "Air Serbia"},
  {"TVS", "QS", "Smartwings"},
  {"ENT", "E4", "Enter Air"},
  {"MAY", "AL", "Malta Air"},
  {"TOM", "BY", "TUI Airways"},
  {"TUI", "X3", "TUI fly Deutschland"},
  {"JAF", "TB", "TUI fly Belgium"},
  {"TRA", "HV", "Transavia"},
  {"TVF", "TO", "Transavia France"},
  {"CND", "CD", "Corendon Dutch Airlines"},
  {"CAI", "XC", "Corendon Airlines"},
  {"FHY", "FH", "Freebird Airlines"},
  {"UAE", "EK", "Emirates"},
  {"QTR", "QR", "Qatar Airways"},
  {"ETD", "EY", "Etihad Airways"},
  {"FDB", "FZ", "flydubai"},
  {"SVA", "SV", "Saudia"},
  {"GFA", "GF", "Gulf Air"},
  {"OMA", "WY", "Oman Air"},
  {"KAC", "KU", "Kuwait Airways"},
  {"JZR", "J9", "Jazeera Airways"},
  {"ELY", "LY", "El Al Israel Airlines"},
  {"AAL", "AA", "American Airlines"},
  {"DAL", "DL", "Delta Air Lines"},
  {"UAL", "UA", "United Airlines"},
  {"SWA", "WN", "Southwest Airlines"},
  {"JBU", "B6", "JetBlue"},
  {"ASA", "AS", "Alaska Airlines"},
  {"FFT", "F9", "Frontier Airlines"},
  {"NKS", "NK", "Spirit Airlines"},
  {"SKW", "OO", "SkyWest Airlines"},
  {"RPA", "YX", "Republic Airways"},
  {"ENY", "MQ", "Envoy Air"},
  {"ACA", "AC", "Air Canada"},
  {"WJA", "WS", "WestJet"},
  {"TSC", "TS", "Air Transat"},
  {"POE", "PD", "Porter Airlines"},
  {"JZA", "QK", "Jazz Aviation"},
  {"AMX", "AM", "Aeromexico"},
  {"VOI", "Y4", "Volaris"},
  {"CMP", "CM", "Copa Airlines"},
  {"AVA", "AV", "Avianca"},
  {"LAN", "LA", "LATAM Airlines"},
  {"GLO", "G3", "GOL Linhas Aereas"},
  {"ARG", "AR", "Aerolineas Argentinas"},
  {"AZU", "AD", "Azul Brazilian Airlines"},
  {"SIA", "SQ", "Singapore Airlines"},
  {"CPA", "CX", "Cathay Pacific"},
  {"QFA", "QF", "Qantas"},
  {"JST", "JQ", "Jetstar"},
  {"ANZ", "NZ", "Air New Zealand"},
  {"ANA", "NH", "All Nippon Airways"},
  {"JAL", "JL", "Japan Airlines"},
  {"KAL", "KE", "Korean Air"},
  {"AAR", "OZ", "Asiana Airlines"},
  {"EVA", "BR", "EVA Air"},
  {"CAL", "CI", "China Airlines"},
  {"CCA", "CA", "Air China"},
  {"CSN", "CZ", "China Southern Airlines"},
  {"CES", "MU", "China Eastern Airlines"},
  {"CHH", "HU", "Hainan Airlines"},
  {"THA", "TG", "Thai Airways"},
  {"MAS", "MH", "Malaysia Airlines"},
  {"AIC", "AI", "Air India"},
  {"IGO", "6E", "IndiGo"},
  {"AXB", "IX", "Air India Express"},
  {"VJC", "VJ", "VietJet Air"},
  {"HVN", "VN", "Vietnam Airlines"},
  {"AXM", "AK", "AirAsia"},
  {"ETH", "ET", "Ethiopian Airlines"},
  {"SAA", "SA", "South African Airways"},
  {"KQA", "KQ", "Kenya Airways"},
  {"RAM", "AT", "Royal Air Maroc"},
  {"MSR", "MS", "EgyptAir"},
  {"TUN", "TU", "Tunisair"},
  {"FDX", "FX", "FedEx Express"},
  {"UPS", "5X", "UPS Airlines"},
  {"CLX", "CV", "Cargolux"},
  {"GTI", "5Y", "Atlas Air"},
  {"CKS", "K4", "Kalitta Air"},
  {"BCS", "QY", "European Air Transport"},
};

// Return the flight carrier only when the callsign has a plausible airline
// prefix and contains a flight number. E.g. ITY343 -> ITA Airways.
static inline const char *flyAirlineFromCallsign(const char *callsign) {
  if (!callsign) return nullptr;
  // ADS-B 'flight' may have leading/trailing spaces.
  while (*callsign == ' ') ++callsign;
  size_t length = strlen(callsign);
  while (length > 0 && callsign[length-1] == ' ') --length;
  if (length < 3 || length > 11) return nullptr;

  char normalized[12];
  for (size_t i = 0; i < length; ++i)
    normalized[i] = (char)toupper((unsigned char)callsign[i]);
  normalized[length] = 0;

  // Callsigns can end in letters (e.g. EZY31TK), but must have a digit.
  bool containsNumber = false;
  for (size_t i = 2; i < length; ++i)
    if (normalized[i] >= '0' && normalized[i] <= '9') containsNumber = true;
  if (!containsNumber) return nullptr;

  for (const FlyAirlineEntry &entry : FLY_AIRLINES) {
    if (length >= 4 && strncmp(normalized, entry.icao, 3) == 0)
      return entry.name;
  }
  // Two-letter IATA callsigns are accepted only when followed immediately
  // by a digit. This reduces false matches against private registrations.
  if (normalized[2] >= '0' && normalized[2] <= '9') {
    for (const FlyAirlineEntry &entry : FLY_AIRLINES)
      if (entry.iata[0] && strlen(entry.iata) == 2 &&
          strncmp(normalized, entry.iata, 2) == 0) return entry.name;
  }
  return nullptr;
}

// Extract ICAO prefix for an optional ADSBDB airline lookup. No inference
// is made for unknown codes before ADSBDB confirms them.
static inline bool flyIcaoPrefixFromCallsign(const char *callsign, char out[4]) {
  out[0] = 0;
  if (!callsign) return false;
  while (*callsign == ' ') ++callsign;
  size_t n = strlen(callsign);
  if (n < 4) return false;
  for (int i = 0; i < 3; ++i) {
    if (!isalpha((unsigned char)callsign[i])) return false;
    out[i] = (char)toupper((unsigned char)callsign[i]);
  }
  out[3] = 0;
  bool numeric = false;
  for (size_t i = 3; i < n && i < 12; ++i)
    if (isdigit((unsigned char)callsign[i])) numeric = true;
  if (!numeric) out[0] = 0;
  return numeric;
}
