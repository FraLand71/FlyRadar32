#include "NetworkTime.h"
#include "config.h"
#include <WiFi.h>
#include <string.h>
#include <time.h>

// Avvio anticipato NON bloccante: lo splash resta visibile mentre il Wi-Fi
// negozia la connessione. L'attivazione della rete non avvia il worker HTTPS.
static bool wifiAttemptActive = false;
static uint32_t wifiAttemptStartMs = 0;
static char wifiAttemptSsid[33] = {};

void beginKnownWiFi() {
  if (!cmHasConfig()) return;
  if (WiFi.status() == WL_CONNECTED && WiFi.SSID() == cmSSID()) return;
  // Non interrompere una connessione gia' in corso con le stesse credenziali.
  if (wifiAttemptActive && strcmp(wifiAttemptSsid, cmSSID()) == 0 &&
      millis() - wifiAttemptStartMs < 25000UL) return;
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  snprintf(wifiAttemptSsid, sizeof(wifiAttemptSsid), "%s", cmSSID());
  wifiAttemptStartMs = millis();
  wifiAttemptActive = true;
  Serial.printf("WIFI EARLY: connection started to %s\n", wifiAttemptSsid);
  WiFi.begin(cmSSID(), cmPassword());  // Asincrono: NON attendere qui.
}

bool connectKnownWiFi(uint32_t timeoutMs) {
  if (!cmHasConfig()) return false;
  if (WiFi.status() == WL_CONNECTED && WiFi.SSID() == cmSSID()) {
    wifiAttemptActive = false;
    return true;
  }
  beginKnownWiFi();  // Riutilizza la connessione gia' avviata nello splash.
  const uint32_t start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < timeoutMs)
    delay(150);
  if (WiFi.status() == WL_CONNECTED && WiFi.SSID() == cmSSID()) {
    wifiAttemptActive = false;
    Serial.printf("Wi-Fi connected: IP=%s\n", WiFi.localIP().toString().c_str());
    return true;
  }
  // Il prossimo tentativo (p.es. dopo la schermata Impostazioni) riparte.
  wifiAttemptActive = false;
  Serial.printf("Wi-Fi reconnect failed: status=%d\n", (int)WiFi.status());
  return false;
}
bool syncNTP(uint32_t timeoutMs) {
  Serial.printf("Timezone: %s (%s)\n",cmIANA(),cmTZ());
  configTzTime(TIMEZONE,NTP_SERVER_1,NTP_SERVER_2,NTP_SERVER_3);
  uint32_t start=millis();
  struct tm t={};
  while(millis()-start<timeoutMs) {
    if(getLocalTime(&t,1000) && t.tm_year+1900>2024) return true;
    delay(100);
  }
  return false;
}
bool getNow(struct tm& out) { return getLocalTime(&out,1000); }
void maintainWiFi() {
  static uint32_t last=0;
  if(millis()-last<30000) return;
  last=millis();
  if(WiFi.status()!=WL_CONNECTED) connectKnownWiFi(4000);
}
