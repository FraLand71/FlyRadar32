#include "RadarUI.h"
#include "AirborneFallback.h"
#include "AdsbTransport.h"
#include "EuropeanFont.h"
#include "JetPhotosConfig.h"
#include "FlightScheduleConfig.h"
#include "AirlineLookup.h"
#include "AircraftIcons.h"
#include "AircraftCatalog.h"
#include "SplashImage.h"

#include "NetworkTime.h"
#include "RuntimeConfig.h"
#include "SettingsUI.h"
#include "config.h"
#include "esp_lv_adapter_arduino.h"

#include <ArduinoJson.h>
#include <FS.h>
#include <SD.h>
#include <SPI.h>
#include <esp_random.h>
#include <HTTPClient.h>
#include <TJpg_Decoder.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <esp_display_panel.hpp>
#include <esp_err.h>
#include <esp_heap_caps.h>
#include <esp_lcd_panel_rgb.h>
#include <lvgl.h>
#include <math.h>
#include <time.h>
#include "freertos/FreeRTOS.h"
#include "freertos/idf_additions.h"
#include "freertos/semphr.h"
#include "freertos/task.h"

using namespace esp_panel::drivers;
using namespace esp_panel::board;

namespace {

constexpr uint32_t C_BG = 0x050B12;
constexpr uint32_t C_PANEL = 0x071923;
constexpr uint32_t C_PANEL_2 = 0x0B2935;
constexpr uint32_t C_TEXT = 0xF4F8FA;
constexpr uint32_t C_DIM = 0xA7B7C0;
constexpr uint32_t C_CYAN = 0x32E4E0;
constexpr uint32_t C_YELLOW = 0xFFD15B;
constexpr uint32_t C_GREEN = 0x58E68A;
constexpr uint32_t C_RED = 0xFF5A63;
constexpr uint32_t C_ORANGE = 0xFFAA54;

// Keep a border of already decoded imagery around the 800x480 viewport.
// Small drags use this PSRAM overscan instead of another 800x480 HTTPS export.
constexpr int MAP_WIDTH = 1024;
constexpr int MAP_HEIGHT = 704;
constexpr int MAP_MARGIN_X = (MAP_WIDTH - SCREEN_WIDTH) / 2;   // 112px
constexpr int MAP_MARGIN_Y = (MAP_HEIGHT - SCREEN_HEIGHT) / 2; // 112px
constexpr int MAP_SAFE_X = MAP_MARGIN_X - 12;
constexpr int MAP_SAFE_Y = MAP_MARGIN_Y - 12;
constexpr size_t MAP_PIXELS = (size_t)MAP_WIDTH * MAP_HEIGHT;
constexpr size_t MAP_BYTES = MAP_PIXELS * sizeof(uint16_t);
constexpr size_t SPLASH_BYTES = (size_t)SCREEN_WIDTH * SCREEN_HEIGHT * sizeof(uint16_t);
constexpr size_t MAX_MAP_JPEG_BYTES = 1200000;
// ArcGIS World Imagery export does not automatically grant the right to
// persist arbitrary downloaded snapshots. Enable persistent writes ONLY
// with authorization for the imagery source you use.
#ifndef MAP_SD_CACHE_ALLOW_PERSISTENCE
#define MAP_SD_CACHE_ALLOW_PERSISTENCE 0
#endif
#ifndef MAP_SD_CACHE_READ_ENABLED
#define MAP_SD_CACHE_READ_ENABLED 1
#endif
constexpr float SCREEN_ASPECT = (float)SCREEN_WIDTH / (float)SCREEN_HEIGHT;
constexpr float CORNER_FACTOR = 1.9436506f;  // sqrt(1 + aspect^2)

constexpr float RANGE_PRESETS[] = {5.0f, 10.0f, 20.0f,
                                   40.0f, 80.0f, 120.0f, 160.0f};
constexpr int RANGE_PRESET_COUNT =
    sizeof(RANGE_PRESETS) / sizeof(RANGE_PRESETS[0]);

enum AircraftKind : uint8_t {
  KIND_AIRLINER,
  KIND_HEAVY,
  KIND_BUSINESS,
  KIND_LIGHT,
  KIND_HELICOPTER
};

struct Aircraft {
  char callsign[12] = {};
  char hex[10] = {};
  char registration[18] = {};
  char type[10] = {};
  char operatorName[34] = {};
  char squawk[7] = {};
  float lat = 0;
  float lon = 0;
  int altitudeFt = 0;
  int speedKt = 0;
  int headingDeg = 0;
  int verticalFpm = 0;
  float distanceKm = 0;
  float bearingDeg = 0;
  AircraftKind kind = KIND_AIRLINER;
};

struct PlaneSlot {
  lv_obj_t *root = nullptr;
  lv_obj_t *icon = nullptr;
  lv_obj_t *label = nullptr;
  int aircraftIndex = -1;
};

// ArduinoJson 7 allocator: ADS-B responses can contain many aircraft. Keep
// their filtered JSON tree in PSRAM so TLS retains contiguous internal RAM.
struct SpiRamJsonAllocator : ArduinoJson::Allocator {
  void *allocate(size_t size) override {
    return heap_caps_malloc(size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  }
  void deallocate(void *pointer) override {
    heap_caps_free(pointer);
  }
  void *reallocate(void *pointer, size_t newSize) override {
    return heap_caps_realloc(pointer, newSize,
                             MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  }
};

Board *gBoard = nullptr;
SemaphoreHandle_t gDataMutex = nullptr;
TaskHandle_t gNetworkTask = nullptr;

lv_obj_t *gMapImage = nullptr;
lv_obj_t *gMapPlaceholder = nullptr;
lv_obj_t *gPlaneLayer = nullptr;
lv_obj_t *gHomeMarker = nullptr;
lv_obj_t *gRouteLabel = nullptr;
lv_obj_t *gRouteFill = nullptr;
lv_obj_t *gRoutePlane = nullptr;
lv_obj_t *gOriginCodeLabel = nullptr;
lv_obj_t *gDestinationCodeLabel = nullptr;
lv_obj_t *gOriginNameLabel = nullptr;
lv_obj_t *gDestinationNameLabel = nullptr;
lv_obj_t *gPhotoLabel = nullptr;
lv_obj_t *gPhotoImage = nullptr;
lv_obj_t *gPhotoFrame = nullptr;
lv_obj_t *gPhotoOriginBadge = nullptr;
lv_obj_t *gWifiArcs[3] = {nullptr, nullptr, nullptr};
lv_obj_t *gWifiDot = nullptr;
lv_obj_t *gWifiRssiLabel = nullptr;
lv_obj_t *gRangeLabel = nullptr;
lv_obj_t *gClockLabel = nullptr;
lv_obj_t *gCountLabel = nullptr;
lv_obj_t *gStatusPanel = nullptr;
lv_obj_t *gStatusLabel = nullptr;
lv_obj_t *gDetailPanel = nullptr;
lv_obj_t *gCompanyLabel = nullptr;
lv_obj_t *gDepartureTimeLabel = nullptr;
lv_obj_t *gArrivalTimeLabel = nullptr;
char gDetailDepartureTime[76] = {};
char gDetailArrivalTime[76] = {};
volatile bool gArrivalHasScheduleTime = false;
volatile bool gDepartureHasScheduleTime = false;
char gRouteProvider[40] = {};
PlaneSlot gPlaneSlots[MAX_VISIBLE_AIRCRAFT];

uint16_t *gMapBuffer[2] = {nullptr, nullptr};
// Pan displacement of the full image from its downloaded geographic anchor.
// This remains in force after lifting the finger, until new imagery arrives.
int gMapShiftX = 0, gMapShiftY = 0;
double gMapAnchorLat = 0.0, gMapAnchorLon = 0.0;
struct MapSnapshotKey {
  bool valid = false;
  double lat = 0, lon = 0;
  float range = 0;
};
MapSnapshotKey gMapSnapshotKeys[2];
uint16_t *gDecodeTarget = nullptr;
int gMapActiveIndex = -1;
lv_image_dsc_t gMapDescriptor = {};
volatile int gMapPendingIndex = -1;
volatile bool gMapPublishPending = false;
volatile uint32_t gMapPendingSerial = 0;
volatile float gMapPendingRange = DEFAULT_RANGE_KM;
volatile double gPendingLatitude = 0.0, gPendingLongitude = 0.0;

Aircraft gAircraft[MAX_AIRCRAFT];
int gAircraftCount = 0;
volatile bool gAircraftPublishPending = false;

volatile bool gMainScreenActive = false;
volatile bool gNetworkEnabled = false;
volatile bool gNetworkBusy = false;
volatile bool gMapRequested = false;
volatile bool gAircraftRequested = false;
volatile bool gSettingsRequested = false;
volatile bool gCloseDetailRequested = false;
volatile int gDetailSlotRequested = -1;
volatile int gZoomStepsRequested = 0;
volatile bool gHomeRequested = false;
volatile bool gGestureActive = false;
volatile bool gDetailLookupRequested = false;
volatile bool gDetailLookupReady = false;
char gDetailLookupHex[12] = {};
char gDetailLookupCallsign[16] = {};
char gDetailLookupRegistration[18] = {};
char gDetailLookupModel[48] = {};
char gDetailLookupOperator[48] = {};
char gDetailAirline[96] = {};
char gDetailOrigin[160] = {};
char gDetailOriginCode[8] = {};
char gDetailDestinationCode[8] = {};
char gDetailDestination[160] = {};
char gSelectedAircraftHex[12] = {};
char gSelectedAircraftCallsign[16] = {};
double gAirportOriginLat = 0.0, gAirportOriginLon = 0.0;
double gAirportDestLat = 0.0, gAirportDestLon = 0.0;
volatile bool gRouteCoordinatesValid = false;
char gDetailPhotoUrl[768] = {};
enum class PhotoOrigin : uint8_t { NONE, SD, INTERNET, BUNDLED };
PhotoOrigin gPhotoOrigin = PhotoOrigin::NONE;
char gPhotoSource[100] = {};
char gPhotoPhotographer[90] = {};
char gPhotoPageUrl[240] = {};
char gPhotoId[28] = {};
char gDetailLookupType[10] = {};
uint16_t *gPhotoPixels = nullptr;
uint16_t gPhotoWidth = 0, gPhotoHeight = 0;
int gPhotoOffsetX = 0, gPhotoOffsetY = 0;
lv_image_dsc_t gPhotoDescriptor = {};
constexpr int PHOTO_W = 300, PHOTO_H = 156;
constexpr size_t MAX_PHOTO_JPEG_BYTES = 450000;
// These 1280px source JPEGs can be up to ~810 KB in the supplied SD archive.
constexpr size_t SD_PHOTO_MAX_BYTES = 950000;
constexpr char SD_PHOTO_ROOT[] = "/foto_compagnie_aeree";
bool gSDMounted = false;
uint32_t gLastSDMountAttemptMs = 0;


int gPreviewDx = 0, gPreviewDy = 0;
uint32_t gLastZoomClickMs = 0;
constexpr uint32_t ZOOM_CLICK_GUARD_MS = 320;
constexpr uint32_t MAP_SETTLE_MS = 240;

// Navigation centre is separate from the configured home location.
double gViewLatitude = 0.0, gViewLongitude = 0.0;
double gDisplayedLatitude = 0.0, gDisplayedLongitude = 0.0;
volatile bool gSuppressPlaneClick = false;

float gRequestedRangeKm = DEFAULT_RANGE_KM;
float gDisplayedRangeKm = DEFAULT_RANGE_KM;
int gRangePresetIndex = 3;
volatile uint32_t gMapRequestSerial = 1;
uint32_t gLastAircraftRequestMs = 0;
uint32_t gLastClockMs = 0;
volatile uint32_t gNextMapAttemptMs = 0;
volatile uint32_t gNextAircraftAttemptMs = 0;
volatile uint32_t gNetworkPauseUntilMs = 0;

char gPendingStatus[112] = {};
volatile bool gStatusPublishPending = false;

static const lv_font_t *fontSmall() {
#if LV_FONT_MONTSERRAT_10
  return &lv_font_montserrat_10;
#elif LV_FONT_MONTSERRAT_12
  return &lv_font_montserrat_12;
#else
  return LV_FONT_DEFAULT;
#endif
}

static const lv_font_t *fontNormal() {
#if LV_FONT_MONTSERRAT_14
  return &lv_font_montserrat_14;
#elif LV_FONT_MONTSERRAT_12
  return &lv_font_montserrat_12;
#else
  return LV_FONT_DEFAULT;
#endif
}

static const lv_font_t *fontMedium() {
#if LV_FONT_MONTSERRAT_16
  return &lv_font_montserrat_16;
#elif LV_FONT_MONTSERRAT_14
  return &lv_font_montserrat_14;
#else
  return LV_FONT_DEFAULT;
#endif
}

static const lv_font_t *fontLarge() {
#if LV_FONT_MONTSERRAT_20
  return &lv_font_montserrat_20;
#elif LV_FONT_MONTSERRAT_18
  return &lv_font_montserrat_18;
#elif LV_FONT_MONTSERRAT_16
  return &lv_font_montserrat_16;
#else
  return LV_FONT_DEFAULT;
#endif
}

static float degToRad(float value) {
  return value * (float)PI / 180.0f;
}

static void copyText(char *destination, size_t capacity,
                     const char *source) {
  if (!destination || capacity == 0) return;
  strlcpy(destination, source ? source : "", capacity);
}

static lv_obj_t *makeLabel(lv_obj_t *parent, const char *text, int x, int y,
                           int width, const lv_font_t *font,
                           uint32_t color = C_TEXT) {
  lv_obj_t *label = lv_label_create(parent);
  lv_label_set_text(label, text ? text : "");
  lv_obj_set_pos(label, x, y);
  lv_obj_set_width(label, width);
  lv_label_set_long_mode(label, LV_LABEL_LONG_DOT);
  lv_obj_set_style_text_font(label, font, 0);
  lv_obj_set_style_text_color(label, lv_color_hex(color), 0);
  lv_obj_clear_flag(label, LV_OBJ_FLAG_SCROLLABLE);
  return label;
}

static lv_obj_t *makePanel(lv_obj_t *parent, int x, int y, int w, int h) {
  lv_obj_t *panel = lv_obj_create(parent);
  lv_obj_set_pos(panel, x, y);
  lv_obj_set_size(panel, w, h);
  lv_obj_set_style_pad_all(panel, 0, 0);
  lv_obj_set_style_radius(panel, 8, 0);
  lv_obj_set_style_bg_color(panel, lv_color_hex(C_PANEL), 0);
  lv_obj_set_style_bg_opa(panel, LV_OPA_90, 0);
  lv_obj_set_style_border_color(panel, lv_color_hex(0x1D5360), 0);
  lv_obj_set_style_border_width(panel, 1, 0);
  lv_obj_clear_flag(panel, LV_OBJ_FLAG_SCROLLABLE);
  return panel;
}

static lv_obj_t *makeButton(lv_obj_t *parent, const char *text, int x, int y,
                            int w, int h, lv_event_cb_t callback,
                            void *userData = nullptr) {
  lv_obj_t *button = lv_button_create(parent);
  lv_obj_set_pos(button, x, y);
  lv_obj_set_size(button, w, h);
  lv_obj_set_style_pad_all(button, 0, 0);
  lv_obj_set_style_radius(button, 8, 0);
  lv_obj_set_style_bg_color(button, lv_color_hex(C_PANEL_2), 0);
  lv_obj_set_style_border_color(button, lv_color_hex(C_CYAN), 0);
  lv_obj_set_style_border_width(button, 1, 0);
  lv_obj_clear_flag(button, LV_OBJ_FLAG_SCROLLABLE);
  if (callback)
    lv_obj_add_event_cb(button, callback, LV_EVENT_CLICKED, userData);
  lv_obj_t *label = lv_label_create(button);
  lv_label_set_text(label, text);
  lv_obj_set_style_text_font(label, fontLarge(), 0);
  lv_obj_set_style_text_color(label, lv_color_hex(C_CYAN), 0);
  lv_obj_clear_flag(label, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_center(label);
  return button;
}

static lv_obj_t *shapeRect(lv_obj_t *parent, int x, int y, int w, int h,
                           uint32_t color, int radius = 1) {
  lv_obj_t *shape = lv_obj_create(parent);
  lv_obj_set_pos(shape, x, y);
  lv_obj_set_size(shape, w, h);
  lv_obj_set_style_pad_all(shape, 0, 0);
  lv_obj_set_style_border_width(shape, 0, 0);
  lv_obj_set_style_radius(shape, radius, 0);
  lv_obj_set_style_bg_color(shape, lv_color_hex(color), 0);
  lv_obj_set_style_bg_opa(shape, LV_OPA_COVER, 0);
  lv_obj_clear_flag(shape, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(shape, LV_OBJ_FLAG_CLICKABLE);
  return shape;
}

static void setStatusLocked(const char *text) {
  if (!gStatusPanel || !gStatusLabel) return;
  if (!text || !text[0]) {
    lv_obj_add_flag(gStatusPanel, LV_OBJ_FLAG_HIDDEN);
    return;
  }
  lv_label_set_text(gStatusLabel, text);
  lv_obj_clear_flag(gStatusPanel, LV_OBJ_FLAG_HIDDEN);
}

static void postStatus(const char *text) {
  if (!gDataMutex) return;
  xSemaphoreTake(gDataMutex, portMAX_DELAY);
  copyText(gPendingStatus, sizeof(gPendingStatus), text);
  gStatusPublishPending = true;
  xSemaphoreGive(gDataMutex);
}

static void zoomEvent(lv_event_t *event) {
  const int direction = (int)(intptr_t)lv_event_get_user_data(event);
  // A single physical press must never auto-repeat or skip presets.
  const uint32_t now = millis();
  if (now - gLastZoomClickMs < ZOOM_CLICK_GUARD_MS) return;
  gLastZoomClickMs = now;
  gZoomStepsRequested = direction;
}

static void updateHomeMarkerLocked() {
  if (!gHomeMarker) return;
  const float lat = (float)gDisplayedLatitude;
  const float kmPerPx = 2.0f * gDisplayedRangeKm / SCREEN_HEIGHT;
  if (kmPerPx <= 0) return;
  const float east = (cmLongitude() - gDisplayedLongitude) * 111.12f * cosf(degToRad(lat));
  const float north = (cmLatitude() - gDisplayedLatitude) * 111.12f;
  int x = lroundf(SCREEN_WIDTH * 0.5f + east / kmPerPx);
  int y = lroundf(SCREEN_HEIGHT * 0.5f - north / kmPerPx);
  lv_obj_set_pos(gHomeMarker, x - 6, y - 6);
  if (x < 0 || x >= SCREEN_WIDTH || y < 58 || y >= 429)
    lv_obj_add_flag(gHomeMarker, LV_OBJ_FLAG_HIDDEN);
  else lv_obj_remove_flag(gHomeMarker, LV_OBJ_FLAG_HIDDEN);
}

static void homeEvent(lv_event_t *) {
  gHomeRequested = true;
}

static void settingsEvent(lv_event_t *) {
  gSettingsRequested = true;
}

static void closeDetailEvent(lv_event_t *) {
  gCloseDetailRequested = true;
}

static void planeEvent(lv_event_t *event) {
  if (gSuppressPlaneClick) return;
  gDetailSlotRequested =
      (int)(intptr_t)lv_event_get_user_data(event);
}

// Raw GT911 samples are delivered in LVGL task context. Never perform
// HTTP or LVGL redraw work from this callback.
static void drawAircraftLocked(float displayRange);

static void mapTouchGesture(uint8_t count, int16_t x0, int16_t y0,
                            int16_t x1, int16_t y1) {
  static uint8_t mode = 0; // 0 idle, 1 drag, 2 pinch, 3 UI
  static int16_t startX = 0, startY = 0;
  static int dragX = 0, dragY = 0;
  static float pinchStart = 0;
  static int pinchSteps = 0;
  if (!gMainScreenActive || gDetailPanel) {
    mode = 0;
    gGestureActive = false;
    return;
  }
  if (count == 0) {
    if (mode == 1 && gMapActiveIndex >= 0 &&
        (abs(dragX) > 12 || abs(dragY) > 12)) {
      // Geography must be computed from the *bitmap anchor*, not from the
      // current viewport: several small drags must accumulate correctly.
      const int requestedShiftX = gMapShiftX + dragX;
      const int requestedShiftY = gMapShiftY + dragY;
      const double kmPerPx = (double)gDisplayedRangeKm * 2.0 / SCREEN_HEIGHT;
      const double lat = gMapAnchorLat + requestedShiftY * kmPerPx / 111.12;
      const double cosLat = fmax(0.08, fabs(cos(degToRad((float)gMapAnchorLat))));
      const double lon = gMapAnchorLon - requestedShiftX * kmPerPx / (111.12 * cosLat);
      gViewLatitude = constrain(lat, -84.0, 84.0);
      gViewLongitude = constrain(lon, -179.9, 179.9);
      gDisplayedLatitude = gViewLatitude;
      gDisplayedLongitude = gViewLongitude;

      // Any old download in flight refers to an obsolete centre.
      ++gMapRequestSerial;
      const bool canReuse = gMapActiveIndex >= 0 &&
          fabsf(gRequestedRangeKm - gDisplayedRangeKm) < 0.05f &&
          abs(requestedShiftX) <= MAP_SAFE_X &&
          abs(requestedShiftY) <= MAP_SAFE_Y;
      gMapShiftX = constrain(requestedShiftX, -MAP_MARGIN_X, MAP_MARGIN_X);
      gMapShiftY = constrain(requestedShiftY, -MAP_MARGIN_Y, MAP_MARGIN_Y);
      if (gMapImage)
        lv_obj_set_pos(gMapImage, -MAP_MARGIN_X + gMapShiftX,
                      -MAP_MARGIN_Y + gMapShiftY);
      if (gPlaneLayer) lv_obj_set_pos(gPlaneLayer, 0, 0);
      drawAircraftLocked(gDisplayedRangeKm);
      updateHomeMarkerLocked();
      if (canReuse) {
        gMapRequested = false;
        Serial.printf("MAP: RAM overscan hit, dx=%d dy=%d (NO HTTP)\n",
                      gMapShiftX, gMapShiftY);
      } else {
        gMapRequested = true;
        gNextMapAttemptMs = millis() + MAP_SETTLE_MS;
        Serial.printf("MAP: edge reached, request new image (%d,%d)\n",
                      requestedShiftX, requestedShiftY);
      }
      gAircraftRequested = true;
      gNextAircraftAttemptMs = millis() + MAP_SETTLE_MS;
    } else if (mode == 2 && pinchSteps != 0) {
      gZoomStepsRequested = constrain(pinchSteps, -2, 2);
    } else if (mode == 1) {
      // A tap is not a pan: restore the previous bitmap position.
      if (gMapImage)
        lv_obj_set_pos(gMapImage, -MAP_MARGIN_X + gMapShiftX,
                      -MAP_MARGIN_Y + gMapShiftY);
      if (gPlaneLayer) lv_obj_set_pos(gPlaneLayer, 0, 0);
      updateHomeMarkerLocked();
    }
    gGestureActive = false;
    mode = 0;
    dragX = dragY = 0;
    return;
  }
  if (count >= 2) {
    const float distance = hypotf((float)x1 - x0, (float)y1 - y0);
    if (mode != 2) {
      mode = 2;
      pinchStart = fmaxf(distance, 1.0f);
      pinchSteps = 0;
      if (gMapImage)
        lv_obj_set_pos(gMapImage, -MAP_MARGIN_X + gMapShiftX,
                      -MAP_MARGIN_Y + gMapShiftY);
      if (gPlaneLayer) lv_obj_set_pos(gPlaneLayer, 0, 0);
      updateHomeMarkerLocked();
    } else {
      const float ratio = distance / pinchStart;
      pinchSteps = ratio > 1.30f ? -1 : (ratio < 0.77f ? 1 : 0);
      if (ratio > 1.8f) pinchSteps = -2;
      if (ratio < 0.56f) pinchSteps = 2;
    }
    gGestureActive = true;
    gSuppressPlaneClick = true;
    return;
  }
  if (mode == 2) return;
  if (mode == 0) {
    gSuppressPlaneClick = false;
    startX = x0; startY = y0;
    dragX = dragY = 0;
    mode = (y0 < 58 || y0 > 425) ? 3 : 1;
  } else if (mode == 1) {
    dragX = constrain((int)x0 - startX, -260, 260);
    dragY = constrain((int)y0 - startY, -170, 170);
    if (abs(dragX) > 10 || abs(dragY) > 10) {
      gGestureActive = true;
      gSuppressPlaneClick = true;
      // Restore immediate visual feedback during dragging (v5.8.9 behavior).
      // Reuse the cached image; network work is still scheduled on release.
      const int shiftX = constrain(gMapShiftX + dragX, -MAP_MARGIN_X, MAP_MARGIN_X);
      const int shiftY = constrain(gMapShiftY + dragY, -MAP_MARGIN_Y, MAP_MARGIN_Y);
      if (gMapImage)
        lv_obj_set_pos(gMapImage, -MAP_MARGIN_X + shiftX,
                      -MAP_MARGIN_Y + shiftY);
      if (gPlaneLayer) lv_obj_set_pos(gPlaneLayer, dragX, dragY);
      if (gHomeMarker) {
        updateHomeMarkerLocked();
        lv_obj_set_pos(gHomeMarker, lv_obj_get_x(gHomeMarker) + dragX,
                       lv_obj_get_y(gHomeMarker) + dragY);
      }
      gPreviewDx = dragX;
      gPreviewDy = dragY;
    }
  }
}

static bool allocateMapBuffers() {
  if (gMapBuffer[0] && gMapBuffer[1]) return true;
  for (int i = 0; i < 2; ++i) {
    if (!gMapBuffer[i]) {
      gMapBuffer[i] = static_cast<uint16_t *>(heap_caps_malloc(
          MAP_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    }
    if (!gMapBuffer[i]) {
      for (int j = 0; j < 2; ++j) {
        if (gMapBuffer[j]) heap_caps_free(gMapBuffer[j]);
        gMapBuffer[j] = nullptr;
      }
      Serial.printf("MAP: PSRAM allocation failed, free=%u\n",
                    (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
      return false;
    }
  }
  Serial.printf("MAP: 2 buffers x %u bytes, PSRAM free=%u\n",
                (unsigned)MAP_BYTES,
                (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
  return true;
}

static void initMapDescriptor(const uint16_t *pixels) {
  memset(&gMapDescriptor, 0, sizeof(gMapDescriptor));
  gMapDescriptor.header.magic = LV_IMAGE_HEADER_MAGIC;
  gMapDescriptor.header.cf = LV_COLOR_FORMAT_RGB565;
  gMapDescriptor.header.flags = 0;
  gMapDescriptor.header.w = MAP_WIDTH;
  gMapDescriptor.header.h = MAP_HEIGHT;
  gMapDescriptor.header.stride = MAP_WIDTH * sizeof(uint16_t);
  gMapDescriptor.data_size = MAP_BYTES;
  gMapDescriptor.data = reinterpret_cast<const uint8_t *>(pixels);
}

static bool mapJpegBlock(int16_t x, int16_t y, uint16_t w, uint16_t h,
                         uint16_t *bitmap) {
  if (!gDecodeTarget || !bitmap) return false;
  for (uint16_t row = 0; row < h; ++row) {
    const int yy = y + row;
    if (yy < 0 || yy >= MAP_HEIGHT) continue;
    int targetX = x;
    int sourceX = 0;
    int count = w;
    if (targetX < 0) {
      sourceX = -targetX;
      count -= sourceX;
      targetX = 0;
    }
    if (targetX + count > MAP_WIDTH)
      count = MAP_WIDTH - targetX;
    if (count <= 0) continue;
    memcpy(gDecodeTarget + (size_t)yy * MAP_WIDTH + targetX,
           bitmap + (size_t)row * w + sourceX,
           (size_t)count * sizeof(uint16_t));
  }
  return true;
}

static String buildMapUrl(double latitude, double longitude,
                          float rangeKm) {
  constexpr double earthRadius = 6378137.0;
  latitude = constrain(latitude, -85.0, 85.0);
  longitude = constrain(longitude, -180.0, 180.0);
  const double latRad = latitude * PI / 180.0;
  const double centerX = earthRadius * longitude * PI / 180.0;
  const double centerY =
      earthRadius * log(tan(PI / 4.0 + latRad / 2.0));
  const double cosLat = max(0.08, fabs(cos(latRad)));
  // Same metres-per-pixel as the 800x480 radar.  Extra pixels provide
  // about 112px of geographic overscan on each side.
  const double halfGroundY = rangeKm * 1000.0 * MAP_HEIGHT / SCREEN_HEIGHT;
  const double halfGroundX = rangeKm * 1000.0 * MAP_WIDTH / SCREEN_HEIGHT;
  const double halfX = halfGroundX / cosLat;
  const double halfY = halfGroundY / cosLat;

  String url =
      "https://server.arcgisonline.com/ArcGIS/rest/services/"
      "World_Imagery/MapServer/export?bbox=";
  url += String(centerX - halfX, 2); url += "%2C";
  url += String(centerY - halfY, 2); url += "%2C";
  url += String(centerX + halfX, 2); url += "%2C";
  url += String(centerY + halfY, 2);
  url += "&bboxSR=3857&imageSR=3857&size=";
  url += String(MAP_WIDTH); url += "%2C"; url += String(MAP_HEIGHT);
  url += "&format=jpg&transparent=false&dpi=96&f=image";
  return url;
}

static bool mapCacheLoad(int targetIndex, double latitude,
                         double longitude, float rangeKm);
static void mapCacheSave(const uint8_t *jpeg, size_t bytes,
                         double latitude, double longitude, float rangeKm);

static bool decodeMapInto(int targetIndex, const uint8_t *jpeg, size_t length) {
  uint16_t width = 0, height = 0;
  if (!jpeg || length < 1000 ||
      TJpgDec.getJpgSize(&width, &height, jpeg, length) != 0 ||
      width != MAP_WIDTH || height != MAP_HEIGHT) {
    Serial.printf("MAP: invalid JPEG size %ux%u\n", width, height);
    return false;
  }
  gDecodeTarget = gMapBuffer[targetIndex];
  TJpgDec.setJpgScale(1);
  TJpgDec.setSwapBytes(false);
  TJpgDec.setCallback(mapJpegBlock);
  const bool decoded = TJpgDec.drawJpg(0, 0, jpeg, length) == 0;
  gDecodeTarget = nullptr;
  return decoded;
}

static bool downloadMapInto(int targetIndex, double latitude,
                            double longitude, float rangeKm) {
  if (targetIndex < 0 || targetIndex > 1 || !gMapBuffer[targetIndex])
    return false;

  // Cache reader is available for correctly licensed, preloaded map JPEGs.
  // The normal Esri online source is not persisted without authorization.
  if (mapCacheLoad(targetIndex, latitude, longitude, rangeKm)) return true;
  postStatus("Downloading satellite map...");
  uint8_t *jpeg = static_cast<uint8_t *>(heap_caps_malloc(
      MAX_MAP_JPEG_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!jpeg) {
    postStatus("Insufficient PSRAM for map");
    return false;
  }

  WiFiClientSecure client;
  client.setInsecure();
  client.setHandshakeTimeout(15);
  client.setTimeout(25000);
  HTTPClient http;
  http.setTimeout(25000);
  http.useHTTP10(true);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);

  const String url = buildMapUrl(latitude, longitude, rangeKm);
  if (!http.begin(client, url)) {
    heap_caps_free(jpeg);
    postStatus("Map service connection failed");
    return false;
  }
  http.addHeader("Accept", "image/jpeg,image/*");
  http.addHeader("Accept-Encoding", "identity");
  http.addHeader("User-Agent", "FlyRadar-Waveshare7/5.8.8");

  Serial.printf("MAP: request %s\n", url);
  const int code = http.GET();
  if (code != HTTP_CODE_OK) {
    Serial.printf("MAP: HTTP %d\n", code);
    http.end();
    heap_caps_free(jpeg);
    postStatus("Map temporarily unavailable");
    return false;
  }

  const int announced = http.getSize();
  if (announced > (int)MAX_MAP_JPEG_BYTES) {
    http.end();
    heap_caps_free(jpeg);
    postStatus("Map image too large");
    return false;
  }

  WiFiClient *stream = http.getStreamPtr();
  size_t total = 0;
  uint32_t lastData = millis();
  while ((announced < 0 || total < (size_t)announced) &&
         total < MAX_MAP_JPEG_BYTES && millis() - lastData < 25000UL) {
    const size_t available = stream->available();
    if (available) {
      size_t wanted = min(available, MAX_MAP_JPEG_BYTES - total);
      if (announced >= 0)
        wanted = min(wanted, (size_t)announced - total);
      const int received = stream->readBytes(jpeg + total, wanted);
      if (received > 0) {
        total += received;
        lastData = millis();
      }
    } else {
      if (announced < 0 && !http.connected()) break;
      vTaskDelay(pdMS_TO_TICKS(1));
    }
  }
  http.end();

  const bool complete =
      total >= 1000 && jpeg[0] == 0xFF && jpeg[1] == 0xD8 &&
      (announced < 0 || total == (size_t)announced);
  if (!complete) {
    Serial.printf("MAP: incomplete JPEG, expected=%d received=%u\n",
                  announced, (unsigned)total);
    heap_caps_free(jpeg);
    postStatus("Map download incomplete: retrying");
    return false;
  }

  const bool decoded = decodeMapInto(targetIndex, jpeg, total);
  if (decoded) mapCacheSave(jpeg, total, latitude, longitude, rangeKm);
  heap_caps_free(jpeg);
  if (!decoded) {
    postStatus("Map decoding failed");
    return false;
  }
  Serial.printf("MAP: ready, range=%.0f km target=%d JPEG=%u bytes\n",
                rangeKm, targetIndex, (unsigned)total);
  return true;
}

static int parseAltitude(JsonVariantConst value) {
  if (value.is<int>()) return value.as<int>();
  if (value.is<float>()) return lroundf(value.as<float>());
  if (value.is<const char *>()) {
    const char *text = value.as<const char *>();
    if (!text || !text[0] || !strcmp(text, "ground")) return 0;
    return atoi(text);
  }
  return 0;
}

static AircraftKind classifyAircraft(const char *type) {
  String t = type ? type : "";
  t.toUpperCase();
  if (t.startsWith("H") || t.startsWith("R22") ||
      t.startsWith("R44") || t.startsWith("EC") ||
      t.startsWith("AS3")) return KIND_HELICOPTER;
  if (t.startsWith("A38") || t.startsWith("B74") ||
      t.startsWith("B77") || t.startsWith("A34")) return KIND_HEAVY;
  if (t.startsWith("C5") || t.startsWith("C6") ||
      t.startsWith("LJ") || t.startsWith("GLF") ||
      t.startsWith("E50")) return KIND_BUSINESS;
  if (t.startsWith("C1") || t.startsWith("C2") ||
      t.startsWith("PA") || t.startsWith("P2") ||
      t.startsWith("DA") || t.startsWith("SR")) return KIND_LIGHT;
  return KIND_AIRLINER;
}

static void calculateAircraftGeometry(Aircraft &aircraft) {
  const float centerLat = (float)gDisplayedLatitude;
  const float northKm = (aircraft.lat - centerLat) * 111.12f;
  const float eastKm = (aircraft.lon - (float)gDisplayedLongitude) *
                       111.12f * cosf(degToRad(centerLat));
  aircraft.distanceKm = sqrtf(northKm * northKm + eastKm * eastKm);
  aircraft.bearingDeg = atan2f(eastKm, northKm) * 180.0f / PI;
  if (aircraft.bearingDeg < 0) aircraft.bearingDeg += 360.0f;
}

static void sortAircraftByDistance(Aircraft *list, int count) {
  for (int i = 1; i < count; ++i) {
    Aircraft value = list[i];
    int j = i - 1;
    while (j >= 0 && list[j].distanceKm > value.distanceKm) {
      list[j + 1] = list[j];
      --j;
    }
    list[j + 1] = value;
  }
}

static bool fetchAircraftData(float rangeKm) {
  postStatus("Updating air traffic...");
  // adsb.fi accepts only 250 NM per single query. Wider maps show partial
  // live coverage until multi-region aggregation is implemented.
  const int radiusNm = constrain(
      (int)ceilf(rangeKm * CORNER_FACTOR / 1.852f), 1, 250);
  char url[220];
  snprintf(url, sizeof(url),
           "https://opendata.adsb.fi/api/v3/lat/%.6f/lon/%.6f/dist/%d",
           gViewLatitude, gViewLongitude, radiusNm);

  AdsbTlsClient client;
  client.setInsecure();
  client.setHandshakeTimeout(15);
  client.setTimeout(30000);
  HTTPClient http;
  http.setTimeout(30000);
  http.useHTTP10(true);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  if (!http.begin(client, url)) {
    postStatus("ADS-B connection failed: retrying");
    return false;
  }
  const char *headers[] = {"Content-Type", "Content-Encoding", "Transfer-Encoding"};
  http.collectHeaders(headers, 3);
  http.addHeader("Accept", "application/json");
  http.addHeader("Accept-Encoding", "identity");
  http.addHeader("User-Agent", "FlyRadar-Waveshare7/" FLYRADAR_VERSION);

  const int code = http.GET();
  if (code != HTTP_CODE_OK) {
    Serial.printf("ADSB: HTTP %d\n", code);
    http.end();
    postStatus(code == 429 ? "ADS-B rate limit: waiting to retry"
                           : "ADS-B traffic temporarily unavailable");
    return false;
  }

  const int expected = http.getSize();
  const String encoding = http.header("Content-Encoding");
  const String contentType = http.header("Content-Type");
  Serial.printf("ADSB: HTTP=%d expected=%d type=%s transfer=%s encoding=%s RSSI=%d\n",
                code, expected, contentType.c_str(),
                http.header("Transfer-Encoding").c_str(), encoding.c_str(), WiFi.RSSI());
  if (expected > (int)AdsbBody::MAX_BYTES ||
      (encoding.length() && !encoding.equalsIgnoreCase("identity"))) {
    http.end();
    postStatus("Unsupported ADS-B response: retrying");
    return false;
  }

  // Finish the HTTP transfer before parsing. HTTPClient removes chunk framing;
  // AdsbTlsClient waits through TLS gaps instead of reporting premature EOF.
  AdsbBody body;
  client.beginBody();
  const uint32_t downloadStarted = millis();
  const int downloaded = http.writeToStream(&body);
  const bool timedOut = client.timedOut;
  http.end();  // Free TLS memory before allocating the filtered JSON tree.
  Serial.printf("ADSB: body received=%u expected=%d result=%d elapsed=%lu ms timeout=%d\n",
                (unsigned)body.length, expected, downloaded,
                (unsigned long)(millis() - downloadStarted), (int)timedOut);
  if (downloaded <= 0 || timedOut || body.failed || !body.length ||
      downloaded != (int)body.length ||
      (expected >= 0 && body.length != (size_t)expected)) {
    postStatus("Incomplete ADS-B data: automatic retry scheduled");
    return false;
  }

  // Retain the same fields and aircraft filtering as v5.9.2.
  JsonDocument filter;
  filter["ac"][0]["lat"] = true;
  filter["ac"][0]["lon"] = true;
  filter["ac"][0]["flight"] = true;
  filter["ac"][0]["hex"] = true;
  filter["ac"][0]["r"] = true;
  filter["ac"][0]["t"] = true;
  filter["ac"][0]["ownOp"] = true;
  filter["ac"][0]["alt_baro"] = true;
  filter["ac"][0]["alt_geom"] = true;
  filter["ac"][0]["gs"] = true;
  filter["ac"][0]["track"] = true;
  filter["ac"][0]["true_heading"] = true;
  filter["ac"][0]["baro_rate"] = true;
  filter["ac"][0]["squawk"] = true;
  filter["total"] = true;

  SpiRamJsonAllocator jsonAllocator;
  JsonDocument document(&jsonAllocator);
  DeserializationError error = deserializeJson(
      document, static_cast<const uint8_t *>(body.data), body.length,
      DeserializationOption::Filter(filter));
  if (error) {
    Serial.printf("ADSB: JSON error=%s\n", error.c_str());
    postStatus("Incomplete ADS-B data: automatic retry scheduled");
    return false;
  }

  JsonArrayConst items = document["ac"].as<JsonArrayConst>();
  if (items.isNull()) {
    Serial.println("ADSB: response has no 'ac' array");
    postStatus("Unexpected ADS-B format: automatic retry scheduled");
    return false;
  }

  Aircraft *fresh = static_cast<Aircraft *>(heap_caps_malloc(
      sizeof(Aircraft) * MAX_AIRCRAFT,
      MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!fresh) {
    postStatus("Insufficient PSRAM for ADS-B data");
    return false;
  }
  int count = 0;
  for (JsonObjectConst item : items) {
    if (count >= MAX_AIRCRAFT || item["lat"].isNull() ||
        item["lon"].isNull()) continue;

    int altitude = parseAltitude(item["alt_baro"]);
    if (!altitude) altitude = parseAltitude(item["alt_geom"]);
    if (altitude <= 0 || altitude < DEFAULT_MIN_ALTITUDE_FT ||
        altitude > 100000) continue;

    Aircraft &aircraft = fresh[count];
    aircraft = Aircraft{};
    aircraft.lat = item["lat"].as<float>();
    aircraft.lon = item["lon"].as<float>();
    if (!isfinite(aircraft.lat) || !isfinite(aircraft.lon) ||
        aircraft.lat < -90.0f || aircraft.lat > 90.0f ||
        aircraft.lon < -180.0f || aircraft.lon > 180.0f) continue;

    copyText(aircraft.callsign, sizeof(aircraft.callsign),
             item["flight"] | "");
    for (int i = (int)strlen(aircraft.callsign) - 1;
         i >= 0 && aircraft.callsign[i] == ' '; --i)
      aircraft.callsign[i] = 0;
    copyText(aircraft.hex, sizeof(aircraft.hex), item["hex"] | "");
    copyText(aircraft.registration, sizeof(aircraft.registration),
             item["r"] | "");
    copyText(aircraft.type, sizeof(aircraft.type), item["t"] | "");
    copyText(aircraft.operatorName, sizeof(aircraft.operatorName),
             item["ownOp"] | "");
    if (item["squawk"].is<const char *>())
      copyText(aircraft.squawk, sizeof(aircraft.squawk),
               item["squawk"].as<const char *>());
    else if (item["squawk"].is<int>())
      snprintf(aircraft.squawk, sizeof(aircraft.squawk), "%04d",
               item["squawk"].as<int>());

    aircraft.altitudeFt = altitude;
    aircraft.speedKt = lroundf(item["gs"] | 0.0f);
    aircraft.headingDeg = lroundf(
        item["track"] | (item["true_heading"] | 0.0f));
    aircraft.verticalFpm = lroundf(item["baro_rate"] | 0.0f);
    aircraft.kind = classifyAircraft(aircraft.type);
    calculateAircraftGeometry(aircraft);
    ++count;
  }

  sortAircraftByDistance(fresh, count);
  xSemaphoreTake(gDataMutex, portMAX_DELAY);
  memcpy(gAircraft, fresh, sizeof(Aircraft) * count);
  gAircraftCount = count;
  gAircraftPublishPending = true;
  xSemaphoreGive(gDataMutex);
  heap_caps_free(fresh);
  postStatus("");
  Serial.printf("ADSB: %d airborne aircraft, radius=%d NM\n",
                count, radiusNm);
  return true;
}


// Enrichment is optional: adsbdb can be unavailable or have no flight route.
static bool photoJpegBlock(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *bmp) {
  if (!gPhotoPixels || !bmp) return false;
  for (int row = 0; row < h; ++row) {
    const int dy = y + row + gPhotoOffsetY;
    if (dy < 0 || dy >= PHOTO_H) continue;
    int dx = x + gPhotoOffsetX;
    int srcX = 0;
    int copyW = (int)w;
    if (dx < 0) { srcX = -dx; copyW -= srcX; dx = 0; }
    if (dx + copyW > PHOTO_W) copyW = PHOTO_W - dx;
    if (copyW <= 0) continue;
    memcpy(gPhotoPixels + dy * PHOTO_W + dx, bmp + row * w + srcX, copyW * 2);
  }
  return true;
}

class PhotoBufferStream : public Stream {
public:
  uint8_t *buffer = nullptr;
  size_t length = 0, capacity = 0;
  explicit PhotoBufferStream(size_t maxBytes) : maximum(maxBytes) {}
  ~PhotoBufferStream() override { if (buffer) heap_caps_free(buffer); }
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  void flush() override {}
  size_t write(uint8_t c) override { return write(&c, 1); }
  size_t write(const uint8_t *p, size_t n) override {
    if (!p || !n || n > maximum - length) return 0;
    if (length + n > capacity) {
      size_t next = capacity ? capacity : 32768;
      while (next < length + n) next = min(maximum, next * 2);
      uint8_t *grown = (uint8_t *)heap_caps_realloc(buffer, next, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
      if (!grown) return 0;
      buffer = grown; capacity = next;
    }
    memcpy(buffer + length, p, n); length += n; return n;
  }
private:
  size_t maximum;
};

// Small, maintainable photo pipeline. All HTTPS and JPEG operations run on
// the network task; only publishDetailLookup() touches LVGL objects.
// No image is marked ready until the HTTP body AND JPEG decode succeeded.
static String photoUrlEncode(const String &input) {
  const char *hex = "0123456789ABCDEF";
  String out;
  out.reserve(input.length()*3);
  for(size_t i=0;i<input.length();++i) {
    const uint8_t ch=(uint8_t)input[i];
    if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') ||
       (ch >= '0' && ch <= '9') || ch=='-' || ch=='_' || ch=='.' || ch=='~') out += (char)ch;
    else { out += '%'; out += hex[ch>>4]; out += hex[ch&15]; }
  }
  return out;
}

// On the network worker only. All strings are copied out of the JSON
// BEFORE HTTPClient::end() and the JsonDocument are destroyed.
static bool validAirportCoords(double lat, double lon) {
  return isfinite(lat) && isfinite(lon) && fabs(lat) <= 90 && fabs(lon) <= 180;
}

static bool gOriginCoordKnown = false, gDestinationCoordKnown = false;
static void updateRouteCoordValidity() {
  if (gOriginCoordKnown && gDestinationCoordKnown &&
      (fabs(gAirportOriginLat-gAirportDestLat) +
       fabs(gAirportOriginLon-gAirportDestLon)) > 0.01)
    gRouteCoordinatesValid = true;
}

static void incorporateAirport(JsonVariantConst airport, bool origin,
                              bool fromLol = false) {
  if (airport.isNull()) return;
  char *code = origin ? gDetailOriginCode : gDetailDestinationCode;
  char *name = origin ? gDetailOrigin : gDetailDestination;
  const char *iata = fromLol ? (airport["iata"] | "") : (airport["iata_code"] | "");
  const char *icao = fromLol ? (airport["icao"] | "") : (airport["icao_code"] | "");
  const char *place = airport["name"] | "";
  if (!place[0]) place = fromLol ? (airport["location"] | "") : (airport["municipality"] | "");
  // Do not mix coordinates from a DIFFERENT route with airports already
  // named by the primary provider.
  if (code[0] && (iata[0] || icao[0]) &&
      (!iata[0] || strcmp(code, iata) != 0) &&
      (!icao[0] || strcmp(code, icao) != 0)) return;
  if (!code[0]) copyText(code, 8, iata[0] ? iata : icao);
  if (!name[0] && place[0]) {
    char formatted[160];
    snprintf(formatted, sizeof(formatted), "%.138s%s%.7s%s", place,
             code[0] ? " (" : "", code, code[0] ? ")" : "");
    copyText(name, origin ? sizeof(gDetailOrigin) : sizeof(gDetailDestination), formatted);
  }
  JsonVariantConst latField = fromLol ? airport["lat"] : airport["latitude"];
  JsonVariantConst lonField = fromLol ? airport["lon"] : airport["longitude"];
  if (!latField.isNull() && !lonField.isNull()) {
    const double lat = latField.as<double>(), lon = lonField.as<double>();
    if (validAirportCoords(lat, lon)) {
      if (origin) {
        if (!gOriginCoordKnown) { gAirportOriginLat = lat; gAirportOriginLon = lon; }
        gOriginCoordKnown = true;
      } else {
        if (!gDestinationCoordKnown) { gAirportDestLat = lat; gAirportDestLon = lon; }
        gDestinationCoordKnown = true;
      }
      updateRouteCoordValidity();
    }
  }
}

static void incorporateAdsbdbRoute(JsonVariantConst route, const char *provider,
                                  char *airline, size_t airlineSize) {
  if (route.isNull()) return;
  const char *verifiedName = route["airline"]["name"] | "";
  if (verifiedName[0]) copyText(airline, airlineSize, verifiedName);
  const bool before = (gDetailOrigin[0] && gDetailDestination[0]);
  incorporateAirport(route["origin"], true);
  incorporateAirport(route["destination"], false);
  if ((!before || !gRouteProvider[0]) && gDetailOrigin[0] && gDetailDestination[0])
    copyText(gRouteProvider, sizeof(gRouteProvider), provider);
}

// ADSBDB's combined aircraft/flight lookup sometimes knows the airframe but
// not the callsign route. A separate callsign query can still succeed.
static bool fetchAdsbdbByCallsign(const char *callsign, char *airline, size_t airlineSize) {
  if (!callsign || !callsign[0]) return false;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http; http.setTimeout(4800); http.useHTTP10(true);
  const String url = String("https://api.adsbdb.com/v0/callsign/") + photoUrlEncode(callsign);
  if (!http.begin(client, url)) return false;
  http.addHeader("Accept", "application/json");
  http.addHeader("Accept-Encoding", "identity");
  const int code = http.GET();
  Serial.printf("ROUTE: ADSBDB callsign HTTP=%d\n", code);
  if (code == 200) {
    JsonDocument doc;
    if (!deserializeJson(doc, http.getStream()))
      incorporateAdsbdbRoute(doc["response"]["flightroute"].as<JsonVariantConst>(),
                             "ADSBDB/callsign", airline, airlineSize);
  }
  http.end();
  return gDetailOrigin[0] && gDetailDestination[0];
}

// Independent fallback: documented POST /api/0/routeset of ADSB.lol.
// This is a crowd-sourced plausible route, NOT a verified flight plan.
static bool fetchAdsbLolRoute(const char *callsign, double latitude, double longitude) {
  if (!callsign || !callsign[0] || !validAirportCoords(latitude, longitude)) return false;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http; http.setTimeout(5300); http.useHTTP10(true);
  if (!http.begin(client, "https://api.adsb.lol/api/0/routeset")) return false;
  http.addHeader("Accept", "application/json");
  http.addHeader("Content-Type", "application/json");
  JsonDocument request;
  JsonArray planes = request["planes"].to<JsonArray>();
  JsonObject plane = planes.add<JsonObject>();
  plane["callsign"] = callsign;
  plane["lat"] = latitude;
  plane["lng"] = longitude;
  String body; serializeJson(request, body);
  const int code = http.POST(body);
  Serial.printf("ROUTE: ADSB.lol HTTP=%d\n", code);
  if (code == 200) {
    SpiRamJsonAllocator allocator;
    JsonDocument response(&allocator);
    if (!deserializeJson(response, http.getStream())) {
      JsonVariantConst obj = response[0].as<JsonVariantConst>();
      JsonArrayConst airports = obj["_airports"].as<JsonArrayConst>();
      if (!airports.isNull() && airports.size() >= 2 && airports.size() <= 3) {
        // Only use a two/three-leg response when matching requested callsign.
        const char *match = obj["callsign"] | "";
        if (!match[0] || String(match).equalsIgnoreCase(callsign)) {
          incorporateAirport(airports[0], true, true);
          incorporateAirport(airports[airports.size()-1], false, true);
          if (gDetailOrigin[0] && gDetailDestination[0] && !gRouteProvider[0])
            copyText(gRouteProvider, sizeof(gRouteProvider), "ADSB.lol (indicative route)");
        }
      }
    }
  }
  http.end();
  return gDetailOrigin[0] && gDetailDestination[0];
}

// Optional provider for ACTUAL/SCHEDULED flight times. A valid API key is
// required: ADS-B/ADSBDB do NOT return reliable takeoff/landing clocks.
// Convert ISO 8601 flight timestamps to the UTC clock.  This deliberately
// avoids timegm(), which is not declared by some Arduino ESP32 core versions.
// Since the UI shows only HH:MM, date-to-epoch conversion is unnecessary.
static bool formatIsoTimeUTC(const char *iso, char *out, size_t capacity) {
  if (!iso || !out || capacity < 10 || strlen(iso) < 19) return false;
  int y = 0, mo = 0, d = 0, h = 0, mi = 0, sec = 0;
  if (sscanf(iso, "%d-%d-%dT%d:%d:%d", &y, &mo, &d, &h, &mi, &sec) != 6 ||
      y < 2020 || mo < 1 || mo > 12 || d < 1 || d > 31 ||
      h < 0 || h > 23 || mi < 0 || mi > 59 || sec < 0 || sec > 60)
    return false;

  // Time zone comes after seconds, optionally after fractional seconds.
  const char *tz = iso + 19;
  if (*tz == '.') {
    ++tz;
    if (*tz < '0' || *tz > '9') return false;
    while (*tz >= '0' && *tz <= '9') ++tz;
  }

  int offsetMinutes = 0;
  if (*tz == '+' || *tz == '-') {
    const bool positiveOffset = (*tz == '+');
    ++tz;
    if (tz[0] < '0' || tz[0] > '9' || tz[1] < '0' || tz[1] > '9')
      return false;
    const int oh = (tz[0] - '0') * 10 + (tz[1] - '0');
    tz += 2;
    if (*tz == ':') ++tz;
    if (tz[0] < '0' || tz[0] > '9' || tz[1] < '0' || tz[1] > '9')
      return false;
    const int om = (tz[0] - '0') * 10 + (tz[1] - '0');
    tz += 2;
    if (*tz != '\0' || oh > 14 || om > 59 || (oh == 14 && om > 0))
      return false;
    offsetMinutes = (oh * 60 + om) * (positiveOffset ? 1 : -1);
  } else if (*tz == 'Z' || *tz == 'z') {
    if (tz[1] != '\0') return false;
  } else if (*tz != '\0') {
    return false;
  }

  // Offset +02:00 means local clock two hours ahead of UTC.
  int utcMinutes = (h * 60 + mi - offsetMinutes) % 1440;
  if (utcMinutes < 0) utcMinutes += 1440;
  snprintf(out, capacity, "%02d:%02d UTC", utcMinutes / 60, utcMinutes % 60);
  return true;
}

static void fetchOptionalSchedule(const char *callsign, const char *registration,
                                  char *airline, size_t airlineCap) {
  if (!FLY_AVIATIONSTACK_API_KEY[0] || !callsign || !callsign[0]) return;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http; http.setTimeout(6300); http.useHTTP10(true);
  String url=String("https://api.aviationstack.com/v1/flights?access_key=") +
             photoUrlEncode(FLY_AVIATIONSTACK_API_KEY) +
             "&flight_icao=" + photoUrlEncode(callsign) + "&limit=5";
  if(!http.begin(client,url)) return;
  http.addHeader("Accept", "application/json");
  const int status=http.GET();
  Serial.printf("TIMES: Aviationstack HTTP=%d\n",status);
  if (status==200) {
    SpiRamJsonAllocator allocator;
    JsonDocument doc(&allocator);
    if (!deserializeJson(doc,http.getStream())) {
      JsonArrayConst records=doc["data"].as<JsonArrayConst>();
      for (JsonObjectConst record : records) {
        const char *flight = record["flight"]["icao"] | "";
        if (!flight[0] || !String(flight).equalsIgnoreCase(callsign)) continue;
        // Prefer the exact same registration if the response contains it.
        const char *actualReg=record["aircraft"]["registration"] | "";
        if (actualReg[0] && registration[0] && strcmp(actualReg,registration)!=0) continue;
        const char *company=record["airline"]["name"] | "";
        if (company[0]) copyText(airline, airlineCap, company);
        if (!gDetailOrigin[0]) {
          JsonVariantConst departure = record["departure"].as<JsonVariantConst>();
          incorporateAirport(departure, true, false); // fields handled below if needed
          if (!gDetailOrigin[0]) copyText(gDetailOrigin,sizeof(gDetailOrigin),departure["airport"] | "");
          if (!gDetailOriginCode[0]) copyText(gDetailOriginCode,sizeof(gDetailOriginCode),departure["iata"] | "");
        }
        if (!gDetailDestination[0]) {
          JsonVariantConst arrival=record["arrival"].as<JsonVariantConst>();
          incorporateAirport(arrival, false, false);
          if (!gDetailDestination[0]) copyText(gDetailDestination,sizeof(gDetailDestination),arrival["airport"] | "");
          if (!gDetailDestinationCode[0]) copyText(gDetailDestinationCode,sizeof(gDetailDestinationCode),arrival["iata"] | "");
        }
        char buf[30]={};
        const char *dep = record["departure"]["actual"] | "";
        const char *depKind = "eff.";
        if (!dep[0]) {dep=record["departure"]["estimated"] | "";depKind="stim.";}
        if (!dep[0]) {dep=record["departure"]["scheduled"] | "";depKind="prog.";}
        if(formatIsoTimeUTC(dep,buf,sizeof(buf))) {
          snprintf(gDetailDepartureTime,sizeof(gDetailDepartureTime),"TAKEOFF %s (%s)",buf,depKind);
          gDepartureHasScheduleTime = true;
        }
        const char *arr = record["arrival"]["actual"] | "";
        const char *arrKind = "eff.";
        if (!arr[0]) {arr=record["arrival"]["estimated"] | "";arrKind="stim.";}
        if (!arr[0]) {arr=record["arrival"]["scheduled"] | "";arrKind="prog.";}
        if(formatIsoTimeUTC(arr,buf,sizeof(buf))) {
          snprintf(gDetailArrivalTime,sizeof(gDetailArrivalTime),"ARRIVAL %s (%s)",buf,arrKind);
          gArrivalHasScheduleTime = true;
        }
        break;
      }
    }
  }
  http.end();
}

// Wikipedia supplies representative (model, not airframe-specific) aircraft
// photos without any keys. Pageimages returns a small Wikimedia thumbnail.
static const char *wikipediaAircraftArticle(const char *type) {
  String code=type ? type : "";
  code.toUpperCase();
  if(code.startsWith("A388")) return "Airbus_A380";
  if(code.startsWith("A35")) return "Airbus_A350";
  if(code.startsWith("A34")) return "Airbus_A340";
  if(code.startsWith("A33")) return "Airbus_A330";
  if(code.startsWith("A32") || code.startsWith("A20N") || code.startsWith("A21N") || code.startsWith("A19N") || code.startsWith("A31")) return "Airbus_A320_family";
  if(code.startsWith("A22") || code.startsWith("BCS")) return "Airbus_A220";
  if(code.startsWith("B74")) return "Boeing_747";
  if(code.startsWith("B76")) return "Boeing_767";
  if(code.startsWith("B77")) return "Boeing_777";
  if(code.startsWith("B78")) return "Boeing_787_Dreamliner";
  if(code.startsWith("B73") || code.startsWith("B38") || code.startsWith("B39")) return "Boeing_737";
  if(code.startsWith("B75")) return "Boeing_757";
  if(code.startsWith("CL35") || code.startsWith("CL30")) return "Bombardier_Challenger_300";
  if(code.startsWith("CL60")) return "Bombardier_Challenger_600_series";
  if(code.startsWith("CRJ")) return "Bombardier_CRJ";
  if(code.startsWith("E17") || code.startsWith("E19") || code.startsWith("E75") || code.startsWith("E90") || code.startsWith("E95")) return "Embraer_E-Jet_family";
  if(code.startsWith("C172")) return "Cessna_172";
  if(code.startsWith("C182")) return "Cessna_182_Skylane";
  if(code.startsWith("C208")) return "Cessna_208_Caravan";
  if(code.startsWith("PA28")) return "Piper_PA-28_Cherokee";
  if(code.startsWith("R44")) return "Robinson_R44";
  if(code.startsWith("R22")) return "Robinson_R22";
  if(code.startsWith("GLF6")) return "Gulfstream_G650";
  if(code.startsWith("AT7")) return "ATR_72";
  if(code.startsWith("AT4")) return "ATR_42";
  if(code.startsWith("DH8")) return "De_Havilland_Canada_Dash_8";
  return nullptr;
}

static bool getWikipediaThumbnail(const char *type, String &out) {
  const char *article = wikipediaAircraftArticle(type);
  if (!article) return false;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http; http.setTimeout(7500); http.useHTTP10(true);
  const String api = String("https://en.wikipedia.org/w/api.php?action=query&titles=") +
      photoUrlEncode(article) + "&prop=pageimages&piprop=thumbnail&pithumbsize=300&format=json&formatversion=2&redirects=1";
  if(!http.begin(client,api)) return false;
  http.addHeader("User-Agent","FlyRadar/5.8.4 (https://github.com/RexKramer1/AircraftShapesSVG; personal aviation display)");
  http.addHeader("Accept","application/json");
  http.addHeader("Accept-Encoding","identity");
  const int code=http.GET();
  Serial.printf("PHOTO: Wikipedia %s HTTP=%d\n",article,code);
  if(code==200) {
    JsonDocument doc;
    const DeserializationError err=deserializeJson(doc,http.getStream());
    if(!err) {
      const char *u=doc["query"]["pages"][0]["thumbnail"]["source"] | "";
      if(u[0]) out=u;
    } else Serial.printf("PHOTO: Wikipedia JSON=%s\n",err.c_str());
  }
  http.end();
  return out.length() != 0;
}

// Repository search works also when an exact registration is not photographed.
// Ignore non-JPEG sources: TJpg_Decoder does not support PNG, WebP or SVG.
static int getCommonsThumbnails(const String &query, String out[3],
                                const String &requiredAirline = "") {
  if (!query.length()) return 0;
  WiFiClientSecure client; client.setInsecure();
  HTTPClient http; http.setTimeout(8000); http.useHTTP10(true);
  const String url=String("https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=")+
    photoUrlEncode(query + " filemime:image/jpeg")+
    "&gsrnamespace=6&gsrlimit=5&prop=imageinfo&iiprop=url%7Cmime&iiurlwidth=280&format=json&formatversion=2";
  if(!http.begin(client,url)) return 0;
  http.addHeader("Accept","application/json");
  http.addHeader("Accept-Encoding","identity");
  http.addHeader("User-Agent","FlyRadar/5.8.4 (https://github.com/RexKramer1/AircraftShapesSVG; personal aviation display)");
  const int code=http.GET();
  Serial.printf("PHOTO: Commons search '%s' HTTP=%d\n",query.c_str(),code);
  int count=0;
  if(code==200) {
    SpiRamJsonAllocator allocator;
    JsonDocument doc(&allocator);
    const DeserializationError err=deserializeJson(doc,http.getStream());
    if(!err) {
      JsonArrayConst pages=doc["query"]["pages"].as<JsonArrayConst>();
      for(JsonObjectConst page:pages) {
        if(count>=3) break;
        const char *mime=page["imageinfo"][0]["mime"] | "";
        const char *u=page["imageinfo"][0]["thumburl"] | "";
        // Search engines can return unrelated airlines even for a precise
        // query. Verify the source file title when a livery is requested.
        String title = page["title"] | "";
        title.toLowerCase();
        String required = requiredAirline;
        required.toLowerCase();
        if (required.length() && title.indexOf(required) < 0) continue;
        if(strcmp(mime,"image/jpeg") == 0 && u[0]) out[count++]=u;
      }
    } else Serial.printf("PHOTO: Commons JSON=%s\n",err.c_str());
  }
  http.end();
  return count;
}

static String fixPhotoURL(String url) {
  url.trim();
  if(url.startsWith("//")) url="https:" + url;
  else if(url.startsWith("/")) url="https://www.planespotters.net"+url;
  return url;
}

static bool tryDecodePhoto(String imageUrl, const char *source) {
  imageUrl=fixPhotoURL(imageUrl);
  if(!(imageUrl.startsWith("https://")||imageUrl.startsWith("http://"))) return false;
  const bool secure=imageUrl.startsWith("https://");
  WiFiClientSecure tls; tls.setInsecure();
  WiFiClient plain;
  HTTPClient http;
  http.setTimeout(9000);
  http.useHTTP10(true);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  const bool begun=secure ? http.begin(tls,imageUrl) : http.begin(plain,imageUrl);
  if(!begun) {Serial.printf("PHOTO: %s begin failed\n",source);return false;}
  http.addHeader("Accept","image/jpeg,image/*");
  http.addHeader("Accept-Encoding","identity");
  http.addHeader("User-Agent","FlyRadar-Waveshare7/5.7.8");
  const int status=http.GET();
  Serial.printf("PHOTO: %s HTTP=%d size=%d\n",source,status,http.getSize());
  if(status!=200) {http.end();return false;}

  PhotoBufferStream body(MAX_PHOTO_JPEG_BYTES);
  const int written=http.writeToStream(&body);
  http.end();
  if(written<=0 || body.length<128 || !body.buffer ||
     body.buffer[0]!=0xFF || body.buffer[1]!=0xD8) {
    Serial.printf("PHOTO: %s non-JPEG, read=%d length=%u\n",source,written,(unsigned)body.length);
    return false;
  }
  uint16_t width=0,height=0;
  const int valid=TJpgDec.getJpgSize(&width,&height,body.buffer,body.length);
  Serial.printf("PHOTO: %s JPEG check=%d %ux%u bytes=%u\n",source,valid,width,height,(unsigned)body.length);
  if(valid!=0 || !width || !height) return false;
  int scale=1;
  while(scale<8 && ((width/scale)>PHOTO_W || (height/scale)>PHOTO_H)) scale*=2;
  if(width/scale>PHOTO_W || height/scale>PHOTO_H) return false;
  if(!gPhotoPixels) gPhotoPixels=(uint16_t *)heap_caps_malloc(PHOTO_W*PHOTO_H*2, MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
  if(!gPhotoPixels) {Serial.println("PHOTO: PSRAM allocation failure");return false;}
  memset(gPhotoPixels,0,PHOTO_W*PHOTO_H*2);
  gPhotoOffsetX=max(0,(PHOTO_W-(int)width/scale)/2);
  gPhotoOffsetY=max(0,(PHOTO_H-(int)height/scale)/2);
  TJpgDec.setJpgScale(scale);
  TJpgDec.setSwapBytes(false);
  TJpgDec.setCallback(photoJpegBlock);
  const int decoded=TJpgDec.drawJpg(0,0,body.buffer,body.length);
  // Restore decoder scale for the photographic map (shared TJpg_Decoder instance).
  TJpgDec.setJpgScale(1);
  Serial.printf("PHOTO: %s decode=%d\n",source,decoded);
  if(decoded != 0) return false;
  gPhotoWidth=PHOTO_W;gPhotoHeight=PHOTO_H;
  copyText(gPhotoSource,sizeof(gPhotoSource),source);
  gPhotoOrigin = PhotoOrigin::INTERNET;
  Serial.printf("PHOTO: SUCCESS [I] source=%s\n",source);
  return true;
}

// JetPhotos is not queried by scraping its web pages. An explicitly
// authorized, user-configured metadata service may supply the photo URL and
// original credits. No credentials, protected CDN paths or permissions are
// bundled with this sketch. See JETPHOTOS_LEGGIMI.txt.
static bool jetPhotosEndpointConfigured() {
  const char *base = JETPHOTOS_AUTHORIZED_METADATA_URL;
  return base && (strncmp(base,"https://",8)==0 || strncmp(base,"http://",7)==0);
}

static bool jetPhotosHostIsGenuine(const String &pageUrl) {
  // A source link from the provider is only accepted if it really points to JetPhotos.
  return pageUrl.startsWith("https://www.jetphotos.com/photo/") ||
         pageUrl.startsWith("https://jetphotos.com/photo/");
}

// Last-resort in-flight image bundled with the author's FlyRadar32 splash.
// No external calls or JPEG URL are needed. Different crops are alternated.
static bool useBundledInFlightPhoto() {
  const uint32_t seed = esp_random();
  const int choice = seed % FLY_FALLBACK_VARIATIONS;
  const uint8_t *jpg = FLY_FALLBACK_IMAGES[choice];
  const size_t bytes = FLY_FALLBACK_LENGTHS[choice];
  uint16_t w = 0, h = 0;
  if (TJpgDec.getJpgSize(&w, &h, jpg, bytes) != 0 || w > PHOTO_W || h > PHOTO_H) return false;
  if (!gPhotoPixels) gPhotoPixels = (uint16_t *)heap_caps_malloc(PHOTO_W * PHOTO_H * 2,
                                                 MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!gPhotoPixels) return false;
  memset(gPhotoPixels, 0, PHOTO_W * PHOTO_H * 2);
  gPhotoOffsetX = (PHOTO_W - (int)w) / 2;
  gPhotoOffsetY = (PHOTO_H - (int)h) / 2;
  TJpgDec.setJpgScale(1);
  TJpgDec.setSwapBytes(false);
  TJpgDec.setCallback(photoJpegBlock);
  if (TJpgDec.drawJpg(0, 0, jpg, bytes) != 0) return false;
  gPhotoWidth = PHOTO_W; gPhotoHeight = PHOTO_H;
  copyText(gPhotoSource, sizeof(gPhotoSource), "Illustrative photo | FlyRadar32");
  gPhotoOrigin = PhotoOrigin::BUNDLED;
  Serial.printf("PHOTO: bundled flight fallback #%d OK\n", choice);
  return true;
}


// WAVESHARE microSD: SPI on GPIO 12 CLK, 13 MISO, 11 MOSI; CS is EXIO4
// of the CH422G already initialized by the display board.  Do NOT create
// another CH422G instance or reset LCD/GT911 while mounting the card.
static bool ensureSDMounted() {
  if (gSDMounted) return true;
  const uint32_t now = millis();
  if (gLastSDMountAttemptMs &&
      (uint32_t)(now - gLastSDMountAttemptMs) < 10000UL)
    return false;
  gLastSDMountAttemptMs = now ? now : 1;

  if (!gBoard || !gBoard->getIO_Expander() ||
      !gBoard->getIO_Expander()->getBase()) {
    Serial.println("PHOTO SD: CH422G not available");
    return false;
  }

  // Identico ordine di inizializzazione del test SD Waveshare 7":
  // selezionare EXIO4 PRIMA dell'inizializzazione SPI. Non usare un
  // GPIO ESP32 come CS: EXIO4 e' una linea dell'espansore CH422G.
  // L'espansore appartiene alla scheda gia' inizializzata (no nuovo I2C).
  auto *io = gBoard->getIO_Expander()->getBase();
  Serial.printf("PHOTO SD: mount, heap=%u, psram=%u\n",
                (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());
  SPI.setHwCs(false);
  // IMPORTANTE: attivare CS prima di SPI.begin, come 03_SD_Test Waveshare.
  io->digitalWrite(4, 0);
  delay(10);
  SPI.begin(12, 13, 11, -1);  // SCK 12, MISO 13, MOSI 11, CS esterno
  delay(10);
  Serial.println("PHOTO SD: SPI ready (SCK=12 MISO=13 MOSI=11 EXIO4=LOW)");

  constexpr uint8_t SD_SS_EXTERNAL = static_cast<uint8_t>(-1);
  // Usare ESP32-S3 SPI della libreria Arduino, senza pin CS hardware.
  bool mounted = SD.begin(SD_SS_EXTERNAL, SPI, 4000000U);
  if (!mounted) {
    Serial.println("PHOTO SD: 4 MHz mount failed; resetting SPI and retrying at 1 MHz");
    SD.end();
    SPI.end();
    // Nessun reset del CH422G: interferirebbe con LCD/GT911.
    io->digitalWrite(4, 1);
    delay(15);
    io->digitalWrite(4, 0);
    delay(10);
    SPI.begin(12, 13, 11, -1);
    delay(10);
    mounted = SD.begin(SD_SS_EXTERNAL, SPI, 1000000U);
  }
  if (!mounted) {
    Serial.println("PHOTO SD: MOUNT FAILED AT 1 MHz TOO");
    Serial.println("PHOTO SD: try the separate SD diagnostic sketch");
    SD.end();
    SPI.end();
    io->digitalWrite(4, 1);
    return false;
  }

  const uint8_t cardType = SD.cardType();
  Serial.printf("PHOTO SD: MOUNT OK, type=%u, size=%llu MB\n",
                (unsigned)cardType,
                (unsigned long long)(SD.cardSize() / 1048576ULL));
  if (cardType == CARD_NONE) {
    Serial.println("PHOTO SD: CARD_NONE after mount");
    SD.end();
    SPI.end();
    io->digitalWrite(4, 1);
    return false;
  }
  // Una cartella assente e' un problema *diverso* dal mount fallito.
  // Lascia la SD montata per poter diagnosticare la struttura senza
  // ripetere continuamente l'inizializzazione del bus.
  gSDMounted = true;
  const bool photoDirectoryExists = SD.exists(SD_PHOTO_ROOT);
  const bool mapExists = SD.exists("/foto_compagnie_aeree/mappa_codici.json");
  Serial.printf("PHOTO SD: directory=%s catalog=%s\n",
                photoDirectoryExists ? "PRESENT" : "ABSENT",
                mapExists ? "PRESENT" : "ABSENT");
  if (!photoDirectoryExists || !mapExists) {
    File root = SD.open("/");
    if (root) {
      for (int i = 0; i < 12; ++i) {
        File child = root.openNextFile();
        if (!child) break;
        Serial.printf("PHOTO SD: root %s\n", child.name());
        child.close();
      }
      root.close();
    }
    Serial.println("PHOTO SD: check the /foto_compagnie_aeree/ folder");
    return false;
  }
  Serial.println("PHOTO SD: READY (photo catalog accessible)");
  return true;
}

// Snapshot cache interface.  JPEG images on SD must be licensed for local
// persistence.  Format: 1024x704 baseline JPEG, keys include exact request
// centre and range.  Never touch the existing airline photo directories.
static String mapCacheFilename(double latitude, double longitude, float rangeKm) {
  char name[100];
  const long lat = lround(latitude * 100000.0);
  const long lon = lround(longitude * 100000.0);
  const unsigned range10 = (unsigned)lroundf(rangeKm * 10.0f);
  snprintf(name, sizeof(name), "/maps/screen_v1/r%04u_%+09ld_%+010ld.jpg",
           range10, lat, lon);
  return String(name);
}

static bool mapCacheLoad(int targetIndex, double latitude,
                         double longitude, float rangeKm) {
#if MAP_SD_CACHE_READ_ENABLED
  if (!ensureSDMounted()) return false;
  const String path = mapCacheFilename(latitude, longitude, rangeKm);
  File file = SD.open(path.c_str(), FILE_READ);
  if (!file) return false;
  const size_t size = (size_t)file.size();
  if (size < 1000 || size > MAX_MAP_JPEG_BYTES) { file.close(); return false; }
  auto *jpeg = (uint8_t *)heap_caps_malloc(size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!jpeg) { file.close(); return false; }
  const size_t received = file.read(jpeg, size);
  file.close();
  const bool ok = received == size && decodeMapInto(targetIndex, jpeg, received);
  heap_caps_free(jpeg);
  if (ok) Serial.printf("MAP SD: HIT %s (%u bytes)\n", path.c_str(), (unsigned)size);
  else Serial.printf("MAP SD: BAD FILE %s\n", path.c_str());
  return ok;
#else
  return false;
#endif
}

static void mapCacheSave(const uint8_t *jpeg, size_t bytes,
                         double latitude, double longitude, float rangeKm) {
#if MAP_SD_CACHE_ALLOW_PERSISTENCE
  if (!jpeg || !bytes || !ensureSDMounted()) return;
  if (!SD.exists("/maps")) SD.mkdir("/maps");
  if (!SD.exists("/maps/screen_v1")) SD.mkdir("/maps/screen_v1");
  const String path = mapCacheFilename(latitude, longitude, rangeKm);
  File out = SD.open(path.c_str(), FILE_WRITE);
  if (!out) { Serial.printf("MAP SD: CREATE FAIL %s\n", path.c_str()); return; }
  const size_t written = out.write(jpeg, bytes);
  out.close();
  if (written == bytes)
    Serial.printf("MAP SD: SAVED %s (%u bytes)\n", path.c_str(), (unsigned)bytes);
  else { SD.remove(path.c_str()); Serial.printf("MAP SD: WRITE FAIL %s\n", path.c_str()); }
#else
  (void)jpeg; (void)bytes; (void)latitude; (void)longitude; (void)rangeKm;
#endif
}

static bool trySDCompanyPhoto(const char *callsign, const char *airlineName) {
  if (!ensureSDMounted()) return false;
  File map = SD.open("/foto_compagnie_aeree/mappa_codici.json", FILE_READ);
  if (!map) {
    Serial.println("PHOTO SD: mappa_codici.json missing");
    return false;
  }
  // ArduinoJson consumes the 128 KB map as a Stream: no full JSON copy in RAM.
  // Its allocated JSON nodes go into PSRAM, not the small internal heap.
  SpiRamJsonAllocator allocator;
  JsonDocument doc(&allocator);
  const DeserializationError error = deserializeJson(doc, map);
  map.close();
  if (error) {
    Serial.printf("PHOTO SD: JSON map error: %s\n", error.c_str());
    return false;
  }
  JsonObjectConst root = doc.as<JsonObjectConst>();
  if (root.isNull()) return false;
  String call = String(callsign ? callsign : "");
  call.trim(); call.toUpperCase();
  // Exact three-character ICAO prefix first, then two-character IATA alias.
  // The map already includes RYR/FR, ITY/AZ, DLH/LH etc.
  JsonObjectConst entry;
  String code;
  if (call.length() >= 3) {
    code = call.substring(0, 3);
    entry = root[code.c_str()].as<JsonObjectConst>();
  }
  if (entry.isNull() && call.length() >= 2) {
    code = call.substring(0, 2);
    entry = root[code.c_str()].as<JsonObjectConst>();
  }
  // An ambiguous callsign is NOT evidence of an airline. To avoid showing
  // another carrier's livery, only trust a prefix known by AirlineLookup.h,
  // or an exact verified airline-name match from flight-route data.
  const char *knownCallsignAirline = flyAirlineFromCallsign(call.c_str());
  if (!entry.isNull() && !knownCallsignAirline) {
    Serial.printf("PHOTO SD: ignoring ambiguous prefix '%s' (ICAO not confirmed)\n", code.c_str());
    entry = JsonObjectConst();
  }
  if (entry.isNull() && airlineName && airlineName[0]) {
    String wanted = String(airlineName);
    wanted.trim(); wanted.toLowerCase();
    for (JsonPairConst pair : root) {
      const char *name = pair.value()["airline"] | "";
      if (!name[0]) continue;
      String available = name; available.trim(); available.toLowerCase();
      if (available == wanted) {
        entry = pair.value().as<JsonObjectConst>();
        code = pair.key().c_str();
        break;
      }
    }
  }
  if (entry.isNull()) {
    Serial.printf("PHOTO SD: airline missing from map (callsign=%s)\n", call.c_str());
    return false;
  }
  const char *relative = entry["image"] | "";
  if (!relative[0] || strncmp(relative, "images/", 7) != 0 ||
      strstr(relative, "..") || strchr(relative, '\\')) {
    Serial.println("PHOTO SD: invalid JPEG path");
    return false;
  }
  String filename = String(SD_PHOTO_ROOT) + "/" + relative;
  File photo = SD.open(filename.c_str(), FILE_READ);
  if (!photo) {
    Serial.printf("PHOTO SD: JPEG missing %s\n", filename.c_str());
    return false;
  }
  const size_t bytes = photo.size();
  if (bytes < 100 || bytes > SD_PHOTO_MAX_BYTES) {
    Serial.printf("PHOTO SD: JPEG too small/large %u bytes\n", (unsigned)bytes);
    photo.close();
    return false;
  }
  uint8_t *jpg = (uint8_t *)heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!jpg) {
    Serial.println("PHOTO SD: insufficient PSRAM for JPEG");
    photo.close();
    return false;
  }
  size_t got = 0;
  while (got < bytes) {
    const int n = photo.read(jpg + got, min((size_t)8192, bytes - got));
    if (n <= 0) break;
    got += (size_t)n;
    vTaskDelay(pdMS_TO_TICKS(1));
  }
  photo.close();
  bool success = false;
  if (got == bytes && jpg[0] == 0xFF && jpg[1] == 0xD8 &&
      jpg[bytes - 2] == 0xFF && jpg[bytes - 1] == 0xD9) {
    uint16_t width = 0, height = 0;
    if (TJpgDec.getJpgSize(&width, &height, jpg, bytes) == 0 && width && height) {
      int scale = 1;
      // Use the largest image that is close to the frame; centre crop the
      // slight overshoot so 1280x720 looks like a full-size photograph.
      while (scale < 8 && (width / scale > PHOTO_W + 80 ||
                           height / scale > PHOTO_H + 120)) scale *= 2;
      if (!gPhotoPixels) {
        gPhotoPixels = (uint16_t *)heap_caps_malloc(PHOTO_W * PHOTO_H * 2,
                                      MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
      }
      if (gPhotoPixels) {
        memset(gPhotoPixels, 0, PHOTO_W * PHOTO_H * 2);
        gPhotoOffsetX = ((int)PHOTO_W - (int)width / scale) / 2;
        gPhotoOffsetY = ((int)PHOTO_H - (int)height / scale) / 2;
        TJpgDec.setJpgScale(scale);
        TJpgDec.setSwapBytes(false);
        TJpgDec.setCallback(photoJpegBlock);
        success = (TJpgDec.drawJpg(0, 0, jpg, bytes) == 0);
      }
    }
  }
  heap_caps_free(jpg);
  if (!success) {
    Serial.printf("PHOTO SD: JPEG decoding failed (%s)\n", filename.c_str());
    return false;
  }
  gPhotoWidth = PHOTO_W;
  gPhotoHeight = PHOTO_H;
  copyText(gPhotoSource, sizeof(gPhotoSource), "microSD / Wikimedia Commons - illustrative photo");
  gPhotoOrigin = PhotoOrigin::SD;
  copyText(gPhotoPhotographer, sizeof(gPhotoPhotographer), entry["author"] | "");
  copyText(gPhotoPageUrl, sizeof(gPhotoPageUrl), entry["source_page"] | "");
  copyText(gPhotoId, sizeof(gPhotoId), entry["license"] | "");
  Serial.printf("PHOTO SD: OK airline=%s, file=%s, author=%s, license=%s\n",
                code.c_str(), relative, gPhotoPhotographer, gPhotoId);
  return true;
}

static bool tryAuthorizedJetPhotos(const char *reg, const char *type,
                                   const char *airline) {
  if (!jetPhotosEndpointConfigured()) return false;
  String endpoint = String(JETPHOTOS_AUTHORIZED_METADATA_URL);
  endpoint += (endpoint.indexOf('?') >= 0) ? "&" : "?";
  endpoint += "registration=" + photoUrlEncode(String(reg ? reg : ""));
  endpoint += "&type=" + photoUrlEncode(String(type ? type : ""));
  endpoint += "&airline=" + photoUrlEncode(String(airline ? airline : ""));
  if (endpoint.length() > 1300) return false;

  WiFiClient plain;
  WiFiClientSecure ssl;
  ssl.setInsecure(); // Same TLS policy used by the original sketch.
  HTTPClient http;
  http.setTimeout(6500);
  http.useHTTP10(true);
  const bool tls = endpoint.startsWith("https://");
  const bool begun = tls ? http.begin(ssl, endpoint) : http.begin(plain, endpoint);
  if (!begun) {
    Serial.println("JETPHOTOS: metadata connection failed");
    return false;
  }
  http.addHeader("Accept", "application/json");
  http.addHeader("Accept-Encoding", "identity");
  http.addHeader("User-Agent", "FlyRadar-Waveshare7/5.7.8");
  const int status = http.GET();
  Serial.printf("JETPHOTOS: metadata HTTP=%d\n", status);
  if (status != HTTP_CODE_OK) {
    http.end();
    return false;
  }

  // Accept one-photo JSON, or the photos[0] form returned by a licensed
  // backend adapter. Never infer or fabricate photographer credit.
  SpiRamJsonAllocator allocator;
  JsonDocument doc(&allocator);
  const DeserializationError error = deserializeJson(doc, http.getStream());
  http.end();
  if (error) {
    Serial.printf("JETPHOTOS: metadata JSON error=%s\n", error.c_str());
    return false;
  }
  JsonVariantConst photo = doc.as<JsonVariantConst>();
  if (!doc["photos"].isNull()) photo = doc["photos"][0].as<JsonVariantConst>();
  if (photo.isNull()) return false;
  String jpeg = photo["thumbnail_url"] | "";
  if (!jpeg.length()) jpeg = photo["thumbUrl"] | "";
  if (!jpeg.length()) jpeg = photo["image_url"] | "";
  if (!jpeg.length()) jpeg = photo["imageUrl"] | "";
  String name = photo["photographer"] | "";
  String page = photo["page_url"] | "";
  if (!page.length()) page = photo["pageUrl"] | "";
  String id = photo["photo_id"] | "";
  if (!id.length()) id = photo["photoId"] | "";
  // Permit only numeric identifiers in a generated public page URL.
  if (!page.length() && id.length() && id.length() < 24) {
    bool numeric = true;
    for (size_t i=0; i<id.length(); ++i)
      if (id[i] < '0' || id[i] > '9') numeric = false;
    if (numeric) page = String("https://www.jetphotos.com/photo/") + id;
  }
  if (!jetPhotosHostIsGenuine(page)) {
    Serial.println("JETPHOTOS: missing or invalid source-page URL");
    return false;
  }
  if (!jpeg.startsWith("https://")) {
    Serial.println("JETPHOTOS: HTTPS JPEG thumbnail URL required");
    return false;
  }
  // Only the agreed-upon metadata provider supplies the right to fetch and
  // display the JPEG. The firmware never automatically scrapes JetPhotos.
  if (!tryDecodePhoto(jpeg, "JetPhotos.com")) return false;
  copyText(gPhotoPhotographer, sizeof(gPhotoPhotographer), name.length()?name.c_str():"Not specified");
  copyText(gPhotoPageUrl, sizeof(gPhotoPageUrl), page.c_str());
  copyText(gPhotoId, sizeof(gPhotoId), id.c_str());
  Serial.printf("JETPHOTOS: displayed / photographer=%s / page=%s\n",
                gPhotoPhotographer, gPhotoPageUrl);
  return true;
}

static bool getPlanespottersThumbnail(const String &path,String &photo,String &credit) {
  WiFiClientSecure client;client.setInsecure();
  HTTPClient http;http.setTimeout(6500);http.useHTTP10(true);
  const String url="https://api.planespotters.net/pub/photos/"+path;
  if(!http.begin(client,url))return false;
  http.addHeader("Accept","application/json");
  http.addHeader("Accept-Encoding","identity");
  http.addHeader("User-Agent","FlyRadar-Waveshare7/5.7.8");
  const int status=http.GET();
  Serial.printf("PHOTO: Planespotters %s HTTP=%d\n",path.c_str(),status);
  if(status==200){
    JsonDocument doc;
    const DeserializationError err=deserializeJson(doc,http.getStream());
    if(!err){
      const char *src=doc["photos"][0]["thumbnail"]["src"] | "";
      if(!src[0]) src=doc["photos"][0]["thumbnail_large"]["src"] | "";
      if(src[0])photo=src;
      credit=doc["photos"][0]["photographer"].as<String>();
    }else Serial.printf("PHOTO: Planespotters JSON=%s\n",err.c_str());
  }
  http.end();
  return photo.length()>0;
}

// ADSBDB airline catalog: only contacted on an opened detail page when
// neither the local known ICAO list nor the exact route supplied an airline.
static void lookupMissingAirlineFromAdsbdb(const char *callsign, char *result,
                                          size_t capacity) {
  if (result[0]) return;
  char prefix[4] = {};
  if (!flyIcaoPrefixFromCallsign(callsign, prefix)) return;
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(3500);
  http.useHTTP10(true);
  const String url = String("https://api.adsbdb.com/v0/airline/") + prefix;
  if (!http.begin(client, url)) return;
  http.addHeader("Accept", "application/json");
  http.addHeader("Accept-Encoding", "identity");
  const int status = http.GET();
  if (status == 200) {
    JsonDocument doc;
    if (!deserializeJson(doc, http.getStream())) {
      JsonArrayConst airlines = doc["response"].as<JsonArrayConst>();
      // The API may return multiple businesses for the same short code:
      // don't assign a random one when ambiguous.
      if (!airlines.isNull() && airlines.size() == 1) {
        const char *name = airlines[0]["name"] | "";
        if (name[0]) copyText(result, capacity, name);
      }
    }
  }
  Serial.printf("AIRLINE: ADSBDB prefix=%s HTTP=%d found=%d\n",
                prefix, status, (int)(result[0] != 0));
  http.end();
}

static void fetchDetailLookup() {
  char hex[12],call[16],reg[18],model[48],op[48],type[10];
  copyText(hex,sizeof(hex),gDetailLookupHex);
  copyText(call,sizeof(call),gDetailLookupCallsign);
  copyText(reg,sizeof(reg),gDetailLookupRegistration);
  copyText(model,sizeof(model),gDetailLookupModel);
  copyText(op,sizeof(op),gDetailLookupOperator);
  copyText(type,sizeof(type),gDetailLookupType);
  // This cached local name was displayed immediately; a verified exact
  // flightroute below takes precedence when present.
  char airline[96] = {};
  const char *localAirline = flyAirlineFromCallsign(call);
  if (localAirline) copyText(airline, sizeof(airline), localAirline);
  gDetailAirline[0] = 0;
  gDetailLookupRequested=false;
  gDetailOrigin[0]=gDetailDestination[0]=0;
  gDetailOriginCode[0]=gDetailDestinationCode[0]=0;
  gRouteCoordinatesValid = false;
  gOriginCoordKnown = gDestinationCoordKnown = false;
  gRouteProvider[0] = 0;
  copyText(gDetailDepartureTime, sizeof(gDetailDepartureTime), "TAKEOFF --:--");
  copyText(gDetailArrivalTime, sizeof(gDetailArrivalTime), "ARRIVAL --:--");
  gArrivalHasScheduleTime = false;
  gDepartureHasScheduleTime = false;
  gAirportOriginLat = gAirportOriginLon = gAirportDestLat = gAirportDestLon = 0.0;
  gPhotoOrigin = PhotoOrigin::NONE;
  gPhotoSource[0]=gDetailPhotoUrl[0]=0;
  gPhotoPhotographer[0]=gPhotoPageUrl[0]=gPhotoId[0]=0;
  gPhotoWidth=gPhotoHeight=0;
  gPhotoOffsetX=gPhotoOffsetY=0;
  // On the configured FLYRADAR32 card this is the PRIMARY photo source.
  // The chosen photo can represent the airline, not necessarily this model.
  trySDCompanyPhoto(call, localAirline ? localAirline : op);
  if(WiFi.status()!=WL_CONNECTED){
    if (!gPhotoWidth) useBundledInFlightPhoto();
    gDetailLookupReady=true;return;
  }

  // Keep ADSBDB for airport lookup, but do not rely on it as only photo source.
  String adsbPhoto;
  if(hex[0]) {
    WiFiClientSecure client;client.setInsecure();
    HTTPClient http;http.setTimeout(5500);http.useHTTP10(true);
    String url="https://api.adsbdb.com/v0/aircraft/"+photoUrlEncode(hex);
    if(call[0]) url+="?callsign="+photoUrlEncode(call);
    if(http.begin(client,url)){
      http.addHeader("Accept","application/json");
      http.addHeader("Accept-Encoding","identity");
      const int status=http.GET();
      Serial.printf("PHOTO: ADSBDB route HTTP=%d\n",status);
      if(status==200){
        JsonDocument doc;
        if(!deserializeJson(doc,http.getStream())){
          incorporateAdsbdbRoute(doc["response"]["flightroute"].as<JsonVariantConst>(),
                                 "ADSBDB", airline, sizeof(airline));
          const char *thumb=doc["response"]["aircraft"]["url_photo_thumbnail"] | "";
          const char *full=doc["response"]["aircraft"]["url_photo"] | "";
          adsbPhoto=thumb[0]?thumb:full;
        }
      }
      http.end();
    }
  }

  // Try the callsign-specific route index before contacting an independent
  // crowd-sourced database. Only one fallback lookup per opened detail.
  if (call[0] && (!gDetailOrigin[0] || !gDetailDestination[0] ||
                  !gRouteCoordinatesValid)) {
    fetchAdsbdbByCallsign(call, airline, sizeof(airline));
  }
  if (call[0] && (!gDetailOrigin[0] || !gDetailDestination[0] ||
                  !gRouteCoordinatesValid)) {
    double lat=0.0,lon=0.0;
    bool located=false;
    xSemaphoreTake(gDataMutex,portMAX_DELAY);
    for (int i=0; i<gAircraftCount; ++i) {
      if ((hex[0] && strcmp(hex,gAircraft[i].hex)==0) ||
          (!hex[0] && strcmp(call,gAircraft[i].callsign)==0)) {
        lat=gAircraft[i].lat;lon=gAircraft[i].lon;located=true;break;
      }
    }
    xSemaphoreGive(gDataMutex);
    if (located) fetchAdsbLolRoute(call,lat,lon);
  }
  // Additional schedule provider is optional and used only for opened flights.
  fetchOptionalSchedule(call, reg, airline, sizeof(airline));
  if (!airline[0]) lookupMissingAirlineFromAdsbdb(call, airline, sizeof(airline));
  // Publish the airline together with the other detail data. Keep the
  // photographer attribution / image routines exactly as in v5.7.7.
  copyText(gDetailAirline, sizeof(gDetailAirline), airline);
  // A provider may identify the airline only after the route lookup; in that
  // case attempt the offline catalog once more with the exact airline name.
  if (!gPhotoWidth && airline[0]) trySDCompanyPhoto(call, airline);

  // If an authorized JetPhotos catalog was configured, try it first.
  // On failure, fallback to the original model / aircraft providers.
  if (!gPhotoWidth && tryAuthorizedJetPhotos(reg, type, op)) {
    // gPhotoWidth is set only after a valid JPEG has been decoded.
  }

  // After microSD: first photographs matched to the exact aircraft hex or
  // registration; these cannot accidentally show a different airline.
  if(!gPhotoWidth && hex[0]) {
    String photo, credit;
    if(getPlanespottersThumbnail(String("hex/")+hex,photo,credit)) {
      String label="Planespotters.net";
      if(credit.length()) label+=" / "+credit;
      tryDecodePhoto(photo,label.c_str());
    }
  }
  if(!gPhotoWidth && reg[0]) {
    String photo, credit;
    if(getPlanespottersThumbnail(String("reg/")+photoUrlEncode(reg),photo,credit)) {
      String label="Planespotters.net";
      if(credit.length()) label+=" / "+credit;
      tryDecodePhoto(photo,label.c_str());
    }
  }
  if(!gPhotoWidth && adsbPhoto.length()) tryDecodePhoto(adsbPhoto,"ADSBDB");
  if(!gPhotoWidth && hex[0])
    tryDecodePhoto(String("https://hexdb.io/hex-image-thumb?hex=")+hex,"hexdb.io");

  // Company + aircraft model: only accept Wikimedia file names explicitly
  // containing the company. A search match alone is not sufficient: it can
  // show unrelated liveries. Generic model photos are used only for flights
  // whose airline cannot be established from ADSBDB or the ICAO callsign.
  String query = String(model);
  query.replace(" - ", " "); query.replace("/3500", "");
  if (query.indexOf("not available") >= 0) query = "";
  String candidates[3];
  const bool knownAirline = airline[0] != 0;
  if (!gPhotoWidth && query.length() && knownAirline) {
    const String airlineName = String(airline);
    const int count = getCommonsThumbnails(query + " " + airlineName + " aircraft in flight",
                                           candidates, airlineName);
    const int first = count ? (int)(esp_random() % count) : 0;
    for (int j=0; j<count && !gPhotoWidth; ++j)
      tryDecodePhoto(candidates[(j+first)%count], "Wikimedia Commons - aircraft type and airline");
  }
  if (!knownAirline && !gPhotoWidth && query.length()) {
    const int count = getCommonsThumbnails(query + " flying aircraft", candidates);
    const int first = count ? (int)(esp_random() % count) : 0;
    for (int j=0; j<count && !gPhotoWidth; ++j)
      tryDecodePhoto(candidates[(j+first)%count],
                     "Wikimedia Commons - aircraft type (unknown airline)");
  }
  if (!knownAirline && !gPhotoWidth && type[0]) {
    String wikipedia;
    if (getWikipediaThumbnail(type,wikipedia))
      tryDecodePhoto(wikipedia,"Wikipedia - representative aircraft type photo");
  }

  if (!gPhotoWidth) useBundledInFlightPhoto();

  if(strcmp(hex,gDetailLookupHex)==0 && strcmp(call,gDetailLookupCallsign)==0) {
    if(!gPhotoWidth)copyText(gPhotoSource,sizeof(gPhotoSource),"No valid JPEG from image sources");
    gDetailLookupReady=true;
  }
}

static double routeAngularDistance(double aLat, double aLon, double bLat, double bLon) {
  const double p1 = aLat * PI / 180.0, p2 = bLat * PI / 180.0;
  const double dp = (bLat-aLat) * PI / 180.0;
  const double dl = (bLon-aLon) * PI / 180.0;
  const double h = sin(dp/2)*sin(dp/2) + cos(p1)*cos(p2)*sin(dl/2)*sin(dl/2);
  return 2.0 * asin(sqrt(fmax(0.0, fmin(1.0, h))));
}
static double routeBearing(double aLat, double aLon, double bLat, double bLon) {
  const double p1 = aLat * PI / 180.0, p2 = bLat * PI / 180.0;
  const double dl = (bLon-aLon) * PI / 180.0;
  return atan2(sin(dl)*cos(p2), cos(p1)*sin(p2)-sin(p1)*cos(p2)*cos(dl));
}
// Result is an along-track fraction, NOT ETA and NOT flown-path mileage.
static bool projectedFlightProgress(double liveLat, double liveLon, double &fraction) {
  if (!gRouteCoordinatesValid) return false;
  const double d12 = routeAngularDistance(gAirportOriginLat, gAirportOriginLon,
                                         gAirportDestLat, gAirportDestLon);
  const double d13 = routeAngularDistance(gAirportOriginLat, gAirportOriginLon,
                                         liveLat, liveLon);
  if (d12 < 0.001 || d12 > PI || !isfinite(d13)) return false;
  const double theta12 = routeBearing(gAirportOriginLat, gAirportOriginLon,
                                      gAirportDestLat, gAirportDestLon);
  const double theta13 = routeBearing(gAirportOriginLat, gAirportOriginLon,
                                      liveLat, liveLon);
  // Signed along-track angular distance on the great-circle joining airports.
  const double along = atan2(sin(d13) * cos(theta13-theta12), cos(d13));
  if (!isfinite(along)) return false;
  fraction = fmax(0.0, fmin(1.0, along / d12));
  return true;
}

// Without an authorized schedule service, there is NO actual departure time
// in the ADS-B feed. Show a clearly marked geographic retrospective eestimatedte
// (distance already travelled / current ground speed), not a fabricated fact.
// Official scheduled/eestimatedted/actual times, if available, always win.
static void updateEestimatedtedFlightTimesLocked(const Aircraft &aircraft, double fraction) {
  if (!gRouteCoordinatesValid ||
      (gDepartureHasScheduleTime && gArrivalHasScheduleTime)) return;
  const double routeRadians = routeAngularDistance(gAirportOriginLat, gAirportOriginLon,
                                                  gAirportDestLat, gAirportDestLon);
  const double totalKm = 6371.0 * routeRadians;
  if (!isfinite(totalKm) || totalKm < 8.0 || totalKm > 20000.0 ||
      aircraft.speedKt < 100 || aircraft.speedKt > 750) return;
  const double speedKmH = aircraft.speedKt * 1.852;
  const time_t nowUtc = time(nullptr);
  if (nowUtc < 1735689600) return; // NTP not synchronized.

  const double flownKm = totalKm * fraction;
  const double elapsedHours = flownKm / speedKmH;
  if (!gDepartureHasScheduleTime && gDepartureTimeLabel &&
      fraction >= 0.01 && isfinite(elapsedHours) && elapsedHours < 18.0) {
    const time_t departedUtc = nowUtc - (time_t)lround(elapsedHours * 3600.0);
    struct tm t = {};
    gmtime_r(&departedUtc, &t);
    char timeLabel[76];
    snprintf(timeLabel, sizeof(timeLabel), "TAKEOFF ~%02d:%02d UTC (estimated)",
             t.tm_hour, t.tm_min);
    lv_label_set_text(gDepartureTimeLabel, timeLabel);
  }

  const double remainingKm = totalKm * (1.0 - fraction);
  const double remainingHours = remainingKm / speedKmH;
  if (!gArrivalHasScheduleTime && gArrivalTimeLabel &&
      fraction < 0.99 && remainingKm > 3.0 &&
      isfinite(remainingHours) && remainingHours < 18.0) {
    const time_t etaUtc = nowUtc + (time_t)lround(remainingHours * 3600.0);
    struct tm t = {};
    gmtime_r(&etaUtc, &t);
    char timeLabel[76];
    snprintf(timeLabel, sizeof(timeLabel), "ETA ~%02d:%02d UTC (estimated)",
             t.tm_hour, t.tm_min);
    lv_label_set_text(gArrivalTimeLabel, timeLabel);
  }
}

static void updateRouteProgressLocked() {
  if (!gDetailPanel || !gRouteFill || !gRouteLabel || !gRoutePlane) return;
  if (!gRouteCoordinatesValid) {
    lv_label_set_text(gRouteLabel, "Route position unavailable");
    lv_obj_set_width(gRouteFill, 0);
    lv_obj_add_flag(gRoutePlane, LV_OBJ_FLAG_HIDDEN);
    return;
  }
  Aircraft aircraft;
  bool found = false;
  xSemaphoreTake(gDataMutex, portMAX_DELAY);
  for (int i=0; i<gAircraftCount; ++i) {
    if ((gSelectedAircraftHex[0] && strcmp(gAircraft[i].hex, gSelectedAircraftHex) == 0) ||
        (!gSelectedAircraftHex[0] && gSelectedAircraftCallsign[0] &&
         strcmp(gAircraft[i].callsign, gSelectedAircraftCallsign) == 0)) {
      aircraft = gAircraft[i]; found = true; break;
    }
  }
  xSemaphoreGive(gDataMutex);
  double fraction = 0.0;
  if (!found || !projectedFlightProgress(aircraft.lat, aircraft.lon, fraction)) {
    lv_label_set_text(gRouteLabel, "Flight position unavailable");
    lv_obj_set_width(gRouteFill, 0);
    lv_obj_add_flag(gRoutePlane, LV_OBJ_FLAG_HIDDEN);
    return;
  }
  const int barWidth = 264;
  const int w = constrain((int)lround(fraction * barWidth), 0, barWidth);
  lv_obj_set_width(gRouteFill, w);
  // The actual GLYPH is centered vertically and horizontally on the
  // illuminated section of the line (do not offset it 3/4 above the bar).
  lv_obj_set_pos(gRoutePlane, constrain(20 + w - 14, 6, 280), 65);
  lv_obj_clear_flag(gRoutePlane, LV_OBJ_FLAG_HIDDEN);
  char progressText[72];
  snprintf(progressText, sizeof(progressText), "%d%% geographic route (%s)",
           constrain((int)lround(fraction*100.0), 0, 100),
           strstr(gRouteProvider,"ADSB.lol") ? "ADSB.lol, indicative" : "estimated");
  lv_label_set_text(gRouteLabel, progressText);
  updateEestimatedtedFlightTimesLocked(aircraft, fraction);
}

static void publishDetailLookup() {
  if (!gDetailLookupReady) return;
  gDetailLookupReady = false;
  esp_lv_adapter_lock(-1);
  if (gDetailPanel && gRouteLabel) {
    const char *origin = gDetailOrigin[0] ? gDetailOrigin : "Not available";
    const char *destination = gDetailDestination[0] ? gDetailDestination : "Not available";
    if (gOriginCodeLabel) lv_label_set_text(gOriginCodeLabel,
        gDetailOriginCode[0] ? gDetailOriginCode : "---");
    if (gDestinationCodeLabel) lv_label_set_text(gDestinationCodeLabel,
        gDetailDestinationCode[0] ? gDetailDestinationCode : "---");
    if (gOriginNameLabel) lv_label_set_text(gOriginNameLabel, origin);
    if (gDestinationNameLabel) lv_label_set_text(gDestinationNameLabel, destination);
    if (gDepartureTimeLabel) lv_label_set_text(gDepartureTimeLabel, gDetailDepartureTime);
    if (gArrivalTimeLabel) lv_label_set_text(gArrivalTimeLabel, gDetailArrivalTime);
    // This line is a route indicator, NOT a calculated percentage of flight.
    updateRouteProgressLocked();
    if (gCompanyLabel && gDetailAirline[0]) {
      lv_label_set_text(gCompanyLabel, gDetailAirline);
      Serial.printf("AIRLINE: verified/lookup = %s\n", gDetailAirline);
    }
    if (gPhotoLabel) {
      if (gPhotoWidth && strncmp(gPhotoSource, "microSD /", 10) == 0) {
        char credit[235];
        snprintf(credit, sizeof(credit), "Illustrative SD photo | %.85s | %.28s",
                 gPhotoPhotographer[0] ? gPhotoPhotographer : "Author not specified",
                 gPhotoId[0] ? gPhotoId : "license in CREDITI.txt");
        lv_label_set_text(gPhotoLabel, credit);
      } else if (gPhotoWidth && strcmp(gPhotoSource, "JetPhotos.com") == 0) {
        char credit[210];
        if (gPhotoId[0])
          snprintf(credit, sizeof(credit), "JetPhotos.com | Photo: %.70s\njetphotos.com/photo/%.22s",
                   gPhotoPhotographer[0] ? gPhotoPhotographer : "Not specified", gPhotoId);
        else
          snprintf(credit, sizeof(credit), "JetPhotos.com | Photo: %.70s\nSource: JetPhotos.com",
                   gPhotoPhotographer[0] ? gPhotoPhotographer : "Not specified");
        lv_label_set_text(gPhotoLabel, credit);
      } else {
        lv_label_set_text(gPhotoLabel, gPhotoWidth ? gPhotoSource : "Photo not loaded");
      }
      if (gPhotoWidth) {
        // Dark readable caption over the bottom of the actual 300 x 156 image.
        lv_obj_set_pos(gPhotoLabel, 485, 143);
        lv_obj_set_size(gPhotoLabel, 296, 39);
        lv_obj_set_style_bg_color(gPhotoLabel, lv_color_hex(0x050B12), 0);
        lv_obj_set_style_bg_opa(gPhotoLabel, LV_OPA_90, 0);
        lv_obj_set_style_text_color(gPhotoLabel, lv_color_hex(C_TEXT), 0);
        lv_label_set_long_mode(gPhotoLabel, LV_LABEL_LONG_WRAP);
        lv_obj_set_style_text_font(gPhotoLabel, fontSmall(), 0);
      } else {
        lv_obj_set_pos(gPhotoLabel, 490, 78);
        lv_obj_set_size(gPhotoLabel, 288, 28);
        lv_obj_set_style_text_align(gPhotoLabel, LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_style_bg_opa(gPhotoLabel, LV_OPA_TRANSP, 0);
        lv_obj_set_style_text_color(gPhotoLabel, lv_color_hex(C_DIM), 0);
        lv_label_set_long_mode(gPhotoLabel, LV_LABEL_LONG_DOT);
        lv_obj_set_style_text_font(gPhotoLabel, fontMedium(), 0);
      }
    }
    if (gPhotoWidth && gPhotoPixels && gPhotoFrame) {
      if (gPhotoImage) { lv_obj_delete(gPhotoImage); gPhotoImage = nullptr; }
      gPhotoDescriptor = {};
      gPhotoDescriptor.header.magic = LV_IMAGE_HEADER_MAGIC;
      gPhotoDescriptor.header.cf = LV_COLOR_FORMAT_RGB565;
      gPhotoDescriptor.header.w = PHOTO_W;
      gPhotoDescriptor.header.h = PHOTO_H;
      gPhotoDescriptor.header.stride = PHOTO_W * sizeof(uint16_t);
      gPhotoDescriptor.data_size = PHOTO_W * PHOTO_H * 2;
      gPhotoDescriptor.data = (const uint8_t *)gPhotoPixels;
      // The reserved photo frame is created once with the detail page.
      // This avoids stacking additional panels every time a new image arrives.
      gPhotoImage = lv_image_create(gPhotoFrame);
      lv_obj_set_pos(gPhotoImage, 0, 0);
      lv_image_set_src(gPhotoImage, &gPhotoDescriptor);
      if (gPhotoLabel) lv_obj_move_foreground(gPhotoLabel);
    }
    if (gPhotoOriginBadge) {
      if (gPhotoWidth) {
        const char *badge = gPhotoOrigin == PhotoOrigin::SD ? "S" :
                            gPhotoOrigin == PhotoOrigin::INTERNET ? "I" : "-";
        const uint32_t badgeColor = gPhotoOrigin == PhotoOrigin::SD ? C_GREEN :
                                    gPhotoOrigin == PhotoOrigin::INTERNET ? C_CYAN : C_DIM;
        lv_obj_t *badgeLabel = lv_obj_get_child(gPhotoOriginBadge, 0);
        if (badgeLabel) {
          lv_label_set_text(badgeLabel, badge);
          lv_obj_set_style_text_color(badgeLabel, lv_color_hex(badgeColor), 0);
          lv_obj_set_style_text_align(badgeLabel, LV_TEXT_ALIGN_CENTER, 0);
        }
        lv_obj_set_style_border_color(gPhotoOriginBadge, lv_color_hex(badgeColor), 0);
        lv_obj_clear_flag(gPhotoOriginBadge, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(gPhotoOriginBadge);
      } else lv_obj_add_flag(gPhotoOriginBadge, LV_OBJ_FLAG_HIDDEN);
    }
  }
  esp_lv_adapter_unlock();
}

static void networkWorker(void *) {
  bool wifiWarningShown = false;
  for (;;) {
    if (!gNetworkEnabled || !gMainScreenActive) {
      vTaskDelay(pdMS_TO_TICKS(100));
      continue;
    }
    if (WiFi.status() != WL_CONNECTED) {
      // The microSD photo viewer also works while the Wi-Fi is temporarily
      // unavailable; do not starve its lookup behind the network gate.
      if (gDetailLookupRequested && !gGestureActive) {
        gNetworkBusy = true;
        fetchDetailLookup();
        gNetworkBusy = false;
        continue;
      }
      if (!wifiWarningShown) {
        postStatus("Wi-Fi disconnected: waiting to reconnect");
        wifiWarningShown = true;
      }
      vTaskDelay(pdMS_TO_TICKS(250));
      continue;
    }
    if (gMapPublishPending ||
        (int32_t)(millis() - gNetworkPauseUntilMs) < 0) {
      vTaskDelay(pdMS_TO_TICKS(50));
      continue;
    }
    if (wifiWarningShown) {
      wifiWarningShown = false;
      gMapRequested = true;
      gAircraftRequested = true;
      gNextMapAttemptMs = 0;
      gNextAircraftAttemptMs = 0;
    }

    if (gDetailLookupRequested && !gGestureActive) {
      gNetworkBusy=true;
      fetchDetailLookup();
      gNetworkBusy=false;
      continue;
    }

    // ADS-B has priority over slow satellite map requests.
    // On an error keep the request pending for the next retry window.
    if (gAircraftRequested && !gGestureActive &&
        (int32_t)(millis() - gNextAircraftAttemptMs) >= 0) {
      gNetworkBusy = true;
      const bool ok = fetchAircraftData(gRequestedRangeKm);
      gAircraftRequested = !ok;
      if (!ok) {
        gNextAircraftAttemptMs = millis() + ADSB_RETRY_MS;
        Serial.println("ADSB: query failed, automatic retry scheduled");
      }
      gNetworkBusy = false;
      continue;
    }

    if (gMapRequested && !gMapPublishPending && !gGestureActive &&
        (int32_t)(millis() - gNextMapAttemptMs) >= 0) {
      gNetworkBusy = true;
      if (!allocateMapBuffers()) {
        postStatus("Map PSRAM unavailable: retrying");
        gNextMapAttemptMs = millis() + MAP_RETRY_MS;
        gNetworkBusy = false;
        continue;
      }

      const uint32_t serial = gMapRequestSerial;
      const float requestedRange = gRequestedRangeKm;
      const int target = (gMapActiveIndex == 0) ? 1 : 0;
      const double requestedLat = gViewLatitude;
      const double requestedLon = gViewLongitude;
      bool ok = false;
      const MapSnapshotKey &key = gMapSnapshotKeys[target];
      if (key.valid && fabs(key.lat - requestedLat) < 0.000002 &&
          fabs(key.lon - requestedLon) < 0.000002 &&
          fabsf(key.range - requestedRange) < 0.05f) {
        ok = true;
        Serial.println("MAP: PSRAM snapshot HIT (no HTTP, no JPEG decode)");
      } else {
        gMapSnapshotKeys[target].valid = false;
        ok = downloadMapInto(target, requestedLat, requestedLon,
                             requestedRange);
        if (ok) {
          gMapSnapshotKeys[target].lat = requestedLat;
          gMapSnapshotKeys[target].lon = requestedLon;
          gMapSnapshotKeys[target].range = requestedRange;
          gMapSnapshotKeys[target].valid = true;
        }
      }
      if (ok && serial == gMapRequestSerial &&
          fabsf(requestedRange - gRequestedRangeKm) < 0.05f) {
        gMapPendingIndex = target;
        gMapPendingRange = requestedRange;
        gMapPendingSerial = serial;
        gPendingLatitude = requestedLat;
        gPendingLongitude = requestedLon;
        gMapPublishPending = true;
        gMapRequested = false;
      } else {
        gNextMapAttemptMs =
            ok ? millis() + 50UL : millis() + MAP_RETRY_MS;
      }
      gNetworkBusy = false;
      continue;
    }

    vTaskDelay(pdMS_TO_TICKS(30));
  }
}

static bool isEmergency(const Aircraft &aircraft) {
  return !strcmp(aircraft.squawk, "7500") ||
         !strcmp(aircraft.squawk, "7600") ||
         !strcmp(aircraft.squawk, "7700");
}

static uint32_t colorForAircraft(const Aircraft &aircraft) {
  switch (aircraft.kind) {
    case KIND_HELICOPTER: return 0x6FE7FF;
    case KIND_HEAVY: return 0xFFB347;
    case KIND_BUSINESS: return 0x7DFF8B;
    case KIND_LIGHT: return 0xFFE16B;
    default: return C_YELLOW;
  }
}

static int iconScaleForAircraft(const Aircraft &aircraft) {
  String t = aircraft.type;
  t.toUpperCase();
  if (aircraft.kind == KIND_HELICOPTER) return 15;
  if (t.startsWith("A388") || t.startsWith("A38")) return 19;
  if (t.startsWith("B748") || t.startsWith("B744") || t.startsWith("B74") ||
      t.startsWith("A346") || t.startsWith("A343") || t.startsWith("A35") ||
      t.startsWith("B77")) return 17;
  if (aircraft.kind == KIND_HEAVY) return 16;
  if (aircraft.kind == KIND_BUSINESS) return 12;
  if (aircraft.kind == KIND_LIGHT) return 10;
  return 14;
}

static void setHidden(lv_obj_t *obj, bool hide) {
  if (!obj) return;
  if (hide) lv_obj_add_flag(obj, LV_OBJ_FLAG_HIDDEN);
  else lv_obj_clear_flag(obj, LV_OBJ_FLAG_HIDDEN);
}

static void updateRangeLabelLocked(bool loading) {
  if (!gRangeLabel) return;
  char text[40];
  snprintf(text, sizeof(text), "RANGE %.0f KM%s",
           gRequestedRangeKm, loading ? " ..." : "");
  lv_label_set_text(gRangeLabel, text);
  lv_obj_set_style_text_color(
      gRangeLabel, lv_color_hex(loading ? C_YELLOW : C_CYAN), 0);
}

// Three curved arcs reproduce the standard Wi-Fi fan (LVGL geometry,
// not a Unicode glyph that might be missing from the selected font).
static void createWifiSignalLocked(lv_obj_t *screen) {
  lv_obj_t *panel = makePanel(screen, 480, 8, 98, 42);
  for (int i=0; i<3; ++i) {
    const int sz = 40 - i * 10;
    lv_obj_t *arc = lv_arc_create(panel);
    gWifiArcs[i] = arc;
    lv_obj_set_size(arc, sz, sz);
    lv_obj_set_pos(arc, 5 + (40-sz)/2, 3 + (40-sz)/2);
    lv_obj_set_style_pad_all(arc, 0, 0);
    lv_arc_set_bg_angles(arc, 212, 328);
    lv_arc_set_angles(arc, 212, 328);
    lv_obj_set_style_arc_opa(arc, LV_OPA_TRANSP, LV_PART_MAIN);
    lv_obj_set_style_arc_width(arc, 3, LV_PART_INDICATOR);
    lv_obj_set_style_arc_rounded(arc, true, LV_PART_INDICATOR);
    lv_obj_remove_style(arc, nullptr, LV_PART_KNOB);
    lv_obj_clear_flag(arc, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(arc, LV_OBJ_FLAG_SCROLLABLE);
  }
  gWifiDot = shapeRect(panel, 23, 30, 6, 6, C_DIM, 3);
  gWifiRssiLabel = makeLabel(panel, "--", 47, 13, 47, fontSmall(), C_DIM);
}

static void updateWifiSignalLocked() {
  if (!gWifiRssiLabel) return;
  const bool connected = WiFi.status() == WL_CONNECTED;
  const int rssi = connected ? WiFi.RSSI() : -127;
  const int strength = !connected ? 0 : (rssi >= -60 ? 3 : rssi >= -72 ? 2 : rssi >= -85 ? 1 : 0);
  const uint32_t active = !connected ? C_RED : (strength >= 2 ? C_GREEN : C_ORANGE);
  for (int i=0; i<3; ++i) {
    if (!gWifiArcs[i]) continue;
    const bool on = i >= 3-strength;
    lv_obj_set_style_arc_color(gWifiArcs[i], lv_color_hex(on ? active : 0x435160), LV_PART_INDICATOR);
  }
  if (gWifiDot) lv_obj_set_style_bg_color(gWifiDot, lv_color_hex(connected ? active : C_RED), 0);
  char text[16];
  if (connected) snprintf(text, sizeof(text), "%d", rssi);
  else strlcpy(text, "OFF", sizeof(text));
  lv_label_set_text(gWifiRssiLabel, text);
  lv_obj_set_style_text_color(gWifiRssiLabel, lv_color_hex(connected ? C_TEXT : C_RED), 0);
}

static void updateClockLocked() {
  if (!gClockLabel) return;
  struct tm now = {};
  if (getNow(now)) {
    char text[8];
    strftime(text, sizeof(text), "%H:%M", &now);
    lv_label_set_text(gClockLabel, text);
  } else {
    lv_label_set_text(gClockLabel, "--:--");
  }
}

static const lv_image_dsc_t *aircraftIcon(const Aircraft &aircraft) {
  String type = aircraft.type; type.toUpperCase();
  // Exact ICAO model precedes generic category; catalog assets generated from SVG.
  if (type.startsWith("B744") || type.startsWith("B742")) return &fly_catalog_B744;
  if (type.startsWith("B748")) return &fly_catalog_B748;
  if (type.startsWith("B762") || type.startsWith("B763") || type.startsWith("B764")) return &fly_catalog_B763;
  if (type.startsWith("A388")) return &fly_catalog_A388;
  if (type.startsWith("A320") || type.startsWith("A20N")) return &fly_catalog_A320;
  if (type.startsWith("CL35") || type.startsWith("CL30") || type.startsWith("CL60")) return &fly_catalog_CL35;
  if (type.startsWith("C172") || type.startsWith("C182")) return &fly_catalog_C172;
  if (type.startsWith("R44")) return &fly_catalog_R44;
  if (aircraft.kind == KIND_HELICOPTER) return &fly_dsc_6;
  if (type.startsWith("A38")) return &fly_dsc_2;
  if (type.startsWith("B74")) return &fly_dsc_3;
  if (aircraft.kind == KIND_HEAVY) return &fly_dsc_1;
  if (aircraft.kind == KIND_BUSINESS) return &fly_dsc_4;
  if (aircraft.kind == KIND_LIGHT) return &fly_dsc_5;
  return &fly_dsc_0;
}

static void stylePlaneSlot(PlaneSlot &slot, const Aircraft &aircraft) {
  if (!slot.icon) return;
  lv_image_set_src(slot.icon, aircraftIcon(aircraft));
  // Relative wingspan representation, not an exact physical map scale.
  int scale = 190;
  String type = aircraft.type; type.toUpperCase();
  if (type.startsWith("A38")) scale = 256;
  else if (type.startsWith("B74")) scale = 239;
  else if (aircraft.kind == KIND_HEAVY) scale = 225;
  else if (aircraft.kind == KIND_BUSINESS) scale = 165;
  else if (aircraft.kind == KIND_LIGHT) scale = 143;
  else if (aircraft.kind == KIND_HELICOPTER) scale = 174;
  lv_image_set_scale(slot.icon, scale);
  lv_image_set_rotation(slot.icon, (int32_t)aircraft.headingDeg * 10);
  lv_obj_set_style_text_color(slot.label, lv_color_hex(colorForAircraft(aircraft)), 0);
}

static void createPlaneSlotsLocked() {
  for (int i = 0; i < MAX_VISIBLE_AIRCRAFT; ++i) {
    PlaneSlot &slot = gPlaneSlots[i];
    slot = PlaneSlot{};
    slot.root = lv_obj_create(gPlaneLayer);
    if (!slot.root) { Serial.printf("ICON %d allocation failed\n", i); break; }
    lv_obj_set_size(slot.root, 130, 62);
    lv_obj_set_style_pad_all(slot.root, 0, 0);
    lv_obj_set_style_border_width(slot.root, 0, 0);
    lv_obj_set_style_bg_opa(slot.root, LV_OPA_TRANSP, 0);
    lv_obj_clear_flag(slot.root, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_add_flag(slot.root, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_add_flag(slot.root, LV_OBJ_FLAG_OVERFLOW_VISIBLE);
    lv_obj_add_event_cb(slot.root, planeEvent, LV_EVENT_CLICKED, (void *)(intptr_t)i);
    slot.icon = lv_image_create(slot.root);
    if (slot.icon) {
      lv_obj_set_pos(slot.icon, 0, 0);
      lv_image_set_src(slot.icon, &fly_dsc_0);
      lv_obj_clear_flag(slot.icon, LV_OBJ_FLAG_CLICKABLE);
    }
    slot.label = makeLabel(slot.root, "", 53, 20, 75, fontSmall(), C_YELLOW);
    lv_obj_add_flag(slot.root, LV_OBJ_FLAG_HIDDEN);
  }
}

static void drawAircraftLocked(float displayRange) {
  if (!gPlaneLayer) return;
  for (int i = 0; i < MAX_VISIBLE_AIRCRAFT; ++i) {
    gPlaneSlots[i].aircraftIndex = -1;
    if (gPlaneSlots[i].root)
      lv_obj_add_flag(gPlaneSlots[i].root, LV_OBJ_FLAG_HIDDEN);
  }

  const float pxPerKm = (SCREEN_HEIGHT * 0.5f) / max(0.1f, displayRange);
  const float centerLat = (float)gDisplayedLatitude;
  const float cosLat = cosf(degToRad(centerLat));
  int visible = 0;

  xSemaphoreTake(gDataMutex, portMAX_DELAY);
  const int total = gAircraftCount;
  for (int i = 0; i < total && visible < MAX_VISIBLE_AIRCRAFT; ++i) {
    const Aircraft &aircraft = gAircraft[i];
    const float northKm = (aircraft.lat - centerLat) * 111.12f;
    const float eastKm = (aircraft.lon - (float)gDisplayedLongitude) *
                         111.12f * cosLat;
    const int x = lroundf(SCREEN_WIDTH * 0.5f + eastKm * pxPerKm);
    const int y = lroundf(SCREEN_HEIGHT * 0.5f - northKm * pxPerKm);
    if (x < 10 || x > SCREEN_WIDTH - 10 || y < 58 || y > 424)
      continue;

    PlaneSlot &slot = gPlaneSlots[visible++];
    slot.aircraftIndex = i;
    lv_obj_set_pos(slot.root, x - 28, y - 28);
    stylePlaneSlot(slot, aircraft);
    const char *name = aircraft.callsign[0] ? aircraft.callsign : aircraft.hex;
    lv_label_set_text(slot.label, name[0] ? name : "AIRCRAFT");
    lv_obj_clear_flag(slot.root, LV_OBJ_FLAG_HIDDEN);
  }
  if (gCountLabel)
    lv_label_set_text_fmt(gCountLabel, displayRange > 238.0f ? "AIRCRAFT %d/%d *" : "AIRCRAFT %d/%d", visible, total);
  static int lastVisible = -1, lastTotal = -1;
  if (visible != lastVisible || total != lastTotal) {
    Serial.printf("ADSB DISPLAY: %d visible / %d received, view range %.0f km\n", visible, total, displayRange);
    lastVisible = visible; lastTotal = total;
  }
  xSemaphoreGive(gDataMutex);
}

static void aircraftManufacturerAndModel(const char *icao, char *out, size_t cap) {
  String t = icao ? icao : ""; t.toUpperCase();
  const char *name = nullptr;
  if (t == "A388") name = "Airbus - A380-800";
  else if (t == "B744") name = "Boeing - 747-400";
  else if (t == "B748") name = "Boeing 747-8";
  else if (t == "B742") name = "Boeing 747-200";
  else if (t == "B762") name = "Boeing 767-200";
  else if (t == "B763") name = "Boeing - 767-300";
  else if (t == "B764") name = "Boeing 767-400";
  else if (t == "A320") name = "Airbus - A320";
  else if (t == "A20N") name = "Airbus A320neo";
  else if (t == "CL35") name = "Bombardier - Challenger 350/3500";
  else if (t == "CL30") name = "Bombardier Challenger 300";
  else if (t == "CL60") name = "Bombardier Challenger 600";
  else if (t == "C172") name = "Cessna - 172 Skyhawk";
  else if (t == "C182") name = "Cessna 182 Skylane";
  else if (t == "R44") name = "Robinson R44 Raven";
  else if (t == "R22") name = "Robinson R22";
  else if (t.startsWith("A")) name = nullptr;
  if (name) snprintf(out, cap, "%s", name);
  else if (t.startsWith("A")) snprintf(out, cap, "Airbus - model not available");
  else if (t.startsWith("B7")) snprintf(out, cap, "Boeing - model not available");
  else if (t.startsWith("E")) snprintf(out, cap, "Embraer - model not available");
  else snprintf(out, cap, "Model not available");
}

static void showDetailLocked(int slotIndex) {
  if (slotIndex < 0 || slotIndex >= MAX_VISIBLE_AIRCRAFT) return;
  const int aircraftIndex = gPlaneSlots[slotIndex].aircraftIndex;
  if (aircraftIndex < 0) return;

  Aircraft aircraft;
  xSemaphoreTake(gDataMutex, portMAX_DELAY);
  if (aircraftIndex >= gAircraftCount) {
    xSemaphoreGive(gDataMutex);
    return;
  }
  aircraft = gAircraft[aircraftIndex];
  xSemaphoreGive(gDataMutex);

  if (gDetailPanel) lv_obj_delete(gDetailPanel);
  gCompanyLabel = nullptr;
  gPhotoImage = nullptr;
  gPhotoFrame = nullptr;
  gPhotoOriginBadge = nullptr;
  gDepartureTimeLabel = gArrivalTimeLabel = nullptr;
  gDetailPanel = lv_obj_create(lv_screen_active());
  lv_obj_set_pos(gDetailPanel, 0, 0);
  lv_obj_set_size(gDetailPanel, SCREEN_WIDTH, SCREEN_HEIGHT);
  lv_obj_set_style_pad_all(gDetailPanel, 0, 0);
  lv_obj_set_style_radius(gDetailPanel, 0, 0);
  lv_obj_set_style_border_width(gDetailPanel, 0, 0);
  lv_obj_set_style_bg_color(gDetailPanel, lv_color_hex(C_BG), 0);
  lv_obj_set_style_bg_opa(gDetailPanel, LV_OPA_COVER, 0);
  lv_obj_clear_flag(gDetailPanel, LV_OBJ_FLAG_SCROLLABLE);

  // Left: flight identity. Right: full 300x156 photo.
  lv_obj_t *identity = makePanel(gDetailPanel, 12, 10, 454, 151);
  lv_obj_set_style_bg_color(identity, lv_color_hex(0x0A1B2A), 0);
  makeLabel(identity, "FLYRADAR32  |  FLIGHT DETAILS", 13, 9, 427,
            fontNormal(), C_CYAN);
  const char *flight = aircraft.callsign[0] ? aircraft.callsign :
                       (aircraft.registration[0] ? aircraft.registration : "FLIGHT");
  lv_obj_t *flightName = makeLabel(identity, flight, 13, 35, 425,
                                   fontLarge(), C_YELLOW);
  lv_obj_set_style_text_letter_space(flightName, 2, 0);
  const char *companyFromCallsign = flyAirlineFromCallsign(aircraft.callsign);
  char companyText[120];
  if (companyFromCallsign) {
    copyText(companyText, sizeof(companyText), companyFromCallsign);
  } else if (aircraft.operatorName[0]) {
    snprintf(companyText, sizeof(companyText), "Operator: %.90s", aircraft.operatorName);
  } else {
    copyText(companyText, sizeof(companyText), "Airline not available");
  }
  gCompanyLabel = makeLabel(identity, companyText, 13, 72, 425,
                            fontLarge(), C_TEXT);
  lv_label_set_long_mode(gCompanyLabel, LV_LABEL_LONG_DOT);
  char line[180];
  aircraftManufacturerAndModel(aircraft.type, line, sizeof(line));
  lv_obj_t *modelLabel = makeLabel(identity, line, 13, 112, 425,
                                   fontMedium(), C_CYAN);
  lv_label_set_long_mode(modelLabel, LV_LABEL_LONG_DOT);
  Serial.printf("AIRLINE: callsign=%s local=%s ownOp=%s\n",
                aircraft.callsign, companyFromCallsign ? companyFromCallsign : "-",
                aircraft.operatorName[0] ? aircraft.operatorName : "-");

  // Fixed-size image box, 300x156 RGB565 photo, not stretched or rescaled.
  gPhotoFrame = makePanel(gDetailPanel, 480, 10, 308, 166);
  lv_obj_set_style_pad_all(gPhotoFrame, 3, 0);
  lv_obj_set_style_bg_color(gPhotoFrame, lv_color_hex(0x101E30), 0);
  // Single centered placeholder: the old permanent "FOTO AEROMOBILE"
  // label overlapped the transient "Searching for photo..." text.
  gPhotoLabel = makeLabel(gDetailPanel, "Searching for photo...", 490, 78,
                          288, fontMedium(), C_DIM);
  lv_obj_set_height(gPhotoLabel, 28);
  lv_obj_set_style_text_align(gPhotoLabel, LV_TEXT_ALIGN_CENTER, 0);
  // S = microSD, I = Internet, - = embedded fallback. Visible over the image.
  gPhotoOriginBadge = makePanel(gDetailPanel, 751, 17, 30, 30);
  lv_obj_set_style_bg_color(gPhotoOriginBadge, lv_color_hex(0x101E30), 0);
  lv_obj_set_style_bg_opa(gPhotoOriginBadge, LV_OPA_COVER, 0);
  lv_obj_set_style_border_color(gPhotoOriginBadge, lv_color_hex(C_CYAN), 0);
  makeLabel(gPhotoOriginBadge, "?", 0, 4, 28, fontLarge(), C_CYAN);
  lv_obj_add_flag(gPhotoOriginBadge, LV_OBJ_FLAG_HIDDEN);

  // Bigger airport card, with two independent 56-pixel high name fields.
  // Explicit LVGL heights prevent a long airport name from drawing over the
  // destination heading (as happened for Rome-Fiumicino in v5.8.8).
  lv_obj_t *airports = makePanel(gDetailPanel, 12, 169, 454, 186);
  lv_obj_set_style_bg_color(airports, lv_color_hex(0x0A1B2A), 0);
  makeLabel(airports, "DEPARTURE", 13, 8, 128, fontMedium(), C_YELLOW);
  gDepartureTimeLabel = makeLabel(airports, "TAKEOFF --:--", 139, 8,
                                   296, fontNormal(), C_CYAN);
  lv_obj_set_style_text_align(gDepartureTimeLabel, LV_TEXT_ALIGN_RIGHT, 0);
  gOriginNameLabel = makeLabel(airports, "Looking up airport...", 13, 33,
                               425, &fly_font_europe_20, C_TEXT);
  lv_obj_set_height(gOriginNameLabel, 58);
  lv_label_set_long_mode(gOriginNameLabel, LV_LABEL_LONG_DOT);
  makeLabel(airports, "DESTINATION", 13, 100, 144, fontMedium(), C_YELLOW);
  gArrivalTimeLabel = makeLabel(airports, "ARRIVAL --:--", 145, 100,
                                 290, fontNormal(), C_CYAN);
  lv_obj_set_style_text_align(gArrivalTimeLabel, LV_TEXT_ALIGN_RIGHT, 0);
  gDestinationNameLabel = makeLabel(airports, "Looking up airport...", 13, 126,
                                    425, &fly_font_europe_20, C_TEXT);
  lv_obj_set_height(gDestinationNameLabel, 56);
  lv_label_set_long_mode(gDestinationNameLabel, LV_LABEL_LONG_DOT);

  // Yellow route line directly BELOW the upper-right aircraft photograph.
  // It is a route indicator, not a fabricated flight progress percentage.
  lv_obj_t *route = makePanel(gDetailPanel, 480, 185, 308, 131);
  lv_obj_set_style_bg_color(route, lv_color_hex(0x0A1B2A), 0);
  makeLabel(route, "FLIGHT ROUTE", 11, 9, 284, fontNormal(), C_CYAN);
  gOriginCodeLabel = makeLabel(route, "---", 11, 32, 125,
                               fontLarge(), C_YELLOW);
  gDestinationCodeLabel = makeLabel(route, "---", 174, 32, 123,
                                    fontLarge(), C_YELLOW);
  lv_obj_set_style_text_align(gDestinationCodeLabel, LV_TEXT_ALIGN_RIGHT, 0);
  // Gray full segment + dynamic yellow segment + moving plane marker.
  // The progress follows the ADS-B location projected onto the great circle
  // between the two airport coordinates supplied by ADSBDB.
  shapeRect(route, 20, 75, 264, 4, 0x475260, 2);
  gRouteFill = shapeRect(route, 20, 75, 1, 4, 0xFFD132, 2);
  lv_obj_set_width(gRouteFill, 0);
  shapeRect(route, 17, 71, 10, 10, 0xFFD132, 5);
  shapeRect(route, 281, 71, 10, 10, 0xFFD132, 5);
  gRoutePlane = makeLabel(route, LV_SYMBOL_RIGHT, 6, 65, 28,
                          fontLarge(), C_YELLOW);
  lv_obj_set_style_text_align(gRoutePlane, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_set_height(gRoutePlane, 25);
  lv_obj_add_flag(gRoutePlane, LV_OBJ_FLAG_HIDDEN);
  gRouteLabel = makeLabel(route, "Route position unavailable",
                          9, 93, 292, fontSmall(), C_DIM);
  lv_obj_set_style_text_align(gRouteLabel, LV_TEXT_ALIGN_CENTER, 0);

  // Compact metric cards: the saved vertical space goes to the airport box.
  lv_obj_t *altCard = makePanel(gDetailPanel, 12, 363, 218, 42);
  lv_obj_t *speedCard = makePanel(gDetailPanel, 238, 363, 228, 42);
  lv_obj_t *trackCard = makePanel(gDetailPanel, 12, 412, 218, 42);
  lv_obj_t *verticalCard = makePanel(gDetailPanel, 238, 412, 228, 42);
  makeLabel(altCard, "ALTITUDE", 10, 3, 190, fontNormal(), C_CYAN);
  snprintf(line, sizeof(line), "%d ft", aircraft.altitudeFt);
  makeLabel(altCard, line, 10, 21, 196, fontMedium(), C_TEXT);
  makeLabel(speedCard, "SPEED", 10, 3, 204, fontNormal(), C_CYAN);
  snprintf(line, sizeof(line), "%d kt", aircraft.speedKt);
  makeLabel(speedCard, line, 10, 21, 204, fontMedium(), C_TEXT);
  makeLabel(trackCard, "HEADING", 10, 3, 190, fontNormal(), C_CYAN);
  snprintf(line, sizeof(line), "%03d degrees", aircraft.headingDeg);
  makeLabel(trackCard, line, 10, 21, 196, fontMedium(), C_TEXT);
  makeLabel(verticalCard, "VERTICAL SPEED", 10, 3, 204, fontNormal(), C_CYAN);
  snprintf(line, sizeof(line), "%+d ft/min", aircraft.verticalFpm);
  makeLabel(verticalCard, line, 10, 21, 204, fontMedium(), C_TEXT);

  // Bottom-right: registration and live radar information.
  lv_obj_t *facts = makePanel(gDetailPanel, 480, 324, 308, 132);
  snprintf(line, sizeof(line), "REG.  %s",
           aircraft.registration[0] ? aircraft.registration : "--");
  makeLabel(facts, line, 12, 8, 281, fontMedium(), C_YELLOW);
  snprintf(line, sizeof(line), "DISTANCE   %.1f km", aircraft.distanceKm);
  makeLabel(facts, line, 12, 35, 284, fontNormal(), C_TEXT);
  snprintf(line, sizeof(line), "BEARING   %.0f degrees", aircraft.bearingDeg);
  makeLabel(facts, line, 12, 59, 284, fontNormal(), C_TEXT);
  snprintf(line, sizeof(line), "SQUAWK   %s",
           aircraft.squawk[0] ? aircraft.squawk : "----");
  makeLabel(facts, line, 12, 91, 170, fontNormal(),
            isEmergency(aircraft) ? C_RED : C_CYAN);
  lv_obj_t *close = makeButton(facts, "CLOSE", 189, 84, 106, 39, closeDetailEvent);
  lv_obj_set_style_border_color(close, lv_color_hex(C_CYAN), 0);
  lv_obj_t *closeLabel = lv_obj_get_child(close, 0);
  lv_obj_set_style_text_font(closeLabel, fontMedium(), 0);

  // Keep selected aircraft identity so progress refreshes with ADS-B every 5s.
  copyText(gSelectedAircraftHex, sizeof(gSelectedAircraftHex), aircraft.hex);
  copyText(gSelectedAircraftCallsign, sizeof(gSelectedAircraftCallsign), aircraft.callsign);
  gRouteCoordinatesValid = false;
  // Keep the photo lookup protocol unchanged except the in-flight fallback.
  copyText(gDetailLookupHex, sizeof(gDetailLookupHex), aircraft.hex);
  copyText(gDetailLookupCallsign, sizeof(gDetailLookupCallsign), aircraft.callsign);
  copyText(gDetailLookupRegistration, sizeof(gDetailLookupRegistration), aircraft.registration);
  char readableModel[100];
  aircraftManufacturerAndModel(aircraft.type, readableModel, sizeof(readableModel));
  copyText(gDetailLookupModel, sizeof(gDetailLookupModel), readableModel);
  copyText(gDetailLookupOperator, sizeof(gDetailLookupOperator), aircraft.operatorName);
  gDetailAirline[0] = 0;
  copyText(gDetailLookupType, sizeof(gDetailLookupType), aircraft.type);
  gDetailPhotoUrl[0] = 0;
  gPhotoWidth = gPhotoHeight = 0;
  gDetailLookupReady = false;
  gDetailLookupRequested = true;
}

static void publishPendingStatus() {
  if (!gStatusPublishPending || !gMainScreenActive) return;
  char message[sizeof(gPendingStatus)];
  xSemaphoreTake(gDataMutex, portMAX_DELAY);
  copyText(message, sizeof(message), gPendingStatus);
  gStatusPublishPending = false;
  xSemaphoreGive(gDataMutex);

  esp_lv_adapter_lock(-1);
  setStatusLocked(message);
  esp_lv_adapter_unlock();
}

static void publishPendingMap() {
  if (!gMapPublishPending || !gMainScreenActive || !gMapImage) return;
  const int index = gMapPendingIndex;
  const uint32_t serial = gMapPendingSerial;
  const float range = gMapPendingRange;

  if (index < 0 || index > 1 || !gMapBuffer[index] ||
      serial != gMapRequestSerial) {
    gMapPendingIndex = -1;
    gMapPublishPending = false;
    return;
  }

  esp_lv_adapter_lock(-1);
  gMapActiveIndex = index;
  gDisplayedRangeKm = range;
  gDisplayedLatitude = gPendingLatitude;
  gDisplayedLongitude = gPendingLongitude;
  initMapDescriptor(gMapBuffer[index]);
  lv_image_set_src(gMapImage, nullptr);
  lv_image_set_src(gMapImage, &gMapDescriptor);
  gMapAnchorLat = gPendingLatitude;
  gMapAnchorLon = gPendingLongitude;
  gMapShiftX = gMapShiftY = 0;
  lv_image_set_scale(gMapImage, 256);
  lv_obj_set_pos(gMapImage, -MAP_MARGIN_X, -MAP_MARGIN_Y);
  if (gPlaneLayer) lv_obj_set_pos(gPlaneLayer, 0, 0);
  gPreviewDx = gPreviewDy = 0;
  lv_obj_move_background(gMapImage);
  if (gMapPlaceholder)
    lv_obj_add_flag(gMapPlaceholder, LV_OBJ_FLAG_HIDDEN);
  updateRangeLabelLocked(false);
  drawAircraftLocked(gDisplayedRangeKm);
  updateHomeMarkerLocked();
  lv_obj_invalidate(gMapImage);
  setStatusLocked("");
  esp_lv_adapter_unlock();

  gMapPendingIndex = -1;
  // Let LVGL finish the one full-screen map redraw before starting another
  // TLS/JSON operation that also uses PSRAM bandwidth.
  gNetworkPauseUntilMs = millis() + 150UL;
  gMapPublishPending = false;
  gAircraftRequested = true;
  gNextAircraftAttemptMs = 0;
}

static void publishPendingAircraft() {
  if (!gAircraftPublishPending || !gMainScreenActive) return;
  xSemaphoreTake(gDataMutex, portMAX_DELAY);
  gAircraftPublishPending = false;
  xSemaphoreGive(gDataMutex);
  esp_lv_adapter_lock(-1);
  drawAircraftLocked(gDisplayedRangeKm);
  updateRouteProgressLocked();
  esp_lv_adapter_unlock();
}

static void applyZoomRequests() {
  int steps = gZoomStepsRequested;
  if (!steps) return;
  gZoomStepsRequested = 0;
  const int oldIndex = gRangePresetIndex;
  gRangePresetIndex = constrain(gRangePresetIndex + steps, 0,
                                RANGE_PRESET_COUNT - 1);
  if (gRangePresetIndex == oldIndex) return;

  gRequestedRangeKm = RANGE_PRESETS[gRangePresetIndex];
  ++gMapRequestSerial;
  gMapRequested = true;
  gAircraftRequested = true;
  gNextMapAttemptMs = millis() + MAP_SETTLE_MS;
  gNextAircraftAttemptMs = millis() + MAP_SETTLE_MS;

  esp_lv_adapter_lock(-1);
  // Keep source bitmap at native scale until the new JPEG is ready.
  // Scaling a 1024x704 LVGL image on every zoom invalidates large RGB regions.
  if (gMapImage) lv_image_set_scale(gMapImage, 256);
  updateRangeLabelLocked(true);
  setStatusLocked("Loading new map...");
  esp_lv_adapter_unlock();
}

}  // namespace

void radarResyncRgbDma() {
  if (!gBoard) return;
  LCD *lcd = gBoard->getLCD();
  if (!lcd || !lcd->getBus()) return;
  if (lcd->getBus()->getBasicAttributes().type != ESP_PANEL_BUS_TYPE_RGB)
    return;
  esp_lcd_panel_handle_t panel = lcd->getRefreshPanelHandle();
  if (!panel) {
    Serial.println("RGB SYNC: panel handle unavailable");
    return;
  }
  const esp_err_t result = esp_lcd_rgb_panel_restart(panel);
  Serial.printf("RGB SYNC: VSYNC DMA restart: %s (%d)\n",
                esp_err_to_name(result), (int)result);
}

bool radarInitDisplayAndLVGL() {
  // Keep this sequence identical to the proven CalendarMoon display path.
  gBoard = new Board();
  if (!gBoard || !gBoard->init()) return false;

  const esp_lv_adapter_rotation_t rotation = ESP_LV_ADAPTER_ROTATE_0;
  const esp_lv_adapter_tear_avoid_mode_t tearMode =
      ESP_LV_ADAPTER_TEAR_AVOID_MODE_DEFAULT_RGB;
  LV_UNUSED(tearMode);
  const uint8_t fbCount = 1;

  LCD *lcd = gBoard->getLCD();
  if (!lcd) return false;
  auto *bus = lcd->getBus();
  if (bus->getBasicAttributes().type == ESP_PANEL_BUS_TYPE_RGB) {
    lcd->configFrameBufferNumber(fbCount);
    const uint32_t rgbBouncePixels = lcd->getFrameWidth() * 20;
    static_cast<BusRGB *>(bus)->configRGB_BounceBufferSize(rgbBouncePixels);
    Serial.printf("RGB: one panel FB, bounce=%u pixels\n",
                  (unsigned)rgbBouncePixels);
  }

  if (!gBoard->begin()) return false;

  esp_lv_adapter_config_t adapterConfig = ESP_LV_ADAPTER_DEFAULT_CONFIG();
  adapterConfig.task_stack_size = 14 * 1024;
  adapterConfig.task_priority = 2;
  adapterConfig.task_core_id = ARDUINO_RUNNING_CORE;
  adapterConfig.task_min_delay_ms = 2;
  adapterConfig.task_max_delay_ms = 20;
  ESP_ERROR_CHECK(esp_lv_adapter_init(&adapterConfig));

  esp_lv_adapter_display_config_t displayConfig =
      ESP_LV_ADAPTER_DISPLAY_RGB_DEFAULT_CONFIG(
          lcd, (uint16_t)lcd->getFrameWidth(),
          (uint16_t)lcd->getFrameHeight(), rotation);
  displayConfig.profile.use_psram = true;
  lv_display_t *display = esp_lv_adapter_register_display(&displayConfig);
  if (!display) return false;

  if (gBoard->getTouch()) {
    esp_lv_adapter_touch_config_t touchConfig =
        ESP_LV_ADAPTER_TOUCH_DEFAULT_CONFIG(display, gBoard->getTouch());
    if (!esp_lv_adapter_register_touch(&touchConfig)) return false;
  }

  ESP_ERROR_CHECK(esp_lv_adapter_start());
  gDataMutex = xSemaphoreCreateMutex();
  return gDataMutex != nullptr;
}

// Lo splash JPEG viene decodificato una sola volta in PSRAM prima di mostrare
// il logo; la rete parte molto piu tardi. LVGL mantiene il descrittore finche
// la schermata viene sostituita, poi rilasciamo il framebuffer temporaneo.
static uint16_t *gSplashPixels = nullptr;
static lv_image_dsc_t gSplashDescriptor = {};

static bool splashJpegBlock(int16_t x, int16_t y, uint16_t w, uint16_t h,
                            uint16_t *pixels) {
  if (!gSplashPixels || !pixels) return false;
  for (uint16_t row = 0; row < h; ++row) {
    const int destY = y + (int)row;
    if (destY < 0 || destY >= SCREEN_HEIGHT) continue;
    int destX = x, sourceX = 0, count = (int)w;
    if (destX < 0) { sourceX = -destX; count -= sourceX; destX = 0; }
    if (destX + count > SCREEN_WIDTH) count = SCREEN_WIDTH - destX;
    if (count <= 0) continue;
    memcpy(gSplashPixels + (size_t)destY * SCREEN_WIDTH + destX,
           pixels + (size_t)row * w + sourceX,
           (size_t)count * sizeof(uint16_t));
  }
  return true;
}

static bool prepareSplashImage() {
  uint16_t jpegWidth = 0, jpegHeight = 0;
  int status = TJpgDec.getJpgSize(&jpegWidth, &jpegHeight,
                                   FLYRADAR_SPLASH_JPEG, FLYRADAR_SPLASH_JPEG_SIZE);
  if (status || jpegWidth != SCREEN_WIDTH || jpegHeight != SCREEN_HEIGHT) {
    Serial.printf("SPLASH: invalid JPEG (%d, %ux%u)\n",
                  status, jpegWidth, jpegHeight);
    return false;
  }

  gSplashPixels = (uint16_t *)heap_caps_malloc(
      SPLASH_BYTES, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!gSplashPixels) {
    Serial.printf("SPLASH: insufficient PSRAM (%u bytes)\n", (unsigned)SPLASH_BYTES);
    return false;
  }
  memset(gSplashPixels, 0, SPLASH_BYTES);
  TJpgDec.setJpgScale(1);
  TJpgDec.setSwapBytes(false);
  TJpgDec.setCallback(splashJpegBlock);
  status = TJpgDec.drawJpg(0, 0, FLYRADAR_SPLASH_JPEG, FLYRADAR_SPLASH_JPEG_SIZE);
  if (status) {
    Serial.printf("SPLASH: JPEG decoder error=%d\n", status);
    heap_caps_free(gSplashPixels);
    gSplashPixels = nullptr;
    return false;
  }
  memset(&gSplashDescriptor, 0, sizeof(gSplashDescriptor));
  gSplashDescriptor.header.magic = LV_IMAGE_HEADER_MAGIC;
  gSplashDescriptor.header.cf = LV_COLOR_FORMAT_RGB565;
  gSplashDescriptor.header.w = SCREEN_WIDTH;
  gSplashDescriptor.header.h = SCREEN_HEIGHT;
  gSplashDescriptor.header.stride = SCREEN_WIDTH * sizeof(uint16_t);
  gSplashDescriptor.data_size = SPLASH_BYTES;
  gSplashDescriptor.data = (const uint8_t *)gSplashPixels;
  Serial.printf("SPLASH: FlyRadar32 800x480 ready (JPEG=%u bytes)\n",
                (unsigned)FLYRADAR_SPLASH_JPEG_SIZE);
  return true;
}

// Richiamare SOLO dopo lv_obj_clean(screen) e con mutex LVGL acquisito.
static void releaseSplashPixelsLocked() {
  if (!gSplashPixels) return;
  heap_caps_free(gSplashPixels);
  gSplashPixels = nullptr;
  memset(&gSplashDescriptor, 0, sizeof(gSplashDescriptor));
  Serial.println("SPLASH: temporary framebuffer released");
}

static void radarShowSplashFallback(uint32_t durationMs) {
  esp_lv_adapter_lock(-1);
  lv_obj_t *screen = lv_screen_active();
  lv_obj_clean(screen);
  releaseSplashPixelsLocked();
  lv_obj_set_style_pad_all(screen, 0, 0);
  lv_obj_set_style_bg_color(screen, lv_color_hex(C_BG), 0);
  lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, 0);
  lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_scrollbar_mode(screen, LV_SCROLLBAR_MODE_OFF);

  lv_obj_t *ring = lv_obj_create(screen);
  lv_obj_set_pos(ring, 320, 52);
  lv_obj_set_size(ring, 160, 160);
  lv_obj_set_style_radius(ring, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_opa(ring, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_color(ring, lv_color_hex(C_CYAN), 0);
  lv_obj_set_style_border_width(ring, 2, 0);
  lv_obj_clear_flag(ring, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(ring, LV_OBJ_FLAG_CLICKABLE);
  shapeRect(ring, 77, 20, 5, 118, C_CYAN, 2);
  shapeRect(ring, 34, 76, 92, 6, C_CYAN, 3);
  shapeRect(ring, 58, 129, 44, 5, C_CYAN, 2);

  lv_obj_t *title = makeLabel(screen, "FLYRADAR32", 0, 247, SCREEN_WIDTH,
                              fontLarge(), C_CYAN);
  lv_obj_set_style_text_align(title, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_set_style_text_letter_space(title, 2, 0);
  lv_obj_t *subtitle = makeLabel(
      screen, "SATELLITE MAP  |  LIVE AIR TRAFFIC",
      0, 298, SCREEN_WIDTH, fontMedium(), C_TEXT);
  lv_obj_set_style_text_align(subtitle, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_t *version = makeLabel(screen, "WAVESHARE 7  |  VERSION 5.9.3",
                                0, 348, SCREEN_WIDTH, fontNormal(), C_DIM);
  lv_obj_set_style_text_align(version, LV_TEXT_ALIGN_CENTER, 0);
  esp_lv_adapter_unlock();
  delay(durationMs);
}

void radarShowSplash(uint32_t durationMs) {
  // Decode outside the LVGL lock; only the final image is drawn by LVGL.
  if (!prepareSplashImage()) {
    radarShowSplashFallback(durationMs);
    return;
  }

  esp_lv_adapter_lock(-1);
  lv_obj_t *screen = lv_screen_active();
  lv_obj_clean(screen);
  lv_obj_set_style_pad_all(screen, 0, 0);
  lv_obj_set_style_bg_color(screen, lv_color_hex(C_BG), 0);
  lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, 0);
  lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_scrollbar_mode(screen, LV_SCROLLBAR_MODE_OFF);
  lv_obj_t *splashImage = lv_image_create(screen);
  if (splashImage) {
    lv_obj_set_pos(splashImage, 0, 0);
    lv_image_set_src(splashImage, &gSplashDescriptor);
    lv_obj_clear_flag(splashImage, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_clear_flag(splashImage, LV_OBJ_FLAG_SCROLLABLE);
  }
  esp_lv_adapter_unlock();
  if (!splashImage) {
    Serial.println("SPLASH: lv_image_create failed; fallback");
    // gSplashPixels stays allocated until the fallback replaces the screen.
    radarShowSplashFallback(durationMs);
    return;
  }
  delay(durationMs);
}

void radarShowBoot(const char *message) {
  esp_lv_adapter_lock(-1);
  lv_obj_t *screen = lv_screen_active();
  lv_obj_clean(screen);
  releaseSplashPixelsLocked();
  lv_obj_set_style_pad_all(screen, 0, 0);
  lv_obj_set_style_bg_color(screen, lv_color_hex(C_BG), 0);
  lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, 0);
  lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_scrollbar_mode(screen, LV_SCROLLBAR_MODE_OFF);
  lv_obj_t *title = makeLabel(screen, "FLYRADAR32", 0, 157, SCREEN_WIDTH,
                              fontLarge(), C_CYAN);
  lv_obj_set_style_text_align(title, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_set_style_text_letter_space(title, 2, 0);
  lv_obj_t *label = makeLabel(screen, message ? message : "Starting...", 30,
                              225, SCREEN_WIDTH - 60,
                              fontMedium(), C_TEXT);
  lv_obj_set_style_text_align(label, LV_TEXT_ALIGN_CENTER, 0);
  esp_lv_adapter_unlock();
}

void radarCreateMainScreen() {
  gMainScreenActive = false;
  gDetailPanel = nullptr;
  gCompanyLabel = nullptr;
  gRouteFill = gRoutePlane = nullptr;
  gDepartureTimeLabel = gArrivalTimeLabel = nullptr;
  gRouteCoordinatesValid = false;
  gHomeMarker = nullptr;
  gRouteLabel = gPhotoLabel = gPhotoImage = nullptr;
  gPhotoOriginBadge = nullptr;
  gWifiDot = gWifiRssiLabel = nullptr;
  for (auto &arc : gWifiArcs) arc = nullptr;
  gOriginCodeLabel = gDestinationCodeLabel = nullptr;
  gOriginNameLabel = gDestinationNameLabel = nullptr;
  gDetailSlotRequested = -1;
  gCloseDetailRequested = false;
  gSettingsRequested = false;
  gZoomStepsRequested = 0;
  gHomeRequested = false;
  gGestureActive = false;
  gPreviewDx = gPreviewDy = 0;
  esp_lv_adapter_set_touch_observer(nullptr);
  // Preserve navigation on screen recreation, initialize on first display.
  static bool navigationInitialized = false;
  if (!navigationInitialized) {
    gViewLatitude = gDisplayedLatitude = cmLatitude();
    gViewLongitude = gDisplayedLongitude = cmLongitude();
    navigationInitialized = true;
  }

  // Select the nearest defined preset without reading/writing flash.
  float best = 100000.0f;
  for (int i = 0; i < RANGE_PRESET_COUNT; ++i) {
    const float difference = fabsf(RANGE_PRESETS[i] - gRequestedRangeKm);
    if (difference < best) {
      best = difference;
      gRangePresetIndex = i;
    }
  }
  gRequestedRangeKm = RANGE_PRESETS[gRangePresetIndex];
  if (gMapActiveIndex < 0) gDisplayedRangeKm = gRequestedRangeKm;

  esp_lv_adapter_lock(-1);
  lv_obj_t *screen = lv_screen_active();
  lv_obj_clean(screen);
  releaseSplashPixelsLocked();
  lv_obj_set_style_pad_all(screen, 0, 0);
  lv_obj_set_style_bg_color(screen, lv_color_hex(C_BG), 0);
  lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, 0);
  lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_scrollbar_mode(screen, LV_SCROLLBAR_MODE_OFF);

  gMapImage = lv_image_create(screen);
  lv_obj_set_pos(gMapImage, -MAP_MARGIN_X + gMapShiftX,
                -MAP_MARGIN_Y + gMapShiftY);
  lv_obj_clear_flag(gMapImage, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_clear_flag(gMapImage, LV_OBJ_FLAG_SCROLLABLE);
  if (gMapActiveIndex >= 0 && gMapBuffer[gMapActiveIndex]) {
    initMapDescriptor(gMapBuffer[gMapActiveIndex]);
    lv_image_set_src(gMapImage, &gMapDescriptor);
  }

  gMapPlaceholder = makeLabel(screen, "LOADING MAP", 0, 220,
                              SCREEN_WIDTH, fontMedium(), C_DIM);
  lv_obj_set_style_text_align(gMapPlaceholder, LV_TEXT_ALIGN_CENTER, 0);
  if (gMapActiveIndex >= 0)
    lv_obj_add_flag(gMapPlaceholder, LV_OBJ_FLAG_HIDDEN);

  gPlaneLayer = lv_obj_create(screen);
  lv_obj_set_pos(gPlaneLayer, 0, 0);
  lv_obj_set_size(gPlaneLayer, SCREEN_WIDTH, SCREEN_HEIGHT);
  lv_obj_set_style_pad_all(gPlaneLayer, 0, 0);
  lv_obj_set_style_border_width(gPlaneLayer, 0, 0);
  lv_obj_set_style_bg_opa(gPlaneLayer, LV_OPA_TRANSP, 0);
  lv_obj_clear_flag(gPlaneLayer, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(gPlaneLayer, LV_OBJ_FLAG_CLICKABLE);
  Serial.printf("RADAR UI: create icons (12), heap=%u, PSRAM=%u\n", (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getFreePsram());
  createPlaneSlotsLocked();
  Serial.printf("RADAR UI: icons ready, heap=%u\n", (unsigned)ESP.getFreeHeap());

  Serial.println("RADAR UI: location marker / header");
  // Georeferenced location marker, independent of the current map centre.
  lv_obj_t *centre = lv_obj_create(screen);
  gHomeMarker = centre;
  lv_obj_set_pos(centre, SCREEN_WIDTH / 2 - 6, SCREEN_HEIGHT / 2 - 6);
  lv_obj_set_size(centre, 12, 12);
  lv_obj_set_style_radius(centre, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_color(centre, lv_color_hex(C_RED), 0);
  lv_obj_set_style_bg_opa(centre, LV_OPA_COVER, 0);
  lv_obj_set_style_border_color(centre, lv_color_hex(0xFFFFFF), 0);
  lv_obj_set_style_border_width(centre, 2, 0);
  lv_obj_clear_flag(centre, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(centre, LV_OBJ_FLAG_CLICKABLE);
  updateHomeMarkerLocked();

  makeButton(screen, LV_SYMBOL_MINUS, 8, 8, 48, 42, zoomEvent,
             (void *)(intptr_t)-1);
  lv_obj_t *rangePanel = makePanel(screen, 62, 8, 156, 42);
  gRangeLabel = makeLabel(rangePanel, "", 4, 12, 148,
                          fontNormal(), C_CYAN);
  lv_obj_set_style_text_align(gRangeLabel, LV_TEXT_ALIGN_CENTER, 0);
  updateRangeLabelLocked(false);
  makeButton(screen, LV_SYMBOL_PLUS, 224, 8, 48, 42, zoomEvent,
             (void *)(intptr_t)1);

  // Home always returns to the GPS coordinates saved in Settings.
  makeButton(screen, LV_SYMBOL_HOME, 280, 8, 48, 42, homeEvent);
  lv_obj_t *clockPanel = makePanel(screen, 333, 8, 134, 42);
  gClockLabel = makeLabel(clockPanel, "--:--", 0, 8, 134,
                          fontLarge(), C_TEXT);
  lv_obj_set_style_text_align(gClockLabel, LV_TEXT_ALIGN_CENTER, 0);
  createWifiSignalLocked(screen);
  updateWifiSignalLocked();

  lv_obj_t *countPanel = makePanel(screen, 589, 8, 145, 42);
  gCountLabel = makeLabel(countPanel, "AIRCRAFT 0", 0, 12, 145,
                          fontNormal(), C_TEXT);
  lv_obj_set_style_text_align(gCountLabel, LV_TEXT_ALIGN_CENTER, 0);

  lv_obj_t *settings = makeButton(screen, LV_SYMBOL_SETTINGS,
                                  742, 8, 50, 42, settingsEvent);
  LV_UNUSED(settings);

  lv_obj_t *locationPanel = makePanel(screen, 8, 432, 466, 40);
  String location = "CENTER  ";
  location += cmLocation();
  makeLabel(locationPanel, location.c_str(), 10, 11, 446,
            fontSmall(), C_TEXT);

  lv_obj_t *sourcePanel = makePanel(screen, 482, 432, 310, 40);
  lv_obj_t *source = makeLabel(sourcePanel,
      "Esri Imagery  |  Live ADS-B adsb.fi", 0, 12, 310,
      fontSmall(), C_DIM);
  lv_obj_set_style_text_align(source, LV_TEXT_ALIGN_CENTER, 0);

  gStatusPanel = makePanel(screen, 190, 383, 420, 38);
  gStatusLabel = makeLabel(gStatusPanel, "", 7, 11, 406,
                           fontSmall(), C_YELLOW);
  lv_obj_set_style_text_align(gStatusLabel, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_add_flag(gStatusPanel, LV_OBJ_FLAG_HIDDEN);

  Serial.printf("RADAR UI: before first paint, heap=%u\n", (unsigned)ESP.getFreeHeap());
  updateClockLocked();
  drawAircraftLocked(gDisplayedRangeKm);
  Serial.println("RADAR UI: before unlock");
  esp_lv_adapter_unlock();

  gMainScreenActive = true;
  esp_lv_adapter_set_touch_observer(mapTouchGesture);
  if (gMapActiveIndex < 0) {
    gMapRequested = true;
    gNextMapAttemptMs = 0;
    postStatus("Loading satellite map...");
  }
  gAircraftRequested = true;
  gNextAircraftAttemptMs = 0;
  gLastAircraftRequestMs = millis();
}

void radarStartNetwork() {
  gNetworkEnabled = true;
  if (gNetworkTask) return;

  // Put the background stack in PSRAM, preserving contiguous internal RAM
  // for the TLS handshake exactly as done by the CalendarMoon memory fixes.
  BaseType_t created = xTaskCreatePinnedToCoreWithCaps(
      networkWorker, "flyradar_net", 18 * 1024, nullptr, 1,
      &gNetworkTask, 0, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (created != pdPASS) {
    Serial.println("NETWORK: PSRAM stack unavailable; internal fallback");
    created = xTaskCreatePinnedToCore(networkWorker, "flyradar_net",
                                     12 * 1024, nullptr, 1,
                                     &gNetworkTask, 0);
  }
  if (created != pdPASS) {
    gNetworkTask = nullptr;
    gNetworkEnabled = false;
    postStatus("Cannot start network task");
    Serial.println("NETWORK: task creation failed");
  }
}

void radarLoop() {
  if (!gMainScreenActive) return;

  if (gHomeRequested) {
    gHomeRequested = false;
    gViewLatitude = cmLatitude();
    gViewLongitude = cmLongitude();
    ++gMapRequestSerial;
    gMapRequested = true;
    gAircraftRequested = true;
    gNextMapAttemptMs = millis() + MAP_SETTLE_MS;
    gNextAircraftAttemptMs = millis() + MAP_SETTLE_MS;
    esp_lv_adapter_lock(-1);
    if (gMapImage) {
      lv_image_set_scale(gMapImage, 256);
      lv_obj_set_pos(gMapImage, -MAP_MARGIN_X + gMapShiftX,
                     -MAP_MARGIN_Y + gMapShiftY);
    }
    if (gPlaneLayer) lv_obj_set_pos(gPlaneLayer, 0, 0);
    gPreviewDx = gPreviewDy = 0;
    updateHomeMarkerLocked();
    setStatusLocked("Returning to home location...");
    esp_lv_adapter_unlock();
  }
  applyZoomRequests();
  publishPendingMap();
  publishPendingAircraft();
  publishPendingStatus();
  publishDetailLookup();

  if (gCloseDetailRequested) {
    gCloseDetailRequested = false;
    esp_lv_adapter_lock(-1);
    if (gDetailPanel) lv_obj_delete(gDetailPanel);
    lv_obj_invalidate(lv_screen_active());
    gDetailPanel = nullptr;
    gPhotoOriginBadge = nullptr;
    gPhotoFrame = gPhotoLabel = gPhotoImage = nullptr;
    gCompanyLabel = nullptr;
    gRouteFill = gRoutePlane = gRouteLabel = nullptr;
    gDepartureTimeLabel = gArrivalTimeLabel = nullptr;
    gRouteCoordinatesValid = false;
    esp_lv_adapter_unlock();
  }

  if (gDetailSlotRequested >= 0) {
    const int slot = gDetailSlotRequested;
    gDetailSlotRequested = -1;
    esp_lv_adapter_lock(-1);
    showDetailLocked(slot);
    lv_obj_invalidate(lv_screen_active());
    esp_lv_adapter_unlock();
  }

  if (gSettingsRequested) {
    gSettingsRequested = false;
    gMainScreenActive = false;
    esp_lv_adapter_set_touch_observer(nullptr);
    const bool screenWasReplaced = cmRunSettingsMenu(false);
    if (screenWasReplaced) {
      radarCreateMainScreen();
    } else {
      gMainScreenActive = true;
      gAircraftRequested = true;
      gNextAircraftAttemptMs = 0;
    }
    return;
  }

  if (millis() - gLastClockMs >= 1000UL) {
    gLastClockMs = millis();
    esp_lv_adapter_lock(-1);
    updateClockLocked();
    updateWifiSignalLocked();
    esp_lv_adapter_unlock();
  }

  if (millis() - gLastAircraftRequestMs >= AIRCRAFT_REFRESH_MS) {
    gLastAircraftRequestMs = millis();
    if (!gNetworkBusy && !gAircraftRequested) {
      gAircraftRequested = true;
      gNextAircraftAttemptMs = 0;
    }
  }
}
