FlyRadar32 v5.9.2 — English UI

All identified Italian runtime UI labels, notices and placeholders in RadarUI.cpp have been translated. Settings firmware label updated. The display driver, gestures, microSD and networking behaviour are unchanged from v5.9.1.

Open FlyRadar_Waveshare7_v5.9.2.ino with Arduino IDE.
No full Arduino or on-device compilation was performed.
