#pragma once
#include <lvgl.h>
LV_FONT_DECLARE(fly_font_europe_20);
