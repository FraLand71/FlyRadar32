#pragma once
// Optional scheduled/actual times provider for one selected flight.
// Register at https://aviationstack.com/ and provide your API key here.
// Without a key FlyRadar still displays GPS-based ETA (approximate) when possible,
// but it will NOT fabricate takeoff times.
// Do not commit/share your filled-in API key in a public ZIP.
#define FLY_AVIATIONSTACK_API_KEY ""
