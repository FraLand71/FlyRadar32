#pragma once
#include <Arduino.h>

void beginKnownWiFi();  // Asincrono, chiamabile mentre e' visibile lo splash.
bool connectKnownWiFi(uint32_t timeoutPerNetworkMs = 10000);
bool syncNTP(uint32_t timeoutMs = 30000);
bool getNow(struct tm &out);
void maintainWiFi();
