#pragma once
#include <Arduino.h>
// Displays first-boot screens and stores Wi-Fi/location in NVS.
// Returns only after a successful, fully saved configuration.
bool cmRunFirstSetup();

// Edit a single setting category without erasing the existing NVS values.
// These return false on BACK/error; successful changes are saved.
bool cmRunChangeWiFi();
bool cmRunChangeLocation();
