#pragma once

// FlyRadar v5: Wi-Fi and location are configured on the touchscreen.
#include "RuntimeConfig.h"

#define FLYRADAR_VERSION "5.9.3"

#define LOCATION_NAME cmLocation()
#define LATITUDE      cmLatitude()
#define LONGITUDE     cmLongitude()
#define TIMEZONE      cmTZ()

#define NTP_SERVER_1 "pool.ntp.org"
#define NTP_SERVER_2 "time.google.com"
#define NTP_SERVER_3 "time.cloudflare.com"

#define SCREEN_WIDTH  800
#define SCREEN_HEIGHT 480

// Network refresh and display limits.
#define DEFAULT_RANGE_KM          40.0f
#define AIRCRAFT_REFRESH_MS       5000UL
#define MAP_RETRY_MS             30000UL
#define ADSB_RETRY_MS            20000UL
#define DEFAULT_MIN_ALTITUDE_FT      0
#define MAX_AIRCRAFT                60
#define MAX_VISIBLE_AIRCRAFT        12

// GT911 dual touch gestures enabled through the LVGL touch adapter.
#define ENABLE_PINCH_ZOOM 1
