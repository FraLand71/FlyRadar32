#pragma once
// JetPhotos non pubblica un endpoint API ufficiale aperto per uso esterno.
// Indicare qui SOLO un endpoint HTTPS fornito/autorizzato dal titolare
// dei diritti, che restituisca JPEG + fotografo + pagina JetPhotos.
// Non inserire qui l'indirizzo della homepage o del motore di ricerca JetPhotos.
// Esempio (fittizio): "https://mio-provider-autorizzato.example/api/jetphotos"
#define JETPHOTOS_AUTHORIZED_METADATA_URL ""
