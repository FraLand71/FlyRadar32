#pragma once
#include <Arduino.h>
// Loaded once at boot from Preferences namespace "flyradar".
void cmLoadConfig();
bool cmHasConfig();
bool cmSaveConfig(const char* ssid, const char* pass, const char* name,
                  double latitude, double longitude, const char* zone, const char* posix);
void cmClearConfig();
const char* cmSSID();
const char* cmPassword();
const char* cmLocation();
const char* cmTZ();
const char* cmIANA();
double cmLatitude();
double cmLongitude();
