#include "SetupWizard.h"
#include "RuntimeConfig.h"
#include "CMTimezones.h"
#include "esp_lv_adapter_arduino.h"
#include <lvgl.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <string.h>
#include <stdlib.h>
#include <esp_heap_caps.h>

// All UI calls are protected with esp_lv_adapter_lock(). The callbacks only
// capture input or set a flag; network requests run in the Arduino task.
namespace {
enum Step { STEP_WIFI, STEP_PASSWORD, STEP_PLACE, STEP_WAIT };
enum KeyMode { LOWER, UPPER, SYMBOLS };
enum WizardMode { WIZARD_INITIAL, WIZARD_WIFI_ONLY, WIZARD_LOCATION_ONLY };
static WizardMode wizardMode = WIZARD_INITIAL;
static Step step = STEP_WIFI;
static KeyMode keyMode = LOWER;
static volatile bool scanRequested = false;
static volatile bool nextRequested = false;
static volatile bool backRequested = false;
static bool showPassword = false;
static lv_obj_t* dropdown = nullptr;
static lv_obj_t* entryLabel = nullptr;
static lv_obj_t* statusLabel = nullptr;
static lv_obj_t* keyboard = nullptr;
static lv_obj_t* eyeText = nullptr;
static constexpr int MAX_NET = 15;
static String networks[MAX_NET];
static int networksCount = 0;
static int selected = -1;
static char pass[65] = {};
static char place[80] = {};

static const char* kbLower[] = {
  "1","2","3","4","5","6","7","8","9","0","DEL","\n",
  "q","w","e","r","t","y","u","i","o","p","\n",
  "a","s","d","f","g","h","j","k","l","\n",
  "ABC","z","x","c","v","b","n","m",".","-","\n",
  "123","@","_","SPACE","/",",","?","OK",""
};
static const char* kbUpper[] = {
  "1","2","3","4","5","6","7","8","9","0","DEL","\n",
  "Q","W","E","R","T","Y","U","I","O","P","\n",
  "A","S","D","F","G","H","J","K","L","\n",
  "abc","Z","X","C","V","B","N","M",".","-","\n",
  "123","@","_","SPACE","/",",","?","OK",""
};
static const char* kbSym[] = {
  "1","2","3","4","5","6","7","8","9","0","DEL","\n",
  "!","@","#","$","%","^","&","*","(",")","\n",
  "[","]","{","}","+","=","/","\\",":",";","\n",
  "abc","<",">","\"","'","~","`",".","-","\n",
  "ABC","_",",","SPACE","?","|","OK",""
};

static lv_obj_t* label(lv_obj_t* parent, const char* text, int x, int y, int w, uint32_t rgb=0xE7F1FF) {
  lv_obj_t* l=lv_label_create(parent);
  lv_label_set_text(l,text);
  lv_obj_set_pos(l,x,y);
  lv_obj_set_width(l,w);
  lv_obj_set_style_text_color(l,lv_color_hex(rgb),0);
  lv_obj_set_style_text_font(l,&lv_font_montserrat_14,0);
  lv_obj_clear_flag(l,LV_OBJ_FLAG_SCROLLABLE);
  return l;
}
static lv_obj_t* button(lv_obj_t* parent, const char* text, int x, int y, int w, int h, lv_event_cb_t cb) {
  lv_obj_t* b=lv_button_create(parent);
  lv_obj_set_pos(b,x,y);
  lv_obj_set_size(b,w,h);
  lv_obj_set_style_radius(b,7,0);
  lv_obj_set_style_border_width(b,0,0);
  lv_obj_set_style_bg_color(b,lv_color_hex(0x215077),0);
  lv_obj_clear_flag(b,LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_t* l=lv_label_create(b);
  lv_label_set_text(l,text);
  lv_obj_set_style_text_font(l,&lv_font_montserrat_14,0);
  lv_obj_set_style_text_color(l,lv_color_hex(0xFFFFFF),0);
  lv_obj_center(l);
  if(cb) lv_obj_add_event_cb(b,cb,LV_EVENT_CLICKED,nullptr);
  return b;
}
static void setMessage(const String& text, uint32_t color=0xFFD071) {
  esp_lv_adapter_lock(-1);
  if(statusLabel) {
    lv_label_set_text(statusLabel,text.c_str());
    lv_obj_set_style_text_color(statusLabel,lv_color_hex(color),0);
  }
  esp_lv_adapter_unlock();
}
static void beginPage(const char* title, const char* subtitle) {
  lv_obj_t* scr=lv_screen_active();
  lv_obj_clean(scr);
  lv_obj_clear_flag(scr,LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_scrollbar_mode(scr,LV_SCROLLBAR_MODE_OFF);
  lv_obj_set_style_pad_all(scr,0,0);
  lv_obj_set_style_bg_color(scr,lv_color_hex(0x050B16),0);
  lv_obj_set_style_bg_opa(scr,LV_OPA_COVER,0);
  dropdown=nullptr; entryLabel=nullptr; keyboard=nullptr; statusLabel=nullptr; eyeText=nullptr;
  label(scr, wizardMode==WIZARD_INITIAL ? "FlyRadar32  |  First setup" : "FlyRadar32  |  Settings",18,12,520,0xB8DFFF);
  label(scr,title,18,42,715,0xFFFFFF);
  if(subtitle) label(scr,subtitle,18,62,760,0x91A7BC);
}
static void updateInput() {
  if(!entryLabel) return;
  const char* content=(step==STEP_PASSWORD) ? pass : place;
  if(content[0]==0) {
    lv_label_set_text(entryLabel,step==STEP_PASSWORD ? "Wi-Fi password" : "City, Country (e.g. Grosseto, Italy)");
    lv_obj_set_style_text_color(entryLabel,lv_color_hex(0x8292A2),0);
    return;
  }
  if(step==STEP_PASSWORD && !showPassword) {
    char mask[65]={}; size_t n=strlen(pass); if(n>64) n=64;
    for(size_t i=0;i<n;i++) mask[i]='*';
    lv_label_set_text(entryLabel,mask);
  } else lv_label_set_text(entryLabel,content);
  lv_obj_set_style_text_color(entryLabel,lv_color_hex(0x162637),0);
}
static void nextEvent(lv_event_t*) { nextRequested=true; }
static void backEvent(lv_event_t*) { backRequested=true; }
static void scanEvent(lv_event_t*) { scanRequested=true; }
static void eyeEvent(lv_event_t*) {
  showPassword=!showPassword;
  updateInput();
  if(eyeText) lv_label_set_text(eyeText,showPassword ? "HIDE" : "SHOW");
}
static void updateKeyboardMap() {
  if(!keyboard) return;
  lv_buttonmatrix_set_map(keyboard,keyMode==UPPER?kbUpper:(keyMode==SYMBOLS?kbSym:kbLower));
}
static void keyboardEvent(lv_event_t* e) {
  // Use VALUE_CHANGED. PRESSED is too early on a buttonmatrix and can
  // capture a previous key: this caused incorrect Wi-Fi passwords before.
  if(lv_event_get_code(e)!=LV_EVENT_VALUE_CHANGED) return;
  lv_obj_t* mat=lv_event_get_target_obj(e);
  uint32_t id=lv_buttonmatrix_get_selected_button(mat);
  if(id==LV_BUTTONMATRIX_BUTTON_NONE) return;
  const char* k=lv_buttonmatrix_get_button_text(mat,id);
  if(!k) return;
  if(!strcmp(k,"OK")) { nextRequested=true; return; }
  if(!strcmp(k,"ABC")) { keyMode=UPPER; updateKeyboardMap(); return; }
  if(!strcmp(k,"abc")) { keyMode=LOWER; updateKeyboardMap(); return; }
  if(!strcmp(k,"123")) { keyMode=SYMBOLS; updateKeyboardMap(); return; }
  char* buf=step==STEP_PASSWORD ? pass : place;
  size_t cap=step==STEP_PASSWORD ? sizeof(pass) : sizeof(place);
  size_t n=strlen(buf);
  if(!strcmp(k,"DEL")) { if(n) buf[n-1]=0; }
  else { const char* ins=!strcmp(k,"SPACE") ? " " : k; size_t count=strlen(ins);
    if(n+count<cap) memcpy(buf+n,ins,count+1);
  }
  updateInput();
}
static void createKeyboard(lv_obj_t* scr) {
  keyMode=LOWER;
  keyboard=lv_buttonmatrix_create(scr);
  lv_obj_set_pos(keyboard,8,154);
  lv_obj_set_size(keyboard,784,318); // bottom=472, inside 800x480
  lv_obj_clear_flag(keyboard,LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_bg_color(keyboard,lv_color_hex(0x15283A),LV_PART_MAIN);
  lv_obj_set_style_bg_opa(keyboard,LV_OPA_COVER,LV_PART_MAIN);
  lv_obj_set_style_pad_all(keyboard,4,LV_PART_MAIN);
  lv_obj_set_style_pad_row(keyboard,3,LV_PART_MAIN);
  lv_obj_set_style_pad_column(keyboard,3,LV_PART_MAIN);
  lv_obj_set_style_bg_color(keyboard,lv_color_hex(0x30516F),LV_PART_ITEMS);
  lv_obj_set_style_text_color(keyboard,lv_color_hex(0xFFFFFF),LV_PART_ITEMS);
  lv_obj_set_style_text_font(keyboard,&lv_font_montserrat_14,LV_PART_ITEMS);
  lv_obj_set_style_radius(keyboard,5,LV_PART_ITEMS);
  lv_obj_set_style_border_width(keyboard,0,LV_PART_ITEMS);
  // Process a character once per touch, rather than auto-repeating
  // during a longer press. Keep VALUE_CHANGED: using PRESSED directly
  // on the matrix previously selected the wrong (old) key.
  lv_buttonmatrix_set_button_ctrl_all(keyboard,LV_BUTTONMATRIX_CTRL_NO_REPEAT);
  lv_obj_add_event_cb(keyboard,keyboardEvent,LV_EVENT_VALUE_CHANGED,nullptr);
  updateKeyboardMap();
}
static void drawNetworks() {
  esp_lv_adapter_lock(-1);
  beginPage("1 / 3  -  Wi-Fi network","Choose a network. Tap SCAN to refresh.");
  lv_obj_t* scr=lv_screen_active();
  dropdown=lv_dropdown_create(scr);
  lv_obj_set_pos(dropdown,18,111);
  lv_obj_set_size(dropdown,576,52);
  String opts;
  for(int i=0;i<networksCount;i++){ if(i) opts+='\n'; opts+=networks[i]; }
  if(!opts.length()) opts="No networks found";
  lv_dropdown_set_options(dropdown,opts.c_str());
  if(selected>=0 && selected<networksCount) lv_dropdown_set_selected(dropdown,selected);
  button(scr,"SCAN",617,111,165,52,scanEvent);
  button(scr,"NEXT",617,188,165,56,nextEvent);
  if(wizardMode==WIZARD_WIFI_ONLY) button(scr,"CANCEL",617,264,165,52,backEvent);
  statusLabel=label(scr,networksCount?"Select your Wi-Fi and tap NEXT.":"No Wi-Fi networks found. Tap SCAN.",18,209,560,networksCount?0x91E8AD:0xFFC177);
  esp_lv_adapter_unlock();
}
static void drawEntry(Step s) {
  step=s;
  esp_lv_adapter_lock(-1);
  beginPage(s==STEP_PASSWORD ? (wizardMode==WIZARD_INITIAL ? "2 / 3  -  Wi-Fi password" : "Change Wi-Fi password")
                               : (wizardMode==WIZARD_INITIAL ? "3 / 3  -  Your location" : "Change location"),
            s==STEP_PASSWORD ? "Check the password with SHOW before connecting." : "Type a city name. Coordinates will be found automatically.");
  lv_obj_t* scr=lv_screen_active();
  button(scr,"BACK",10,85,105,48,backEvent);
  lv_obj_t* box=lv_obj_create(scr);
  lv_obj_set_pos(box,124,85);
  lv_obj_set_size(box,s==STEP_PASSWORD?512:544,48);
  lv_obj_set_style_pad_all(box,0,0);
  lv_obj_set_style_radius(box,7,0);
  lv_obj_set_style_bg_color(box,lv_color_hex(0xF0F3FA),0);
  lv_obj_set_style_border_width(box,0,0);
  lv_obj_clear_flag(box,LV_OBJ_FLAG_SCROLLABLE);
  entryLabel=label(box,"",10,12,s==STEP_PASSWORD?476:516,0x152535);
  lv_label_set_long_mode(entryLabel,LV_LABEL_LONG_DOT);
  updateInput();
  if(s==STEP_PASSWORD) {
    lv_obj_t* eye=button(scr,showPassword?"HIDE":"SHOW",647,85,70,48,eyeEvent);
    eyeText=lv_obj_get_child(eye,0);
  }
  button(scr,s==STEP_PASSWORD?"CONNECT":"SEARCH",s==STEP_PASSWORD?727:680,85,s==STEP_PASSWORD?66:110,48,nextEvent);
  statusLabel=label(scr,s==STEP_PASSWORD?"Password is not stored until setup completes.":"Search uses online city databases.",10,137,775,0x9CABBF);
  createKeyboard(scr);
  esp_lv_adapter_unlock();
}
static void drawBusy(const char* text) {
  step=STEP_WAIT;
  esp_lv_adapter_lock(-1);
  beginPage("Please wait",text);
  statusLabel=label(lv_screen_active(),"",18,118,760,0xFFD071);
  esp_lv_adapter_unlock();
}
static void scan() {
  drawBusy("Scanning nearby Wi-Fi networks...");
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false,false);
  delay(150);
  int n=WiFi.scanNetworks(false,false);
  networksCount=0;
  for(int i=0;i<n && networksCount<MAX_NET;i++){
    String ssid=WiFi.SSID(i);
    if(ssid.length()==0) continue;
    bool duplicate=false;
    for(int j=0;j<networksCount;j++) if(ssid==networks[j]) { duplicate=true; break; }
    if(!duplicate) networks[networksCount++]=ssid;
  }
  WiFi.scanDelete();
  step=STEP_WIFI;
  drawNetworks();
  Serial.printf("SETUP: Wi-Fi scan found %d networks\n",networksCount);
}
static bool connectWifi() {
  if(selected<0 || selected>=networksCount) return false;
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.disconnect(false,false);
  delay(250);
  const char* ssid=networks[selected].c_str();
  Serial.printf("SETUP WIFI: SSID='%s' password_length=%u\n",ssid,(unsigned)strlen(pass));
  WiFi.begin(ssid,pass);
  uint32_t started=millis();
  while(millis()-started<20000) {
    if(WiFi.status()==WL_CONNECTED) {
      Serial.printf("SETUP WIFI: CONNECTED IP=%s RSSI=%d\n",WiFi.localIP().toString().c_str(),WiFi.RSSI());
      return true;
    }
    delay(150);
  }
  Serial.printf("SETUP WIFI: FAILED status=%d\n",(int)WiFi.status());
  return false;
}

// Small JSON primitives; avoid adding ArduinoJson or other dependencies.
// Every key search is bounded by an object offset, and an explicit response
// check is performed before storing anything in NVS.
static int keyPos(const String& j,const char* key,int from) {
  String token="\""; token+=key; token+="\"";
  return j.indexOf(token,from);
}
static bool jsonString(const String& j,const char* key,String& output,int from=0) {
  int p=keyPos(j,key,from); if(p<0) return false;
  p=j.indexOf(':',p); if(p<0) return false;
  while(++p<(int)j.length() && (j[p]==' ' || j[p]=='\n' || j[p]=='\r')) {}
  if(p>=(int)j.length() || j[p]!='"') return false;
  int a=++p;
  while(p<(int)j.length()) { if(j[p]=='\\'){p+=2;continue;} if(j[p]=='"')break; p++; }
  if(p>=(int)j.length()) return false;
  output=j.substring(a,p); output.replace("\\/","/"); return true;
}
static bool jsonDouble(const String& j,const char* key,double& val,int from=0) {
  int p=keyPos(j,key,from); if(p<0) return false;
  p=j.indexOf(':',p); if(p<0) return false;
  const char* start=j.c_str()+p+1;
  char* end=nullptr;
  val=strtod(start,&end);
  return end!=start;
}
static String encodeUrl(const String& s) {
  const char* digits="0123456789ABCDEF"; String v;
  for(size_t i=0;i<s.length();i++){
    uint8_t c=(uint8_t)s[i];
    if((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~') v+=(char)c;
    else {v+='%';v+=digits[c>>4];v+=digits[c&15];}
  }
  return v;
}
static void logHttpMemory(const char* tag) {
  Serial.printf(
      "%s: heap_internal=%u largest_internal=%u psram=%u\n",
      tag,
      (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
      (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
      (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)
  );
}
static bool httpsGet(const String& url,String& body,const char* provider,int& code) {
  body = String();
  if(WiFi.status() != WL_CONNECTED) {
    code=-98;
    Serial.printf("SETUP GEO %s: Wi-Fi disconnected\n",provider);
    return false;
  }
  logHttpMemory("SETUP HTTPS BEFORE");
  WiFiClientSecure client;
  client.setInsecure(); // keep same certificate policy as original setup
  client.setHandshakeTimeout(12);
  HTTPClient http;
  http.setTimeout(13000);
  http.useHTTP10(true);
  if(!http.begin(client,url)) {
    code=-99;
    Serial.printf("SETUP GEO %s: http.begin failed\n",provider);
    return false;
  }
  http.addHeader("Accept-Encoding","identity");
  http.addHeader("User-Agent","FlyRadar-Waveshare7/5.0.0");
  code=http.GET();
  if(code==HTTP_CODE_OK) body=http.getString();
  Serial.printf("SETUP GEO %s: HTTP=%d bytes=%u",provider,code,(unsigned)body.length());
  if(code<0) {
    Serial.printf(" error=%s",HTTPClient::errorToString(code).c_str());
    // HTTP=-1 means secure Client::connect() failed, NOT an HTTP 4xx/5xx.
    // Inspect the underlying mbedTLS error before closing the client.
    char tlsError[160] = {};
    int tlsCode = client.lastError(tlsError,sizeof(tlsError));
    Serial.printf(" tls=%d tls_text=%s",tlsCode,tlsError);
  }
  Serial.println();
  http.end();
  logHttpMemory("SETUP HTTPS AFTER");
  return code==HTTP_CODE_OK && body.length()>0;
}
struct PlaceResult { String name; String zone; double lat=0; double lon=0; };
static bool openMeteoLookup(const String& query,PlaceResult& result) {
  String body;int code=0;
  String url="https://geocoding-api.open-meteo.com/v1/search?name="+encodeUrl(query)+"&count=5&language=en&format=json";
  if(!httpsGet(url,body,"OpenMeteoGeocoding",code)) return false;
  int arr=keyPos(body,"results",0); if(arr<0) { Serial.println("SETUP GEO: no matches in Open-Meteo result"); return false; }
  int a=body.indexOf('[',arr); int first=body.indexOf('{',a);
  if(a<0 || first<0 || first>body.indexOf(']',a)) return false;
  String name, country, zone;
  if(!jsonDouble(body,"latitude",result.lat,first) || !jsonDouble(body,"longitude",result.lon,first)
     || !jsonString(body,"timezone",zone,first)) return false;
  jsonString(body,"name",name,first); jsonString(body,"country",country,first);
  result.name = name.length()?name:query;
  if(country.length()){result.name+=", ";result.name+=country;}
  result.zone=zone;
  return true;
}
static bool photonLookup(const String& query,PlaceResult& result) {
  String body; int code=0;
  String url="https://photon.komoot.io/api/?q="+encodeUrl(query)+"&limit=1&lang=en";
  if(!httpsGet(url,body,"Photon",code)) return false;
  int features=keyPos(body,"features",0); if(features<0) return false;
  int ar=body.indexOf('[',features); if(ar<0) return false; int end=body.indexOf(']',ar); int feature=body.indexOf('{',ar); if(feature<0 || (end>=0 && feature>end)) return false;
  int coordinates=keyPos(body,"coordinates",feature); if(coordinates<0) return false;
  int open=body.indexOf('[',coordinates); if(open<0) return false;
  const char* p=body.c_str()+open+1;
  char* e=nullptr; result.lon=strtod(p,&e);
  if(e==p) return false;
  while(*e==' ' || *e==',' || *e=='\n') e++;
  char* e2=nullptr; result.lat=strtod(e,&e2);
  if(e2==e) return false;
  String city,country;
  int properties=keyPos(body,"properties",feature);
  if(properties>=0) {
    jsonString(body,"name",city,properties);
    jsonString(body,"country",country,properties);
  }
  result.name=city.length()?city:query;
  if(country.length()){result.name+=", ";result.name+=country;}
  return true;
}
static bool timezoneLookup(PlaceResult& result) {
  char url[270];
  snprintf(url,sizeof(url),"https://api.open-meteo.com/v1/forecast?latitude=%.6f&longitude=%.6f&current=temperature_2m&timezone=auto&forecast_days=1",result.lat,result.lon);
  String body;int code=0;
  if(!httpsGet(String(url),body,"Timezone",code)) return false;
  return jsonString(body,"timezone",result.zone);
}
static bool geocode(const char* city,PlaceResult& result,String& error) {
  if(WiFi.status()!=WL_CONNECTED){ error="Wi-Fi disconnected during location search."; return false; }
  String query=String(city); query.trim();
  if(query.length()<2){error="Enter at least two characters.";return false;}
  bool got=openMeteoLookup(query,result);
  if(!got){
    Serial.println("SETUP GEO: Open-Meteo geocoding failed; trying Photon...");
    got=photonLookup(query,result);
    if(got && !timezoneLookup(result)){
      error="Coordinates found, but timezone service unavailable. Try SEARCH again.";
      return false;
    }
  }
  if(!got){error="City lookup unavailable or no match. Try City, Country.";return false;}
  if(result.lat<-90 || result.lat>90 || result.lon<-180 || result.lon>180){error="Invalid coordinates returned by search.";return false;}
  if(!cmPosixForZone(result.zone.c_str())) {
    error="Timezone not recognized: "+result.zone; return false;
  }
  Serial.printf("SETUP GEO: SUCCESS %s -> %.6f, %.6f, %s\n",result.name.c_str(),result.lat,result.lon,result.zone.c_str());
  return true;
}
} // namespace

// One wizard, three modes. Never overwrite saved configuration until the
// chosen operation has completed successfully.
static bool runWizard(WizardMode mode) {
  wizardMode=mode;
  scanRequested=false;nextRequested=false;backRequested=false;
  selected=-1;networksCount=0;pass[0]=0;place[0]=0;showPassword=false;

  if(mode==WIZARD_LOCATION_ONLY) {
    // Saved WLAN remains active. No rescan or password is needed.
    step=STEP_PLACE;
    drawEntry(STEP_PLACE);
  } else {
    step=STEP_WIFI;
    Serial.println(mode==WIZARD_INITIAL ? "FIRST SETUP: starting Wi-Fi scan"
                                        : "SETTINGS: scanning Wi-Fi networks");
    scan();
  }

  while(true) {
    if(scanRequested && step==STEP_WIFI) {scanRequested=false;scan();}
    if(backRequested) {
      backRequested=false;
      if(step==STEP_PASSWORD) { step=STEP_WIFI;drawNetworks(); }
      else if(step==STEP_PLACE) {
        if(mode==WIZARD_INITIAL) drawEntry(STEP_PASSWORD);
        else return false;
      }
      else if(step==STEP_WIFI && mode==WIZARD_WIFI_ONLY) return false;
    }
    if(nextRequested) {
      nextRequested=false;
      if(step==STEP_WIFI) {
        if(networksCount==0) setMessage("No networks found. Tap SCAN.");
        else {
          uint16_t choice=0;
          esp_lv_adapter_lock(-1);
          if(dropdown) choice=lv_dropdown_get_selected(dropdown);
          esp_lv_adapter_unlock();
          if(choice>=networksCount) setMessage("Invalid Wi-Fi selection.");
          else {selected=choice; drawEntry(STEP_PASSWORD);}
        }
      }
      else if(step==STEP_PASSWORD) {
        drawBusy("Verifying Wi-Fi connection...");
        if(connectWifi()) {
          if(mode==WIZARD_WIFI_ONLY) {
            // Save new network/password while keeping the proven existing
            // location, coordinates and timezone. Never clear NVS first.
            bool saved=cmSaveConfig(networks[selected].c_str(),pass,
                cmLocation(),cmLatitude(),cmLongitude(),cmIANA(),cmTZ());
            if(saved) {
              Serial.println("SETTINGS: Wi-Fi configuration saved");
              drawBusy("Wi-Fi settings saved. Restarting...");
              delay(400);
              for(int i=0;i<MAX_NET;i++) networks[i]=String();
              return true;
            }
            drawEntry(STEP_PASSWORD);
            setMessage("Could not save Wi-Fi configuration.",0xFF7777);
          } else drawEntry(STEP_PLACE);
        } else {
          drawEntry(STEP_PASSWORD);
          setMessage("Wi-Fi failed. Check password with SHOW.",0xFF7777);
        }
      }
      else if(step==STEP_PLACE) {
        String query(place); query.trim();
        if(query.length()<2) setMessage("Please enter a city name.",0xFF7777);
        else {
          drawBusy("Searching coordinates and timezone...");
          if(WiFi.status()!=WL_CONNECTED && mode==WIZARD_LOCATION_ONLY) {
            WiFi.mode(WIFI_STA);
            WiFi.begin(cmSSID(),cmPassword());
            uint32_t started=millis();
            while(WiFi.status()!=WL_CONNECTED && millis()-started<16000) delay(150);
          }
          PlaceResult result; String error;
          if(!geocode(query.c_str(),result,error)) {
            drawEntry(STEP_PLACE);
            setMessage(error,0xFF7777);
            Serial.printf("SETUP GEO: FAILED: %s\n",error.c_str());
          } else {
            const char* rule=cmPosixForZone(result.zone.c_str());
            const char* ssid=mode==WIZARD_LOCATION_ONLY ? cmSSID() : networks[selected].c_str();
            const char* password=mode==WIZARD_LOCATION_ONLY ? cmPassword() : pass;
            if(rule && cmSaveConfig(ssid,password,result.name.c_str(),result.lat,result.lon,result.zone.c_str(),rule)) {
              drawBusy("Settings saved. Starting FlyRadar32...");
              Serial.println(mode==WIZARD_INITIAL ? "FIRST SETUP: saved to NVS"
                                                  : "SETTINGS: location saved to NVS");
              delay(400);
              for(int i=0;i<MAX_NET;i++) networks[i]=String();
              return true;
            }
            drawEntry(STEP_PLACE);
            setMessage("Saving configuration failed. Try SEARCH again.",0xFF7777);
          }
        }
      }
    }
    // Network work is in the Arduino task; UI callbacks only set flags.
    // Poll requests more promptly while keeping time for the LVGL task.
    delay(5);
  }
}

bool cmRunFirstSetup() { return runWizard(WIZARD_INITIAL); }
bool cmRunChangeWiFi() { return runWizard(WIZARD_WIFI_ONLY); }
bool cmRunChangeLocation() { return runWizard(WIZARD_LOCATION_ONLY); }
