#pragma once

#include <WiFiClientSecure.h>
#include <esp_heap_caps.h>

// Isolated ADS-B transport. NetworkClient::readBytes() in ESP32 core 3.3.12
// treats TLS read() == -1 (no decrypted bytes yet) as EOF. Wait for available
// bytes instead; do not change the library or the map/photo clients.
class AdsbTlsClient : public WiFiClientSecure {
public:
  static constexpr uint32_t IDLE_MS = 30000;
  static constexpr uint32_t BODY_MS = 120000;

  void beginBody() {
    started = lastByte = millis();
    bodyActive = true;
    timedOut = false;
  }

  int available() override {
    if (expired()) return 0;
    return WiFiClientSecure::available();
  }

  uint8_t connected() override {
    if (expired()) return 0;
    return WiFiClientSecure::connected();
  }

  int read(uint8_t *data, size_t length) override {
    if (expired()) return -1;
    const int count = WiFiClientSecure::read(data, length);
    if (count > 0) lastByte = millis();
    return count;
  }

  using WiFiClientSecure::read;
  size_t readBytes(char *data, size_t length) override {
    size_t received = 0;
    uint32_t lastProgress = millis();
    while (received < length) {
      const int ready = available();
      if (ready > 0) {
        const size_t wanted = (size_t)ready < length - received
                                ? (size_t)ready : length - received;
        const int count = read(reinterpret_cast<uint8_t *>(data) + received, wanted);
        if (count > 0) {
          received += count;
          lastProgress = millis();
          continue;
        }
      }
      if (!connected() || (uint32_t)(millis() - lastProgress) >= IDLE_MS) break;
      delay(2);  // Leave the display/touch tasks runnable while waiting for TLS.
    }
    return received;
  }
  size_t readBytes(uint8_t *data, size_t length) override {
    return readBytes(reinterpret_cast<char *>(data), length);
  }
  bool timedOut = false;

private:
  bool bodyActive = false;
  uint32_t started = 0, lastByte = 0;
  bool expired() {
    if (!bodyActive || timedOut) return timedOut;
    if ((uint32_t)(millis() - lastByte) < IDLE_MS &&
        (uint32_t)(millis() - started) < BODY_MS) return false;
    timedOut = true;
    WiFiClientSecure::stop();
    return true;
  }
};

// Bounded, growing PSRAM storage, used only until the JSON parse completes.
// HTTPClient writes the decoded HTTP body here (including chunked responses).
class AdsbBody : public Stream {
public:
  static constexpr size_t MAX_BYTES = 1024 * 1024;
  ~AdsbBody() override { heap_caps_free(data); }
  AdsbBody() = default;
  AdsbBody(const AdsbBody &) = delete;
  AdsbBody &operator=(const AdsbBody &) = delete;
  uint8_t *data = nullptr;
  size_t length = 0;
  bool failed = false;
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  void flush() override {}
  size_t write(uint8_t value) override { return write(&value, 1); }
  size_t write(const uint8_t *source, size_t count) override {
    if (failed || !source || count > MAX_BYTES - length) {
      failed = true;
      return 0;
    }
    if (!count) return 0;
    if (length + count > capacity) {
      size_t next = capacity ? capacity : 16384;
      while (next < length + count) next *= 2;
      uint8_t *grown = static_cast<uint8_t *>(heap_caps_realloc(
          data, next, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
      if (!grown) { failed = true; return 0; }
      data = grown;
      capacity = next;
    }
    memcpy(data + length, source, count);
    length += count;
    return count;
  }
private:
  size_t capacity = 0;
};
