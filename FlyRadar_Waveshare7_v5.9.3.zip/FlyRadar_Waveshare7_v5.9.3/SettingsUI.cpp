#include "SettingsUI.h"
#include "SetupWizard.h"
#include "RuntimeConfig.h"
#include "esp_lv_adapter_arduino.h"
#include <lvgl.h>
#include <Arduino.h>

namespace {
enum Action { ACTION_NONE, ACTION_NETWORK, ACTION_LOCATION, ACTION_RESET,
              ACTION_BACK, ACTION_CONFIRM_RESET, ACTION_CANCEL_RESET };
static volatile int requested=ACTION_NONE;
static lv_obj_t* layer=nullptr;
static bool startupRecoveryMode=false;

static void actionEvent(lv_event_t* e) {
  requested=(int)(intptr_t)lv_event_get_user_data(e);
}
static lv_obj_t* mkLabel(lv_obj_t* parent, const char* t,
                         int x,int y,int w,uint32_t color=0xE7F1FF) {
  lv_obj_t* l=lv_label_create(parent);
  lv_label_set_text(l,t);
  lv_obj_set_pos(l,x,y);
  lv_obj_set_width(l,w);
  lv_label_set_long_mode(l,LV_LABEL_LONG_DOT);
  lv_obj_set_style_text_font(l,&lv_font_montserrat_14,0);
  lv_obj_set_style_text_color(l,lv_color_hex(color),0);
  return l;
}
static void mkButton(lv_obj_t* parent,const char* text,int x,int y,
                     int w,int h,Action action,uint32_t color=0x1C4C74) {
  lv_obj_t* b=lv_button_create(parent);
  lv_obj_set_pos(b,x,y);
  lv_obj_set_size(b,w,h);
  lv_obj_set_style_bg_color(b,lv_color_hex(color),0);
  lv_obj_set_style_border_width(b,0,0);
  lv_obj_set_style_radius(b,9,0);
  lv_obj_add_event_cb(b,actionEvent,LV_EVENT_CLICKED,(void*)(intptr_t)action);
  lv_obj_t* l=lv_label_create(b);
  lv_label_set_text(l,text);
  lv_obj_set_style_text_font(l,&lv_font_montserrat_14,0);
  lv_obj_set_style_text_color(l,lv_color_hex(0xFFFFFF),0);
  lv_obj_center(l);
}
static void prepareLayer() {
  // Do not delete the radar when simply viewing Settings. It remains
  // below this opaque full-screen overlay.
  lv_obj_t* scr=lv_screen_active();
  layer=lv_obj_create(scr);
  lv_obj_set_pos(layer,0,0);
  lv_obj_set_size(layer,800,480);
  lv_obj_set_style_bg_color(layer,lv_color_hex(0x050D19),0);
  lv_obj_set_style_bg_opa(layer,LV_OPA_COVER,0);
  lv_obj_set_style_border_width(layer,0,0);
  lv_obj_set_style_radius(layer,0,0);
  lv_obj_set_style_pad_all(layer,0,0);
  lv_obj_clear_flag(layer,LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_scrollbar_mode(layer,LV_SCROLLBAR_MODE_OFF);
  lv_obj_move_foreground(layer);
}
static void drawMenu() {
  esp_lv_adapter_lock(-1);
  // The setup wizard cleans the whole screen, so layer can no longer be
  // assumed valid after returning from a wizard. Create a new one.
  prepareLayer();
  mkLabel(layer,"FLYRADAR32  |  SETTINGS",25,24,730,0x86D4FF);
  String wlan="Wi-Fi: "; wlan+=cmSSID();
  String loc="Location: ";loc+=cmLocation();
  mkLabel(layer,wlan.c_str(),25,72,355,0xAEC2D5);
  mkLabel(layer,loc.c_str(),405,72,365,0xAEC2D5);
  mkButton(layer,"CHANGE WI-FI",25,130,355,75,ACTION_NETWORK);
  mkButton(layer,"CHANGE LOCATION",420,130,355,75,ACTION_LOCATION);
  mkButton(layer,"FACTORY RESET",25,235,355,75,ACTION_RESET,0x79333D);
  mkButton(layer, startupRecoveryMode ? "RETRY CONNECTION" : "BACK TO RADAR",
           420,235,355,75,ACTION_BACK,0x255B42);
  if (startupRecoveryMode) {
    mkLabel(layer,"Saved network unavailable or clock not synchronized.",25,346,746,0xFFC17B);
    mkLabel(layer,"Select CHANGE WI-FI to connect to a new network.",25,369,746,0x91A3B6);
  } else {
    mkLabel(layer,"Reset only erases FlyRadar32 Wi-Fi and location settings.",
            25,380,746,0x91A3B6);
  }
  mkLabel(layer,"FIRMWARE VERSION 5.9.3",25,439,730,0x86D4FF);
  requested=ACTION_NONE;
  esp_lv_adapter_unlock();
}
static void drawConfirmation() {
  esp_lv_adapter_lock(-1);
  if(layer) lv_obj_clean(layer);
  mkLabel(layer,"Factory Reset",25,30,730,0xFFC17B);
  mkLabel(layer,"Erase saved Wi-Fi, password, location and timezone?",25,108,746);
  mkLabel(layer,"The device will restart into First Setup.",25,145,746,0x9CB0C3);
  mkButton(layer,"CANCEL",25,245,355,78,ACTION_CANCEL_RESET,0x255B42);
  mkButton(layer,"RESET",420,245,355,78,ACTION_CONFIRM_RESET,0x79333D);
  requested=ACTION_NONE;
  esp_lv_adapter_unlock();
}
static void closeLayer() {
  esp_lv_adapter_lock(-1);
  if(layer) lv_obj_delete(layer);
  layer=nullptr;
  esp_lv_adapter_unlock();
}
}

bool cmRunSettingsMenu(bool startupRecovery) {
  startupRecoveryMode=startupRecovery;
  requested=ACTION_NONE;
  bool replacedCalendar=false;
  bool confirming=false;
  drawMenu();

  while(true) {
    Action a=(Action)requested;
    if(a==ACTION_NONE) { delay(20); continue; }
    requested=ACTION_NONE;
    if(a==ACTION_BACK) {
      closeLayer();
      return replacedCalendar;
    }
    if(a==ACTION_RESET) {
      drawConfirmation();
      confirming=true;
      continue;
    }
    if(a==ACTION_CANCEL_RESET && confirming) {
      confirming=false;
      closeLayer();
      drawMenu();
      continue;
    }
    if(a==ACTION_CONFIRM_RESET && confirming) {
      Serial.println("SETTINGS: factory reset confirmed");
      cmClearConfig();
      delay(200);
      ESP.restart();
    }
    if(a==ACTION_NETWORK || a==ACTION_LOCATION) {
      // The existing SetupWizard cleans the LVGL screen and replaces this
      // overlay. Its saved settings are kept until a complete success.
      layer=nullptr;
      replacedCalendar=true;
      bool ok=(a==ACTION_NETWORK)?cmRunChangeWiFi():cmRunChangeLocation();
      if(ok) {
        Serial.println("SETTINGS: configuration updated; restarting");
        delay(200);
        ESP.restart();
      }
      // Cancel: old NVS values are untouched. Return to Settings.
      confirming=false;
      drawMenu();
    }
  }
}
